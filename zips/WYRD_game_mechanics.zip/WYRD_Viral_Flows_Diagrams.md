# WYRD Viral Flows & Diagrams
## Visual Guide to Viral Mechanics

---

## 1. CORE VIRAL LOOP

```
                    ┌─────────────────────────────────────────┐
                    │                                         │
                    ▼                                         │
    ┌──────────────────────┐      ┌──────────────────────┐   │
    │   USER DISCOVERS     │      │   USER SHARES        │   │
    │   WORD ORIGIN        │─────→│   ON SOCIAL          │   │
    │   (Mind-blown moment)│      │   (Farcaster, etc)   │   │
    └──────────────────────┘      └──────────────────────┘   │
                                              │              │
                                              ▼              │
                              ┌──────────────────────┐       │
                              │   FRIENDS SEE POST   │       │
                              │   (Social proof)     │       │
                              └──────────────────────┘       │
                                              │              │
                                              ▼              │
                              ┌──────────────────────┐       │
                              │   FRIENDS CLICK      │       │
                              │   LINK/FRAME         │───────┘
                              └──────────────────────┘
                                              │
                                              ▼
                              ┌──────────────────────┐
                              │   NEW USER SIGNS UP  │
                              │   (Viral conversion) │
                              └──────────────────────┘
```

**Viral Coefficient (K) = Invites × Conversion Rate**

Target: K > 1 for exponential growth

---

## 2. REFERRAL FLOW

```
    ┌──────────────┐
    │  EXISTING    │
    │   USER       │
    │ (Has WYRD    │
    │  account)    │
    └──────┬───────┘
           │
           │ 1. Generates
           │    referral link
           ▼
    ┌──────────────┐
    │  REFERRAL    │
    │   CODE       │
    │ WYRD-ALICE-  │
    │    001       │
    └──────┬───────┘
           │
           │ 2. Shares via
           │    any channel
           ▼
    ┌──────────────┐     ┌──────────────┐
    │  FARCASTER   │     │   TWITTER    │
    │   FRAME      │     │    POST      │
    └──────┬───────┘     └──────┬───────┘
           │                    │
           └────────┬───────────┘
                    │
                    │ 3. Friend clicks
                    ▼
           ┌────────────────┐
           │  LANDING PAGE  │
           │  (Attribution  │
           │   tracked)     │
           └───────┬────────┘
                   │
                   │ 4. Signs up
                   ▼
           ┌────────────────┐
           │   NEW USER     │
           │  (Referred)    │
           └───────┬────────┘
                   │
                   │ 5. Both get
                   │    rewards!
                   ▼
    ┌────────────────────────────────┐
    │         REWARDS FLOW           │
    ├────────────────────────────────┤
    │  INVITER: +200 WYRD points     │
    │  NEW USER: +100 WYRD points    │
    │  + Bonus on milestones         │
    └────────────────────────────────┘
```

---

## 3. POINTS ECONOMY FLOW

```
                         ┌─────────────────────┐
                         │   USER ACTIVITY     │
                         └──────────┬──────────┘
                                    │
            ┌───────────────────────┼───────────────────────┐
            │                       │                       │
            ▼                       ▼                       ▼
   ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
   │  WORD ANALYSIS  │    │    SHARING      │    │   REFERRALS     │
   │                 │    │                 │    │                 │
   │ +50 pts/word    │    │ +25 pts/share   │    │ +200/signup     │
   │ (cap: 500/day)  │    │ (cap: 250/day)  │    │ (no cap)        │
   └────────┬────────┘    └────────┬────────┘    └────────┬────────┘
            │                       │                       │
            └───────────────────────┼───────────────────────┘
                                    │
                                    ▼
                         ┌─────────────────────┐
                         │   WYRD POINTS       │
                         │   BALANCE           │
                         │                     │
                         │  Stored: PostgreSQL │
                         │  Cache: Redis       │
                         └──────────┬──────────┘
                                    │
                    ┌───────────────┼───────────────┐
                    │               │               │
                    ▼               ▼               ▼
           ┌─────────────┐  ┌─────────────┐  ┌─────────────┐
           │ LEADERBOARD │  │    QUEST    │  │   REWARDS   │
           │   RANKING   │  │  UNLOCKS    │  │   SHOP      │
           │             │  │             │  │             │
           │ Top 100     │  │ Daily/Weekly│  │ Word packs  │
           │ Percentile  │  │ Monthly     │  │ Early access│
           └─────────────┘  └─────────────┘  └─────────────┘
                                    │
                                    ▼
                         ┌─────────────────────┐
                         │   FUTURE: TOKEN     │
                         │   CONVERSION        │
                         │                     │
                         │ Points → Token      │
                         │ allocation at TGE   │
                         └─────────────────────┘
```

---

## 4. STREAK SYSTEM FLOW

```
    Day 1           Day 2           Day 3           Day 7
    ┌───┐           ┌───┐           ┌───┐           ┌───┐
    │ ✓ │──────────→│ ✓ │──────────→│ ✓ │──...────→│ ✓ │
    └───┘           └───┘           └───┘           └───┘
      │               │               │               │
      │ +50 pts       │ +50 pts       │ +50 pts       │ +500 pts
      │               │               │               │ (bonus)
      ▼               ▼               ▼               ▼
    ┌─────────────────────────────────────────────────────┐
    │                    STREAK BONUS                      │
    ├─────────────────────────────────────────────────────┤
    │  3 days: +100 pts    14 days: +1000 pts             │
    │  7 days: +500 pts    30 days: +2000 pts             │
    └─────────────────────────────────────────────────────┘

    IF MISSED:
    ┌─────────────────────────────────────────────────────┐
    │                                                     │
    │   STREAK BROKEN! 💔                                 │
    │                                                     │
    │   You had {N} days...                               │
    │                                                     │
    │   [Share your streak] ← Viral opportunity!         │
    │   [Start new streak]                                │
    │                                                     │
    │   +50 pts consolation                               │
    │                                                     │
    └─────────────────────────────────────────────────────┘
```

---

## 5. COMMUNITY CHALLENGE FLOW

```
    ┌─────────────────────────────────────────────────────────────┐
    │                    CHALLENGE ANNOUNCEMENT                    │
    │                                                              │
    │  🔍 This Week: Find words with Latin roots!                  │
    │                                                              │
    │  Target: 50 words    Reward: 500 WYRD + POAP                 │
    │                                                              │
    │  [Join Challenge]                                            │
    └─────────────────────────────┬───────────────────────────────┘
                                  │
                                  ▼
    ┌─────────────────────────────────────────────────────────────┐
    │                    USER PARTICIPATION                        │
    │                                                              │
    │  User finds Latin word ──→ +10 pts per word                 │
    │         │                                                    │
    │         ▼                                                    │
    │  Progress: 12/50 [████████████░░░░░░░░░░░░░░░░░░] 24%        │
    │                                                              │
    │  [Share Progress] ← Viral trigger                           │
    └─────────────────────────────┬───────────────────────────────┘
                                  │
                                  ▼
    ┌─────────────────────────────────────────────────────────────┐
    │                 COMMUNITY AGGREGATION                        │
    │                                                              │
    │  All users' finds combined                                   │
    │         │                                                    │
    │         ▼                                                    │
    │  Community: 1,247/5,000 [████████████████░░░░░░░░] 25%       │
    │                                                              │
    │  [View Leaderboard]                                          │
    └─────────────────────────────┬───────────────────────────────┘
                                  │
                                  ▼
    ┌─────────────────────────────────────────────────────────────┐
    │                   CHALLENGE COMPLETE                         │
    │                                                              │
    │  🎉 MILESTONE REACHED! 5,000 Latin words found!              │
    │                                                              │
    │  Your contribution: 23 words (0.5%)                          │
    │                                                              │
    │  Rewards distributed:                                        │
    │  ✓ 500 WYRD points                                           │
    │  ✓ "Latin Scholar" POAP                                      │
    │  ✓ Unlocked: "Latin Word Pack"                               │
    │                                                              │
    │  [Claim POAP] [Share Victory] [Next Challenge]               │
    └─────────────────────────────────────────────────────────────┘
```

---

## 6. WORD SUBMISSION & UGC FLOW

```
    ┌─────────────────────────────────────────────────────────────┐
    │                    USER HAS INSIGHT                          │
    │                                                              │
    │  User discovers interesting word origin                      │
    │         │                                                    │
    │         ▼                                                    │
    │  [Submit Word] button                                        │
    └─────────────────────────────┬───────────────────────────────┘
                                  │
                                  ▼
    ┌─────────────────────────────────────────────────────────────┐
    │                   SUBMISSION FORM                            │
    │                                                              │
    │  Word: _______________                                       │
    │                                                              │
    │  Surface Meaning: _____________                              │
    │                                                              │
    │  Root/Etymology: _____________                               │
    │                                                              │
    │  Liberation Angle: _____________                             │
    │                                                              │
    │  [Submit for Review]                                         │
    └─────────────────────────────┬───────────────────────────────┘
                                  │
                                  ▼
    ┌─────────────────────────────────────────────────────────────┐
    │                   REVIEW PROCESS                             │
    │                                                              │
    │  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐      │
    │  │   AUTO      │───→│  COMMUNITY  │───→│   TEAM      │      │
    │  │   CHECK     │    │   VOTING    │    │  APPROVAL   │      │
    │  │  (spam)     │    │  (quality)  │    │  (final)    │      │
    │  └─────────────┘    └─────────────┘    └─────────────┘      │
    │                                                              │
    │  Timeline: 24-48 hours                                       │
    └─────────────────────────────┬───────────────────────────────┘
                                  │
                    ┌─────────────┴─────────────┐
                    │                           │
                    ▼                           ▼
    ┌─────────────────────────┐   ┌─────────────────────────┐
    │       APPROVED          │   │       REJECTED          │
    │                         │   │                         │
    │  ✓ Word published       │   │  ✗ Feedback provided    │
    │  ✓ User gets 1000 pts   │   │  ✓ Can resubmit         │
    │  ✓ "Contributor" badge  │   │  ✓ +50 pts for effort   │
    │  ✓ Name in credits      │   │                         │
    │                         │   │                         │
    │  [Share Your Word]      │   │  [Try Again]            │
    └─────────────────────────┘   └─────────────────────────┘
```

---

## 7. FARCASTER FRAME INTERACTION FLOW

```
    ┌─────────────────────────────────────────────────────────────┐
    │                    USER SEES CAST                            │
    │                                                              │
    │  @wyrd: 🔮 WYRD Daily Word #127                              │
    │                                                              │
    │  ┌─────────────────────────────────────────────────────┐    │
    │  │  🔮 WYRD DAILY                                      │    │
    │  │                                                     │    │
    │  │  Today's word: [REDACTED]                           │    │
    │  │                                                     │    │
    │  │  [Reveal Origin]  [Share Discovery]                 │    │
    │  │                                                     │    │
    │  │  1,247 liberators today                             │    │
    │  └─────────────────────────────────────────────────────┘    │
    │                                                              │
    │  [Like] [Recast] [Reply]                                     │
    └─────────────────────────────┬───────────────────────────────┘
                                  │
                    ┌─────────────┴─────────────┐
                    │                           │
                    ▼                           ▼
    ┌─────────────────────────┐   ┌─────────────────────────┐
    │   CLICK [Reveal Origin] │   │  CLICK [Share Discovery]│
    │                         │   │                         │
    │  Frame updates:         │   │  Opens cast composer    │
    │                         │   │  with pre-filled:       │
    │  Word: "GOVERNMENT"     │   │                         │
    │  Root: "gubernare"      │   │  "Just learned..."      │
    │  = to steer ship        │   │  + word reveal          │
    │                         │   │  + link                 │
    │  [Next Word] [Share]    │   │                         │
    │                         │   │  [Cast] ← Viral spread  │
    └─────────────────────────┘   └─────────────────────────┘
```

---

## 8. NETWORK EFFECTS COMPOUNDING

```
         MORE USERS
             │
             ▼
    ┌─────────────────┐
    │  More word      │
    │  submissions    │
    └────────┬────────┘
             │
             ▼
    ┌─────────────────┐
    │  Larger word    │
    │  database       │
    └────────┬────────┘
             │
             ▼
    ┌─────────────────┐
    │  More unique    │
    │  discoveries    │
    └────────┬────────┘
             │
             ▼
    ┌─────────────────┐
    │  More shareable │
    │  moments        │
    └────────┬────────┘
             │
             ▼
    ┌─────────────────┐
    │  More social    │
    │  sharing        │
    └────────┬────────┘
             │
             ▼
    ┌─────────────────┐
    │  More new users │
    │  (back to top)  │
    └─────────────────┘

    ═══════════════════════════════════════════════════════
    
    ADDITIONAL LOOPS:
    
    More users → More challenges → More engagement → More retention
    
    More users → More discussions → More insights → More content
    
    More users → Bigger community → More social proof → More trust
```

---

## 9. TOKEN AIRDROP FLOW (Future)

```
    ┌─────────────────────────────────────────────────────────────┐
    │                   PHASE 1: ACCUMULATION                      │
    │                   (Months 1-3, Silent)                       │
    │                                                              │
    │  • Users earn WYRD points                                    │
    │  • No token mentioned                                        │
    │  • Organic usage patterns                                    │
    │  • Build genuine community                                   │
    │                                                              │
    └─────────────────────────────┬───────────────────────────────┘
                                  │
                                  ▼
    ┌─────────────────────────────────────────────────────────────┐
    │                   PHASE 2: HINT                              │
    │                   (Month 3)                                  │
    │                                                              │
    │  • "Points may have future utility"                          │
    │  • Engagement increases                                      │
    │  • Farmers start to appear                                   │
    │                                                              │
    └─────────────────────────────┬───────────────────────────────┘
                                  │
                                  ▼
    ┌─────────────────────────────────────────────────────────────┐
    │                   PHASE 3: ANNOUNCEMENT                      │
    │                   (Month 6)                                  │
    │                                                              │
    │  • Token launch announced                                    │
    │  • Multiplier system revealed                                │
    │  • Snapshot date announced                                   │
    │  • Anti-sybil measures active                                │
    │                                                              │
    │  Eligibility:                                                │
    │  ✓ 14+ days activity                                         │
    │  ✓ Farcaster account 30+ days                                │
    │  ✓ Gitcoin Passport > 20                                     │
    │  ✓ Unique wallet                                             │
    │                                                              │
    └─────────────────────────────┬───────────────────────────────┘
                                  │
                                  ▼
    ┌─────────────────────────────────────────────────────────────┐
    │                   PHASE 4: DISTRIBUTION                      │
    │                   (Month 6-7)                                │
    │                                                              │
    │  Allocation:                                                 │
    │  ┌─────────────────────────────────────────────────────┐    │
    │  │  Early Adopters (30%)  │  Pre-announcement activity │    │
    │  │  Power Users (25%)     │  Top 10% by points         │    │
    │  │  Contributors (20%)    │  Approved content          │    │
    │  │  Referrers (15%)       │  Successful referrals      │    │
    │  │  Community (10%)       │  Weighted random           │    │
    │  └─────────────────────────────────────────────────────┘    │
    │                                                              │
    │  Formula: Points × Multiplier × Time Bonus = Allocation      │
    │                                                              │
    └─────────────────────────────────────────────────────────────┘
```

---

## 10. USER JOURNEY MAP (Viral Touchpoints)

```
    DISCOVERY          ONBOARDING          ENGAGEMENT          ADVOCACY
    ─────────          ──────────          ──────────          ─────────
    
    ┌─────┐           ┌─────┐            ┌─────┐            ┌─────┐
    │ FC  │           │ 1st │            │ 7d  │            │ 30d │
    │Cast │──────────→│Word │───────────→│Strk │───────────→│Refrr│
    │Frame│           │     │            │     │            │     │
    └─────┘           └─────┘            └─────┘            └─────┘
       │                 │                  │                  │
       │                 │                  │                  │
       ▼                 ▼                  ▼                  ▼
    [Click]           [Share]            [Share]            [Invite]
    Frame             Card               Streak             Friends
       │                 │                  │                  │
       │                 │                  │                  │
       ▼                 ▼                  ▼                  ▼
    +50 pts           +25 pts            +200 pts           +200/
                                               │           referral
                                               │                │
                                               ▼                ▼
                                          [Challenge]      [Tier Up]
                                              Win            Oracle
                                               │                │
                                               ▼                ▼
                                          +500 pts         Governance
                                                            + Revenue

    ═════════════════════════════════════════════════════════════════
    
    VIRAL TOUCHPOINTS BY STAGE:
    
    Discovery:   Frame embeds, recasts, channel presence
    Onboarding:  Share first revelation, referral invite
    Engagement:  Streak shares, challenge participation, leaderboard
    Advocacy:    Referral program, content submission, community building
```

---

## 11. ANTI-SYBIL PROTECTION FLOW

```
    ┌─────────────────────────────────────────────────────────────┐
    │                    SUSPICIOUS ACTIVITY                       │
    │                                                              │
    │  Pattern detected:                                           │
    │  • Multiple accounts, same IP                                │
    │  • Identical activity patterns                               │
    │  • Rapid-fire actions                                        │
    │  • No social graph connections                               │
    │                                                              │
    └─────────────────────────────┬───────────────────────────────┘
                                  │
                                  ▼
    ┌─────────────────────────────────────────────────────────────┐
    │                    VERIFICATION CHECKS                       │
    │                                                              │
    │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐          │
    │  │  Gitcoin    │  │  Farcaster  │  │  Behavioral │          │
    │  │  Passport   │  │   Account   │  │   Analysis  │          │
    │  │   Score     │  │    Age      │  │   Pattern   │          │
    │  └─────────────┘  └─────────────┘  └─────────────┘          │
    │         │               │               │                    │
    │         └───────────────┼───────────────┘                    │
    │                         │                                    │
    │                    [SCORING]                                 │
    │                         │                                    │
    │         ┌───────────────┴───────────────┐                    │
    │         │                               │                    │
    │         ▼                               ▼                    │
    │  ┌─────────────┐               ┌─────────────┐               │
    │  │   PASS      │               │    FAIL     │               │
    │  │  (Score>60) │               │  (Score<60) │               │
    │  └─────────────┘               └─────────────┘               │
    │                                         │                    │
    │                                         ▼                    │
    │                              ┌─────────────────────┐         │
    │                              │   ACTIONS:          │         │
    │                              │   • Points frozen   │         │
    │                              │   • Review required │         │
    │                              │   • Appeal process  │         │
    │                              │   • Ban if confirmed│         │
    │                              └─────────────────────┘         │
    │                                                              │
    └─────────────────────────────────────────────────────────────┘
```

---

*Visual Flows v1.0 - WYRD Viral Mechanics*
