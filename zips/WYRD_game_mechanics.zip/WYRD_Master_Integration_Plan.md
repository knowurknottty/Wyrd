# WYRD: Master Integration Plan
## Farcaster Mini-App with Zora Minting - Complete Implementation Guide

---

## Executive Summary

This document synthesizes comprehensive designs from a 5-specialist swarm to transform **WYRD** (Linguistic Liberation System) into an addictive, viral Farcaster mini-app with integrated Zora NFT minting.

### Project Overview

| Component | Description |
|-----------|-------------|
| **Core Game** | Etymology-based consciousness liberation through 4-step word analysis |
| **Platform** | Farcaster Mini-App (Frame v2) with full-screen web experience |
| **Blockchain** | Base L2 with Zora Creator Contracts |
| **Minting** | 222+ word NFTs with tiered rarity (Common → Legendary) |
| **Target** | 50,000 MAU within 12 months, K-factor > 1 |

### Key Innovations

1. **Linguistic Revelation Loops** - Mind-blowing etymology moments drive natural sharing
2. **Gasless Minting** - FREE NFTs via sponsored transactions (no wallet friction)
3. **Progressive Onboarding** - Wallet-optional entry, progressive feature unlocks
4. **Viral Mechanics** - 3-tap sharing, referral rewards, Farcaster-native distribution
5. **Ethical Design** - Light patterns only, no dark patterns, player wellbeing focus

---

## 1. INTEGRATED SYSTEM ARCHITECTURE

### 1.1 High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         FARCASTER ECOSYSTEM                              │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                     WYRD MINI-APP                                │   │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌────────┐ │   │
│  │  │  Daily  │  │  Word   │  │  Word   │  │ Profile │  │  Mint  │ │   │
│  │  │  Word   │  │ Scanner │  │ Analysis│  │  Page   │  │  Flow  │ │   │
│  │  └─────────┘  └─────────┘  └─────────┘  └─────────┘  └────────┘ │   │
│  │                                                                  │   │
│  │  ┌──────────────────────────────────────────────────────────┐   │   │
│  │  │              FRAME SDK INTEGRATION                        │   │   │
│  │  │  • Context (FID, username, PFP)                          │   │   │
│  │  │  • Wallet (EIP-1193 provider)                            │   │   │
│  │  │  • Actions (signIn, openUrl, close)                      │   │   │
│  │  │  • Notifications (daily word, streak alerts)             │   │   │
│  │  └──────────────────────────────────────────────────────────┘   │   │
│  └─────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                         WYRD BACKEND SERVICES                            │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐  │
│  │ Frame API│  │ Word Svc │  │ User Svc │  │  Notify  │  │  Share   │  │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘  └──────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
                                    │
                    ┌───────────────┼───────────────┐
                    ▼               ▼               ▼
            ┌──────────┐    ┌──────────┐    ┌──────────┐
            │  ZORA    │    │  IPFS    │    │  EAS     │
            │ PROTOCOL │    │ PINATA   │    │ ATTEST   │
            │          │    │          │    │          │
            │• ERC-1155│    │• Metadata│    │• Referral│
            │• Minting │    │• Images  │    │• Claims  │
            │• Rewards │    │          │    │          │
            └──────────┘    └──────────┘    └──────────┘
```

### 1.2 Contract Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    WYRD CONTRACT SUITE (Base L2)             │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  WYRD_WORDS (ERC-1155) - Zora Creator Contract       │   │
│  │  ├─ Token IDs 1-222: Core word collection            │   │
│  │  ├─ Token IDs 223+: Daily word editions              │   │
│  │  ├─ Multiple editions per word                       │   │
│  │  ├─ Configurable pricing per token                   │   │
│  │  └─ Soulbound achievement variants                   │   │
│  │                                                      │   │
│  │  RARITY TIERS:                                       │   │
│  │  • Common (White): 10,000 supply, FREE               │   │
│  │  • Rare (Blue): 1,000 supply, 0.001 ETH              │   │
│  │  • Mythic (Purple): 222 supply, 0.01 ETH             │   │
│  │  • Legendary (Gold): 22 supply, 0.1 ETH              │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  WYRD_ACHIEVEMENTS (ERC-1155)                        │   │
│  │  ├─ Soulbound badges (non-transferable)              │   │
│  │  ├─ Transferable rare badges                         │   │
│  │  └─ Automatic minting on achievement unlock          │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  WYRD_PASSES (ERC-721)                               │   │
│  │  ├─ Seeker Pass (30 days): 0.01 ETH                  │   │
│  │  ├─ Sage Pass (90 days): 0.025 ETH                   │   │
│  │  └─ Oracle Pass (Lifetime): 0.1 ETH                  │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

## 2. GAME MECHANICS INTEGRATION

### 2.1 Core Liberation Loop (Enhanced)

```
TRIGGER → ACTION → REWARD → INVESTMENT → MINT/SHARE
```

**Triggers:**
| Trigger | Timing | Psychology |
|---------|--------|------------|
| Daily Word | 9:00 AM UTC | Creates anticipation |
| Streak Alert | 8:00 PM (if not played) | Loss aversion |
| Curiosity Pulse | "Uncover the truth behind 'Democracy'" | Curiosity gap |
| Social Proof | "3 friends analyzed 'Propaganda' today" | FOMO |

**4-Step Analysis with Micro-Rewards:**
| Step | Duration | XP Reward | Interaction |
|------|----------|-----------|-------------|
| 1. Surface Reading | 30s | +5 XP | Read definition |
| 2. Root Excavation | 45-90s | +10 XP per root | Click to reveal deeper |
| 3. Semantic Shift | 60-120s | +15 XP | Drag timeline |
| 4. Liberation Angle | 60s+ | +25 XP base | Write insight |

**Completion Rewards:**
- Base: +50 XP + 1-3 Root Fragments
- Daily Word Bonus: +50% XP multiplier
- Streak Bonus: +10 XP (1-6d) → +200 XP (100d+)

### 2.2 Progression System (10 Levels)

| Level | Title | XP Required | Key Unlock |
|-------|-------|-------------|------------|
| 1 | Word Wanderer | 0 | Basic analysis |
| 2 | Root Seeker | 200 | Daily word access |
| 3 | Apprentice | 500 | Word scanner |
| 4 | Miner | 1,000 | Streak tracking, sharing |
| 5 | Language Liberator | 2,000 | Categories, profile customization |
| 6 | Scholar | 4,000 | Word suggestions, community features |
| 7 | Truth Tracer | 7,000 | Historical word packs |
| 8 | Cartographer | 12,000 | Expert categories, mentor status |
| 9 | Luminary | 20,000 | Beta features, exclusive content |
| 10 | Master of Liberation | 35,000 | Creator tools, immortalized status |

### 2.3 Achievement Badges (20+)

| Badge | Requirement | Rarity | NFT Type |
|-------|-------------|--------|----------|
| First Steps | Complete first word | Common | Soulbound |
| Daily Devotee | 7-day streak | Common | Soulbound |
| Week Warrior | 30-day streak | Uncommon | Transferable (1/1000) |
| Century Seeker | 365-day streak | Legendary | Transferable (1/100) |
| Lexical Legend | Analyze 1,000 words | Legendary | Transferable (1/50) |
| Inversion Detector | Find 25 inverted words | Rare | Transferable (1/500) |

---

## 3. FARCASTER INTEGRATION

### 3.1 Frame Manifest

```json
{
  "accountAssociation": {
    "header": "eyJmaWQiOjEyMzQsInR5cGUiOiJjdXN0b2R5Iiwia2V5IjoiMHh...",
    "payload": "eyJkb21haW4iOiJ3eXJkLmdhbWUifQ",
    "signature": "MHh..."
  },
  "frame": {
    "version": "1",
    "name": "WYRD - Linguistic Liberation",
    "iconUrl": "https://wyrd.game/icon.png",
    "homeUrl": "https://wyrd.game/frame/launch",
    "imageUrl": "https://wyrd.game/og-image.png",
    "buttonTitle": "Liberate Language",
    "splashImageUrl": "https://wyrd.game/splash.png",
    "splashBackgroundColor": "#1a1a2e",
    "subtitle": "Decode reality through etymology",
    "description": "A linguistic liberation system that reveals how language shapes consciousness through etymological analysis.",
    "primaryCategory": "entertainment",
    "tags": ["word-game", "etymology", "consciousness", "education"],
    "tagline": "Every word is a spell. Break it."
  }
}
```

### 3.2 Frame Routes

| Route | Purpose | Key Features |
|-------|---------|--------------|
| `/frame/launch` | Entry point | Splash screen, auth check |
| `/frame/daily` | Daily word challenge | Today's word, streak display |
| `/frame/word/[id]` | Individual word analysis | 4-step process |
| `/frame/scanner` | Word scanner | Input any word |
| `/frame/profile` | User stats | Level, streaks, collection |
| `/frame/share` | Share composition | Cast templates, preview |

### 3.3 Composer Actions

| Action | Icon | Description |
|--------|------|-------------|
| `wyrd_analyze` | search | Analyze any word from composer |
| `wyrd_daily` | calendar | Share today's daily challenge |
| `wyrd_challenge` | zap | Send challenge invites |
| `wyrd_liberate` | unlock | Quick liberation of common words |

### 3.4 Social Distribution

**Share Card Formats:**

**Format A: Revelation Card**
```
┌─────────────────────────────────────┐
│  🔮 WYRD REVELATION                 │
│                                     │
│  DISASTER                           │
│  ═══════════                        │
│                                     │
│  Surface: Catastrophic event        │
│                                     │
│  Root: dis (bad) + aster (star)     │
│                                     │
│  💫 The ancients blamed bad luck    │
│     on misaligned stars             │
│                                     │
│  [Unlock more at wyrd.game]         │
└─────────────────────────────────────┘
```

**Share Rewards:**
| Share Action | Points | Trigger |
|--------------|--------|---------|
| Complete analysis share | +25 WYRD | After word completion |
| Rare word discovery | +100 WYRD | <5% of users found |
| 7-day streak share | +200 WYRD | Streak milestone |
| Approved submission | +500 WYRD | Word contribution |

---

## 4. ZORA MINTING INTEGRATION

### 4.1 Mintable Assets

| Asset Type | Supply | Price | Purpose |
|------------|--------|-------|---------|
| **Common Words** | 10,000 | FREE | Onboarding |
| **Rare Words** | 1,000 | 0.001 ETH | Engagement |
| **Mythic Words** | 222 | 0.01 ETH | Premium |
| **Legendary Words** | 22 | 0.1 ETH | Exclusivity |
| **Daily Words** | 100/day | Free→0.0005 ETH | Retention |
| **Achievement Badges** | Variable | Soulbound/Transferable | Progression |

### 4.2 Reward Distribution (Per 0.01 ETH Mint)

```
Total Mint: 0.010000 ETH
├─ Zora Protocol Fee (25%): 0.002500 ETH
├─ Creator Reward (10%): 0.001000 ETH → WYRD Treasury
├─ Referrer Reward (5%): 0.000500 ETH
├─ First Minter Reward (2%): 0.000200 ETH
└─ WYRD Treasury (58%): 0.005800 ETH
```

### 4.3 Gasless Minting Architecture

```
USER ACTION → SPONSORED TX → RELAYER/PAYMASTER
(Tap "Mint")   (No gas fee)    (Covers gas)
                    │
                    ▼
              USER RECEIVES
               NFT (FREE)
```

**Implementation Options:**
1. ThirdWeb Gasless (recommended)
2. OpenZeppelin Defender Relayer
3. Custom Paymaster on Base

### 4.4 Mint Flow

**Step 1: Mint Preview**
```
╔═══════════════════════════════════════╗
║      P R O P A G A N D A              ║
║                                       ║
║  "That which spreads                  ║
║   without conscious choice"           ║
║                                       ║
║  Liberated by: @user                  ║
║  Day 47 of 365                        ║
╚═══════════════════════════════════════╝

MINT DETAILS:
• Network: Base (L2)
• Cost: FREE (gas sponsored)
• Edition: 1 of unlimited

[⚡ Mint Now - FREE]
```

**Step 2: Success State**
```
🎉 Successfully minted!

Your word liberation is now forever on-chain.

[View on BaseScan]  [Share]  [Add to Profile]
```

---

## 5. VIRAL LOOPS

### 5.1 Primary Viral Loops

**Loop 1: Share Loop**
```
Complete Analysis → Generate Share Card → Share to Farcaster
        ↑                                      │
        └──────────── New Users ───────────────┘
```
- Target: 0.4 shares per DAU
- Conversion: 15% of shares bring new users

**Loop 2: Referral Loop**
```
Existing User → Invite Link → New User Joins → Both Earn Rewards
     ↑                                              │
     └────────────── Referral Activity ─────────────┘
```
- Dual-sided rewards: Inviter +200 pts, New user +100 pts
- Tiered program: 6 tiers (Seeker → Archon)

**Loop 3: Content Loop**
```
User Plays → Has Insight → Submits Word → Community Votes
     ↑                                              │
     └────────────── Published Content ─────────────┘
```
- User-generated content flywheel
- Rewards: 1000 WYRD for approved submissions

### 5.2 Farcaster-Specific Viral Mechanics

**Frame Types:**
1. **Daily Word Frame** - "Today's word is [REDACTED]"
2. **Word Battle Frame** - "@alice challenges you!"
3. **Milestone Frame** - "10,000 words liberated!"

**Power Badge Benefits:**
- 2x points on all activities
- Early access (48h before public)
- Exclusive word pack
- 1.5x airdrop multiplier

### 5.3 Target Metrics

| Metric | Month 1 | Month 6 | Month 12 |
|--------|---------|---------|----------|
| DAU | 500 | 5,000 | 15,000 |
| K-factor | 0.3 | 0.9 | 1.2 |
| Referral % | 15% | 35% | 45% |
| D7 Retention | 25% | 40% | 45% |

---

## 6. UX FLOWS

### 6.1 Onboarding Flow (Progressive Disclosure)

**Screen 1: Welcome (3s)**
```
        W Y R D
       ─────────
       Linguistic
       Liberation
         System

"Words shape reality.
 Uncover their secrets."

[Begin Liberation]
```

**Screen 2: Tutorial Word (Guided)**
```
┌─────────────────────┐
│  TUTORIAL WORD      │
│  ═════════════════  │
│                     │
│      C O N T R O L  │
└─────────────────────┘

[👁️ STEP 1: Surface Read]
"What does 'control' mean to you?"

[Continue →]
```

**Screen 3: Completion**
```
🎉 Liberation Complete!

┌────────┐ ┌────────┐ ┌────────┐
│  +25   │ │  +10   │ │   🔥   │
│   XP   │ │ Insight│ │ Streak │
│        │ │ Points │ │   +1   │
└────────┘ └────────┘ └────────┘

[🎨 Mint NFT]  [📤 Share]  [🔍 Another]
```

### 6.2 Daily Word Flow (3-Tap Completion)

```
Tap 1: Open Daily Word
Tap 2: Complete 4-Step Analysis
Tap 3: Share/Mint
```

**Time-to-Value:**
- 0-3s: App loads
- 3-8s: Daily word displayed
- 8-15s: First etymology revealed
- 15-30s: Core insight delivered
- 30-60s: Liberation angle presented
- 60-120s: Completion + share options

### 6.3 Friction Reduction

| Flow | Taps | Steps |
|------|------|-------|
| Daily Word → Completion | 3 | Open → Analyze → Share |
| Word Scanner → Analysis | 3 | Scanner → Input → Submit |
| Share → Farcaster Post | 2 | Tap Share → Confirm |
| Mint → NFT Owned | 2 | Tap Mint → Confirm |

**Wallet Abstraction (Privy):**
- Email/Twitter/Farcaster auth
- Embedded smart wallet (auto-created)
- No seed phrases
- Optional export to external wallet

---

## 7. IMPLEMENTATION ROADMAP

### Phase 1: Foundation (Weeks 1-4)

| Week | Task | Deliverable |
|------|------|-------------|
| 1 | Frame SDK setup, manifest, layout | Working frame shell |
| 1 | XP system, progress bar | Gamification core |
| 2 | Basic word analysis (4 steps) | Core gameplay loop |
| 2 | Streak tracking | Retention mechanic |
| 3 | Daily word system | Daily engagement |
| 3 | Share cards, basic sharing | Viral loop v1 |
| 4 | Zora contract deployment | Minting infrastructure |
| 4 | Gasless minting integration | Frictionless minting |

### Phase 2: Social (Weeks 5-8)

| Week | Task | Deliverable |
|------|------|-------------|
| 5 | Referral system | Growth loop |
| 5 | Leaderboards | Social proof |
| 6 | Achievement badges | Progression |
| 6 | Farcaster composer actions | Native sharing |
| 7 | Word battles | Competitive feature |
| 7 | OG image generation | Beautiful shares |
| 8 | Notification system | Re-engagement |
| 8 | Channel bot (/wyrd) | Community hub |

### Phase 3: Scale (Weeks 9-12)

| Week | Task | Deliverable |
|------|------|-------------|
| 9 | Advanced frames (battles, milestones) | Rich social features |
| 9 | Power badge benefits | Influencer incentives |
| 10 | Quest system | Engagement loops |
| 10 | POAP integration | Engagement rewards |
| 11 | Word submission system | UGC flywheel |
| 11 | Dynamic pricing | Economic optimization |
| 12 | Airdrop preparation | Token launch prep |
| 12 | Analytics dashboard | Growth tracking |

### Resource Requirements

| Role | Phase 1 | Phase 2 | Phase 3 |
|------|---------|---------|---------|
| Frontend Dev | 1 FTE | 1 FTE | 1 FTE |
| Backend Dev | 0.5 FTE | 1 FTE | 1 FTE |
| Smart Contract | 0.25 FTE | 0.5 FTE | 0.5 FTE |
| Designer | 0.5 FTE | 0.5 FTE | 0.5 FTE |
| Community | 0.25 FTE | 0.5 FTE | 1 FTE |

---

## 8. TECHNICAL IMPLEMENTATION

### 8.1 Key Dependencies

```json
{
  "dependencies": {
    "@farcaster/miniapp-sdk": "^1.0.0",
    "@zoralabs/protocol-sdk": "^1.0.0",
    "@privy-io/react-auth": "^1.0.0",
    "viem": "^2.0.0",
    "wagmi": "^2.0.0",
    "pinata-sdk": "^1.0.0",
    "@coinbase/onchainkit": "^0.0.1"
  }
}
```

### 8.2 Environment Variables

```bash
# Farcaster
FARCASTER_NEYNAR_API_KEY=
FARCASTER_SIGNER_UUID=

# Zora
ZORA_CREATOR_CONTRACT_ADDRESS=
ZORA_API_KEY=

# Privy (Wallet Abstraction)
PRIVY_APP_ID=
PRIVY_APP_SECRET=

# IPFS (Pinata)
PINATA_JWT=
PINATA_GATEWAY=

# Base
BASE_RPC_URL=
BASE_SEPOLIA_RPC_URL=
```

### 8.3 Critical Code Patterns

**Frame SDK Hook:**
```typescript
// hooks/useFrameSDK.ts
import { sdk } from '@farcaster/miniapp-sdk';

export function useFrameSDK() {
  const [isInFrame, setIsInFrame] = useState(false);
  const [context, setContext] = useState<FrameContext | null>(null);

  useEffect(() => {
    const init = async () => {
      const inFrame = await sdk.isInMiniApp();
      setIsInFrame(inFrame);
      
      if (inFrame) {
        const ctx = await sdk.context;
        setContext(ctx);
        await sdk.actions.ready();
        
        // Set primary button
        await sdk.actions.setPrimaryButton({
          text: 'Liberate',
          enabled: true,
        });
      }
    };
    init();
  }, []);

  return { isInFrame, context };
}
```

**Zora Mint Hook:**
```typescript
// hooks/useMintWord.ts
import { useWriteContract, useWaitForTransactionReceipt } from 'wagmi';
import { collectorClient } from '@/lib/zora';

export function useMintWord() {
  const { writeContract, data: hash, isPending } = useWriteContract();
  const { isSuccess } = useWaitForTransactionReceipt({ hash });
  
  const mintWord = async (tokenId: number, referrer?: string) => {
    const { parameters } = await collectorClient.mint({
      minterAccount: address!,
      quantityToMint: 1,
      collection: WYRD_CONTRACT_ADDRESS,
      tokenId,
      mintType: '1155',
      mintReferral: referrer || ZERO_ADDRESS
    });
    
    writeContract({ ...parameters, value: mintCosts.totalCost });
  };
  
  return { mintWord, hash, isPending, isSuccess };
}
```

---

## 9. SUCCESS METRICS

### 9.1 Primary KPIs

| Metric | Target | Measurement |
|--------|--------|-------------|
| Day 1 Retention | 60%+ | Players returning next day |
| Day 7 Retention | 35%+ | Players returning after week |
| Day 30 Retention | 20%+ | Players returning after month |
| Avg Session Length | 5-10 min | Time per session |
| Words Analyzed (Month 1) | 50+ per user | Content consumption |

### 9.2 Blockchain Metrics

| Metric | Target |
|--------|--------|
| Monthly Mints | 2,250 |
| Mint Conversion Rate | 15% |
| Avg Mints per Player | 3 |
| Gasless Success Rate | 95%+ |

### 9.3 Viral Metrics

| Metric | Target |
|--------|--------|
| K-factor | 0.8 → 1.2 |
| Shares per DAU | 0.4 |
| Referral Conversion | 25% |
| Farcaster Channel Members | 5,000 |

---

## 10. ETHICAL DESIGN PRINCIPLES

### 10.1 Light Patterns (Embraced)

| Pattern | Implementation |
|---------|----------------|
| Autonomy | Players choose depth, categories, social engagement |
| Mastery | Clear skill progression, meaningful improvement |
| Purpose | Insights contribute to collective knowledge |
| Curiosity | Discovery mechanics reward exploration |
| Connection | Optional social features build community |
| Reflection | Analysis process encourages deep thinking |

### 10.2 Dark Patterns (Avoided)

| Dark Pattern | Why Avoided | Alternative |
|--------------|-------------|-------------|
| Pay-to-win | Creates inequality | All purchases cosmetic/convenience |
| Infinite scroll | Time sink, loss of control | Clear session endpoints |
| Artificial scarcity | Manufactured anxiety | Generous time windows |
| Social pressure | Damages relationships | Positive-only social features |
| Sleep disruption | Health harm | No late-night notifications |

### 10.3 Wellbeing Features

| Feature | Description |
|---------|-------------|
| Session Timer | Optional reminder after 20/40/60 minutes |
| Daily Limit | Soft cap at 10 words (can override) |
| Break Suggestions | Encourage breaks after long sessions |
| Streak Sanity | Weekend mode, generous protection |
| Notification Control | Granular control over all notifications |
| Pause Mode | Temporary disable all streaks/progress |
| Export Data | Players own their insights and progress |

---

## 11. GENERATED DOCUMENTS

| Document | Description | Path |
|----------|-------------|------|
| Game Mechanics Design | Comprehensive game systems | `/mnt/okcomputer/output/WYRD_Game_Mechanics_Design.md` |
| Farcaster Integration | Frame SDK technical spec | `/mnt/okcomputer/output/wyrd-farcaster-integration-spec.md` |
| Zora Minting Integration | NFT contract architecture | `/mnt/okcomputer/output/wyrd-zora-minting-integration.md` |
| Viral Loops Design | Growth strategy | `/mnt/okcomputer/output/WYRD_Viral_Loops_Design.md` |
| UX Flows Design | User experience flows | `/mnt/okcomputer/output/WYRD_UX_Flows_Design.md` |
| Frame Components | React component templates | `/mnt/okcomputer/output/wyrd-frame-components.tsx` |
| Frame API Routes | Server-side handlers | `/mnt/okcomputer/output/wyrd-frame-api-routes.ts` |
| Implementation Guide | Quick start guide | `/mnt/okcomputer/output/wyrd-frame-implementation-guide.md` |
| Viral Quick Reference | Copy-paste templates | `/mnt/okcomputer/output/WYRD_Viral_Quick_Reference.md` |
| Viral Flow Diagrams | ASCII flow diagrams | `/mnt/okcomputer/output/WYRD_Viral_Flows_Diagrams.md` |

---

## 12. NEXT STEPS

### Immediate Actions (This Week)

1. **Set up Farcaster Developer Account**
   - Register at https://developer.farcaster.xyz
   - Create frame manifest
   - Generate domain association

2. **Deploy Test Contracts**
   - Deploy WYRD_WORDS ERC-1155 on Base Sepolia
   - Configure Zora Creator Contracts
   - Test minting flow

3. **Initialize Frame Shell**
   - Set up Next.js project with Frame SDK
   - Create route structure
   - Implement basic layout

4. **Set up Infrastructure**
   - Configure Pinata for IPFS
   - Set up Privy for wallet abstraction
   - Deploy to Vercel/Netlify

### Week 2-4 Priorities

1. Implement core 4-step analysis flow
2. Build XP and progression system
3. Create share card generation
4. Integrate gasless minting
5. Launch private beta with 10 users

---

*Document Version: 1.0*
*Created by: WYRD Swarm (5 Specialist Agents)*
*Date: March 2026*
*Mission: Transform etymology into viral, onchain consciousness liberation*
