# WYRD Viral Loops - Quick Reference
## Implementation-Ready Summary

---

## 🎯 VIRAL COEFFICIENT TARGETS

| Phase | K-Factor | Timeline |
|-------|----------|----------|
| Launch | 0.3 | Month 1 |
| Growth | 0.6 | Month 3 |
| Scale | 0.9 | Month 6 |
| Mature | 1.2 | Month 12 |

---

## 📱 SHAREABLE MOMENTS

### Top 5 Share Triggers

| Rank | Trigger | Share Rate | Points Reward |
|------|---------|------------|---------------|
| 1 | Complete word analysis | 45% | +50 |
| 2 | Find rare word (<5% users) | 85% | +100 |
| 3 | 7-day streak complete | 70% | +200 |
| 4 | Discover word connection | 60% | +75 |
| 5 | Submit approved word | 90% | +500 |

### Share Card Templates (Copy-Paste Ready)

**Template 1: Revelation Card**
```
🔮 WYRD REVELATION

"{WORD}"

Surface: {surface_meaning}
Root: {etymology}
The twist: {liberation_angle}

Your mind = blown 🤯

→ wyrd.game/daily

@wyrd #LinguisticLiberation
```

**Template 2: Liberation Frame**
```
Just learned that "{WORD}" comes from {etymology}

My whole worldview shifted.

Discover more linguistic revelations at wyrd.game 🔮

#Etymology #WordOrigins #WYRD
```

**Template 3: Comparison Split**
```
WHAT YOU SEE → WHAT IT MEANS

{WORD} → {etymology}
{surface} → {liberation_angle}

Linguistic liberation via @wyrd 🔮
```

---

## 🔗 REFERRAL SYSTEM

### Dual-Sided Rewards

| Action | Inviter Gets | New User Gets |
|--------|--------------|---------------|
| Sign up | +200 pts | +100 pts |
| First word | +100 pts | +50 pts |
| 7-day streak | +500 pts | +250 pts |
| Submit word | +1000 pts | +500 pts |

### Referral Tiers

| Tier | Invites | Multiplier | Special Perk |
|------|---------|------------|--------------|
| Seeker | 0-2 | 1x | Basic link |
| Apprentice | 3-5 | 2x | Custom code |
| Scholar | 6-10 | 3x | Early access |
| Luminary | 11-25 | 4x | Exclusive POAP |
| Oracle | 26-50 | 5x | Governance |
| Archon | 51+ | 10x | Revenue share |

### Referral Code Format
```
WYRD-[USERNAME]-[NUMBER]
Example: WYRD-ALICE-042
```

---

## 🏆 ACHIEVEMENT BADGES

### Badge List (Implement in Order)

| Priority | Badge | Requirement | Rarity |
|----------|-------|-------------|--------|
| P0 | 🌱 First Step | Complete 1st word | Common |
| P0 | 🔥 Week Warrior | 7-day streak | Common |
| P1 | 💎 Century Club | 100 words | Uncommon |
| P1 | 🔮 Truth Seeker | 10 inversions | Rare |
| P2 | 🏛️ Etymologist | 5 approved words | Rare |
| P2 | 🌊 Viral Vector | 10 referrals | Epic |
| P3 | 👑 Liberator | All 222 words | Legendary |

---

## 💰 POINTS ECONOMY

### Points by Activity

| Activity | Points | Daily Cap |
|----------|--------|-----------|
| Word analysis | 50 | 500 |
| Share | 25 | 250 |
| Daily word | 100 | 100 |
| 7-day streak | 500 | 500 |
| 30-day streak | 2000 | 2000 |
| Referral signup | 200 | ∞ |
| Submit word | 1000 | 1000 |

### Points Utility (Immediate)
1. Leaderboard ranking
2. Exclusive word packs
3. Early feature access

### Points Utility (Future - Token)
1. Governance voting
2. Token allocation multiplier
3. Revenue share (Archon tier)

---

## 🎮 QUEST SYSTEM

### Quest Types to Implement

| Type | Example | Reward | Frequency |
|------|---------|--------|-----------|
| Daily | Analyze 3 words | 150 pts | Daily |
| Weekly | Find 5 Latin words | 500 pts | Weekly |
| Monthly | 30-day streak | 5000 pts | Monthly |
| One-time | Connect wallet | 100 pts | Once |
| Social | Share 5 times | 250 pts | Weekly |
| Creative | Submit word | 1000 pts | Unlimited |

### Quest UI Copy
```
📅 Daily Quest (Resets in {time})
[████████████░░░░░░░░] {progress}/{total}
Reward: {points} WYRD
```

---

## 🖼️ FARCASTER FRAMES

### Frame 1: Daily Word
```
🔮 WYRD DAILY

Today's word: [REDACTED]

[Reveal Origin] [Share Discovery]

{count} liberators today
```

### Frame 2: Word Battle
```
⚔️ WORD BATTLE

@{challenger} challenges you!

Word: "{WORD}"

[Accept] [Decline]

Winner gets 100 WYRD
```

### Frame 3: Milestone
```
🎉 MILESTONE UNLOCKED!

{ milestone_description }

You contributed {user_contribution} 🙌

[Claim POAP] [Share]
```

---

## 📊 LEADERBOARD CATEGORIES

Implement in this order:

1. **Daily Streak** (Real-time) - Most engaging
2. **Words Liberated** (Real-time) - Core metric
3. **Community Builder** (Daily) - Viral metric
4. **Knowledge Score** (Weekly) - Depth metric
5. **Word Contributor** (Weekly) - UGC metric

---

## 🎯 COMMUNITY CHALLENGES

### Challenge Template

```
THIS WEEK'S CHALLENGE

🔍 {Challenge Name}

{Description}

Your Progress: {user_progress}/{target}
[████████████████░░░░] {percentage}%

Community: {community_progress}/{community_target}
[████████████░░░░░░░░] {percentage}%

Reward: {points} WYRD + {POAP_name}
Time: {time_remaining}
```

### First 3 Challenges to Launch

1. **The Latin Hunt** - Find 50 Latin-root words
2. **Streak Challenge** - 100 users maintain 7-day streak
3. **Referral Sprint** - Most referrals in one week

---

## 🪙 POAP INTEGRATION

### Launch POAPs

| POAP | Requirement | Quantity |
|------|-------------|----------|
| Genesis Player | Play in Month 1 | ~500 |
| Streak Master | 30-day streak | Unlimited |
| Word Liberator | 100 words | Unlimited |
| Community Founder | 10 referrals | ~100 |

### POAP Distribution
- Via POAP app (standard)
- Via Farcaster frame (viral)
- Via email for non-FC users

---

## 📈 SUCCESS METRICS

### Track These Weekly

| Metric | Week 1 Target | Week 4 Target | Week 12 Target |
|--------|---------------|---------------|----------------|
| DAU | 100 | 500 | 2,000 |
| K-factor | 0.2 | 0.4 | 0.8 |
| Shares/Week | 20 | 200 | 1,000 |
| Referral Rate | 10% | 20% | 35% |
| D7 Retention | 20% | 30% | 40% |

---

## 🚀 IMPLEMENTATION PRIORITY

### Phase 1 (Weeks 1-4) - MUST HAVE
- [ ] Share cards (3 formats)
- [ ] Basic points system
- [ ] Referral links
- [ ] Daily streak
- [ ] Farcaster daily word frame
- [ ] /wyrd channel

### Phase 2 (Weeks 5-8) - SHOULD HAVE
- [ ] Quest system
- [ ] Community challenges
- [ ] Word submission
- [ ] Leaderboards
- [ ] Achievement badges
- [ ] POAP integration

### Phase 3 (Weeks 9-12) - NICE TO HAVE
- [ ] Word battles
- [ ] Advanced frames
- [ ] Power badge benefits
- [ ] Airdrop prep
- [ ] Tokenomics

---

## 📝 CONTENT CALENDAR (First Month)

### Week 1: Launch
- Day 1: Announcement cast + frame
- Day 3: First revelation thread
- Day 5: Community spotlight
- Day 7: Week 1 stats + celebrate

### Week 2: Engagement
- Daily: Word of the day
- Day 10: First challenge announce
- Day 12: Leaderboard reveal
- Day 14: Streak celebration

### Week 3: Growth
- Daily: Word + tip
- Day 17: Referral contest start
- Day 19: Community submission highlight
- Day 21: Milestone check-in

### Week 4: Retention
- Daily: Word + engagement question
- Day 24: Challenge winners
- Day 26: POAP announcement
- Day 28: Month 1 retrospective

---

## 🔧 TECHNICAL NOTES

### Share Card Specs
- Dimensions: 1200x630px (Twitter/Farcaster)
- Format: PNG with transparency option
- Font: System fonts (Inter, SF Pro)
- Colors: Brand palette

### Frame Requirements
- Aspect ratio: 1.91:1
- Max buttons: 4
- Post URL: Must return frame response
- State: Store in URL params

### Points System
- Store: PostgreSQL + Redis cache
- Real-time: WebSocket updates
- Anti-cheat: Rate limiting + validation

---

*Quick Reference v1.0 - For WYRD Implementation Team*
