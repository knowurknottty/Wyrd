// WYRD Frame API Routes - Server-side Implementation
// These routes handle frame validation, notifications, and word data

// ============================================
// 1. Frame Manifest Route
// ============================================
// File: app/frame/manifest.json/route.ts

import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
  const manifest = {
    accountAssociation: {
      header: process.env.FARCASTER_HEADER,
      payload: process.env.FARCASTER_PAYLOAD,
      signature: process.env.FARCASTER_SIGNATURE,
    },
    frame: {
      version: '1',
      name: 'WYRD - Linguistic Liberation',
      iconUrl: 'https://wyrd.game/icon.png',
      homeUrl: 'https://wyrd.game/frame/launch',
      imageUrl: 'https://wyrd.game/og-image.png',
      buttonTitle: 'Liberate Language',
      splashImageUrl: 'https://wyrd.game/splash.png',
      splashBackgroundColor: '#1a1a2e',
      subtitle: 'Decode reality through etymology',
      description:
        'A linguistic liberation system that reveals how language shapes consciousness through etymological analysis.',
      primaryCategory: 'entertainment',
      tags: ['word-game', 'etymology', 'consciousness', 'education'],
      heroImageUrl: 'https://wyrd.game/hero.png',
      tagline: 'Every word is a spell. Break it.',
      ogTitle: 'WYRD - Linguistic Liberation System',
      ogDescription: 'Decode the hidden meanings behind everyday language',
      ogImageUrl: 'https://wyrd.game/og-image.png',
    },
  };

  return NextResponse.json(manifest);
}

// ============================================
// 2. Frame Validation Route
// ============================================
// File: app/api/frame/validate/route.ts

import { NextRequest, NextResponse } from 'next/server';

interface FrameMessage {
  fid: number;
  timestamp: number;
  url: string;
  buttonIndex?: number;
  inputText?: string;
  state?: string;
  transactionId?: string;
  address?: string;
}

interface FrameRequest {
  untrustedData: FrameMessage;
  trustedData: {
    messageBytes: string;
  };
}

export async function POST(req: NextRequest) {
  try {
    const body: FrameRequest = await req.json();

    // Validate using Neynar
    const validationResponse = await fetch(
      'https://api.neynar.com/v2/farcaster/frame/validate',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'api_key': process.env.NEYNAR_API_KEY!,
        },
        body: JSON.stringify({
          message_bytes_in_hex: body.trustedData.messageBytes,
        }),
      }
    );

    const validation = await validationResponse.json();

    if (!validation.valid) {
      return NextResponse.json(
        { valid: false, error: 'Invalid frame message' },
        { status: 400 }
      );
    }

    // Verify timestamp (prevent replay attacks)
    const timestamp = body.untrustedData.timestamp;
    const now = Math.floor(Date.now() / 1000);
    const MAX_AGE = 5 * 60; // 5 minutes

    if (now - timestamp > MAX_AGE) {
      return NextResponse.json(
        { valid: false, error: 'Message expired' },
        { status: 400 }
      );
    }

    // Verify domain
    const url = new URL(body.untrustedData.url);
    if (url.hostname !== 'wyrd.game') {
      return NextResponse.json(
        { valid: false, error: 'Invalid domain' },
        { status: 400 }
      );
    }

    return NextResponse.json({
      valid: true,
      fid: validation.action?.interactor?.fid,
      username: validation.action?.interactor?.username,
    });
  } catch (error) {
    console.error('Frame validation error:', error);
    return NextResponse.json(
      { valid: false, error: 'Validation failed' },
      { status: 500 }
    );
  }
}

// ============================================
// 3. Notification Route
// ============================================
// File: app/api/frame/notify/route.ts

import { NextRequest, NextResponse } from 'next/server';

interface NotificationPayload {
  fid: number;
  title: string;
  body: string;
  notificationId: string;
}

export async function POST(req: NextRequest) {
  try {
    const payload: NotificationPayload = await req.json();

    // Validate required fields
    if (!payload.fid || !payload.title || !payload.body || !payload.notificationId) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // Store notification in database
    await storeNotification(payload);

    // Get user's notification token from database
    const userToken = await getUserNotificationToken(payload.fid);

    if (!userToken) {
      return NextResponse.json(
        { success: false, error: 'User not subscribed to notifications' },
        { status: 404 }
      );
    }

    // Send notification via Farcaster API
    const response = await fetch('https://api.warpcast.com/v1/notifications', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${process.env.WARPCAST_API_KEY}`,
      },
      body: JSON.stringify({
        targetFid: payload.fid,
        title: payload.title,
        body: payload.body,
        notificationId: payload.notificationId,
        token: userToken,
      }),
    });

    if (!response.ok) {
      throw new Error(`Notification API error: ${response.status}`);
    }

    // Update notification status
    await updateNotificationStatus(payload.notificationId, 'sent');

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Notification error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to send notification' },
      { status: 500 }
    );
  }
}

// Database helper functions (implement with your DB)
async function storeNotification(payload: NotificationPayload) {
  // Store in your database
  // Example: await db.notifications.create({ data: payload });
}

async function getUserNotificationToken(fid: number): Promise<string | null> {
  // Retrieve notification token from database
  // Example: return await db.users.findUnique({ where: { fid } }).notificationToken();
  return null;
}

async function updateNotificationStatus(notificationId: string, status: string) {
  // Update notification status in database
  // Example: await db.notifications.update({ where: { id: notificationId }, data: { status } });
}

// ============================================
// 4. Word API Routes
// ============================================
// File: app/api/words/[id]/route.ts

import { NextRequest, NextResponse } from 'next/server';

interface WordEntry {
  id: string;
  word: string;
  etymology: {
    roots: string[];
    origin: string;
    originalMeaning: string;
  };
  semanticShift: string;
  liberationAngle: string;
  category: string;
  difficulty: number;
}

// Mock database - replace with your actual data source
const wordDatabase: Record<string, WordEntry> = {
  'government': {
    id: 'government',
    word: 'government',
    etymology: {
      roots: ['gubernare', 'mente'],
      origin: 'Latin',
      originalMeaning: 'to steer/control the mind',
    },
    semanticShift:
      'Originally about mind control, now presented as public service',
    liberationAngle:
      'The word itself reveals its true purpose. When you see "government", remember: mind control.',
    category: 'control',
    difficulty: 2,
  },
  // Add more words...
};

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const wordId = params.id;
  const word = wordDatabase[wordId];

  if (!word) {
    return NextResponse.json(
      { error: 'Word not found' },
      { status: 404 }
    );
  }

  return NextResponse.json(word);
}

// ============================================
// 5. Word Search Route
// ============================================
// File: app/api/words/search/route.ts

import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const query = searchParams.get('q')?.toLowerCase();

  if (!query) {
    return NextResponse.json(
      { error: 'Query required' },
      { status: 400 }
    );
  }

  // Search in database
  const word = wordDatabase[query];

  if (word) {
    return NextResponse.json({
      found: true,
      wordId: word.id,
      word: word.word,
    });
  }

  // Return suggestions if exact match not found
  const suggestions = Object.values(wordDatabase)
    .filter((w) => w.word.includes(query) || query.includes(w.word))
    .slice(0, 5)
    .map((w) => ({ id: w.id, word: w.word }));

  return NextResponse.json({
    found: false,
    suggestions,
  });
}

// ============================================
// 6. Daily Word Route
// ============================================
// File: app/api/words/daily/route.ts

import { NextRequest, NextResponse } from 'next/server';

// Get daily word based on date
function getDailyWord(date: Date): WordEntry {
  const words = Object.values(wordDatabase);
  const dayOfYear = Math.floor(
    (date.getTime() - new Date(date.getFullYear(), 0, 0).getTime()) /
      (1000 * 60 * 60 * 24)
  );
  const wordIndex = dayOfYear % words.length;
  return words[wordIndex];
}

export async function GET(req: NextRequest) {
  const today = new Date();
  const dailyWord = getDailyWord(today);
  const dayNumber = Math.floor(
    (today.getTime() - new Date('2024-01-01').getTime()) /
      (1000 * 60 * 60 * 24)
  );

  return NextResponse.json({
    word: dailyWord,
    dayNumber,
    date: today.toISOString().split('T')[0],
  });
}

// ============================================
// 7. User Stats Route
// ============================================
// File: app/api/users/[fid]/stats/route.ts

import { NextRequest, NextResponse } from 'next/server';

interface UserStats {
  fid: number;
  username: string;
  displayName: string;
  pfpUrl?: string;
  liberationScore: number;
  wordsLiberated: number;
  currentStreak: number;
  longestStreak: number;
  recentDiscoveries: string[];
  badges: string[];
  joinedAt: string;
}

export async function GET(
  req: NextRequest,
  { params }: { params: { fid: string } }
) {
  const fid = parseInt(params.fid);

  if (isNaN(fid)) {
    return NextResponse.json(
      { error: 'Invalid FID' },
      { status: 400 }
    );
  }

  // Fetch user stats from database
  // This is a mock - implement with your actual database
  const stats: UserStats = await fetchUserStats(fid);

  return NextResponse.json(stats);
}

async function fetchUserStats(fid: number): Promise<UserStats> {
  // Implement with your database
  // Example using Prisma:
  // const user = await db.users.findUnique({
  //   where: { fid },
  //   include: { discoveries: true, badges: true }
  // });

  // Mock response
  return {
    fid,
    username: 'user' + fid,
    displayName: 'WYRD Liberator',
    pfpUrl: undefined,
    liberationScore: 1250,
    wordsLiberated: 12,
    currentStreak: 5,
    longestStreak: 10,
    recentDiscoveries: ['government', 'money', 'education'],
    badges: ['First Liberation', 'Week Warrior', 'Word Wizard'],
    joinedAt: new Date().toISOString(),
  };
}

// ============================================
// 8. Share/Analytics Route
// ============================================
// File: app/api/shares/route.ts

import { NextRequest, NextResponse } from 'next/server';

interface ShareEvent {
  fid: number;
  wordId: string;
  castHash?: string;
  timestamp: string;
  template: string;
}

export async function POST(req: NextRequest) {
  try {
    const event: ShareEvent = await req.json();

    // Validate
    if (!event.fid || !event.wordId) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // Store share event
    await storeShareEvent(event);

    // Update user's liberation score
    await updateLiberationScore(event.fid, 10); // +10 points for sharing

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Share tracking error:', error);
    return NextResponse.json(
      { error: 'Failed to track share' },
      { status: 500 }
    );
  }
}

async function storeShareEvent(event: ShareEvent) {
  // Store in database
  // await db.shares.create({ data: event });
}

async function updateLiberationScore(fid: number, points: number) {
  // Update user score
  // await db.users.update({
  //   where: { fid },
  //   data: { liberationScore: { increment: points } }
  // });
}

// ============================================
// 9. OG Image Generation Route
// ============================================
// File: app/api/og/word/[id]/route.ts

import { ImageResponse } from 'next/og';
import { NextRequest } from 'next/server';

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const wordId = params.id;
  const word = wordDatabase[wordId];

  if (!word) {
    return new ImageResponse(
      (
        <div
          style={{
            fontSize: 40,
            color: 'white',
            background: '#1a1a2e',
            width: '100%',
            height: '100%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          Word not found
        </div>
      ),
      {
        width: 1200,
        height: 630,
      }
    );
  }

  return new ImageResponse(
    (
      <div
        style={{
          fontSize: 60,
          color: 'white',
          background: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)',
          width: '100%',
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          padding: 40,
        }}
      >
        <div style={{ fontSize: 30, color: '#a855f7', marginBottom: 20 }}>
          WYRD - Linguistic Liberation
        </div>
        <div
          style={{
            fontSize: 100,
            fontWeight: 'bold',
            background: 'linear-gradient(90deg, #a855f7, #ec4899)',
            backgroundClip: 'text',
            color: 'transparent',
          }}
        >
          {word.word}
        </div>
        <div style={{ fontSize: 30, color: '#9ca3af', marginTop: 20 }}>
          {word.etymology.origin}: {word.etymology.originalMeaning}
        </div>
        <div style={{ fontSize: 24, color: '#a855f7', marginTop: 40 }}>
          🔓 Click to liberate this word
        </div>
      </div>
    ),
    {
      width: 1200,
      height: 630,
    }
  );
}

// ============================================
// 10. Composer Action Route
// ============================================
// File: app/api/composer/route.ts

import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  // Return form configuration for Warpcast composer
  return NextResponse.json({
    type: 'form',
    title: 'Analyze Word with WYRD',
    url: 'https://wyrd.game/frame/scanner?composer=true',
  });
}

export async function GET(req: NextRequest) {
  // Return action metadata
  return NextResponse.json({
    type: 'composer',
    name: 'WYRD Word Analysis',
    icon: 'search',
    description: 'Analyze any word through the lens of etymology and liberation',
    aboutUrl: 'https://wyrd.game/about',
    imageUrl: 'https://wyrd.game/composer-icon.png',
    action: {
      type: 'post',
    },
  });
}

// ============================================
// 11. Challenge Invite Route
// ============================================
// File: app/api/challenges/route.ts

import { NextRequest, NextResponse } from 'next/server';

interface ChallengeInvite {
  id: string;
  challengerFid: number;
  targetFid?: number;
  wordId: string;
  createdAt: string;
  expiresAt: string;
  status: 'pending' | 'accepted' | 'completed';
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { challengerFid, targetFid, wordId } = body;

    if (!challengerFid || !wordId) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    const challenge: ChallengeInvite = {
      id: crypto.randomUUID(),
      challengerFid,
      targetFid,
      wordId,
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
      status: 'pending',
    };

    // Store challenge
    await storeChallenge(challenge);

    // Send notification if target specified
    if (targetFid) {
      await sendChallengeNotification(targetFid, challengerFid, wordId);
    }

    return NextResponse.json({
      success: true,
      challengeId: challenge.id,
      shareUrl: `https://wyrd.game/frame/challenge/${challenge.id}`,
    });
  } catch (error) {
    console.error('Challenge creation error:', error);
    return NextResponse.json(
      { error: 'Failed to create challenge' },
      { status: 500 }
    );
  }
}

async function storeChallenge(challenge: ChallengeInvite) {
  // Store in database
  // await db.challenges.create({ data: challenge });
}

async function sendChallengeNotification(
  targetFid: number,
  challengerFid: number,
  wordId: string
) {
  // Get challenger username
  const challenger = await getUserByFid(challengerFid);

  // Send notification
  await fetch('/api/frame/notify', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      fid: targetFid,
      title: '🎯 Challenge Received!',
      body: `${challenger?.username || 'Someone'} challenged you to liberate "${wordId}"`,
      notificationId: `challenge-${Date.now()}`,
    }),
  });
}

async function getUserByFid(fid: number) {
  // Fetch from database
  // return await db.users.findUnique({ where: { fid } });
  return { username: 'user' + fid };
}
