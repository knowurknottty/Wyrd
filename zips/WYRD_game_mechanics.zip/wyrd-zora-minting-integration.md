# WYRD: Zora Minting Integration Design
## Comprehensive Technical Specification

---

## Executive Summary

This document outlines a complete Zora minting integration strategy for WYRD, transforming the etymology game into a collectible, shareable, and economically sustainable onchain experience. The design leverages Zora's Creator Contracts, reward mechanisms, and Farcaster integration to create viral loops while maintaining the game's consciousness-liberation ethos.

---

## 1. MINTABLE ASSETS DESIGN

### 1.1 Asset Categories

#### A. Word Discoveries (Primary Collection)
**Concept:** Each of the 222+ word entries becomes a mintable NFT

| Asset Type | Description | Edition Size | Pricing |
|------------|-------------|--------------|---------|
| **Common Words** | Basic etymology entries | Open/10,000 | Free |
| **Rare Words** | Words with profound semantic shifts | 1,000 | 0.001 ETH |
| **Mythic Words** | Words tied to consciousness liberation | 222 | 0.01 ETH |
| **Legendary Words** | Founder/curated special words | 22 | 0.1 ETH |

**Metadata Structure:**
```json
{
  "name": "WYRD: Liberation of 'Authority'",
  "description": "A linguistic excavation revealing how 'authority' derives from Latin 'auctoritas' - the power to originate, create, and give increase.",
  "image": "ipfs://...",
  "animation_url": "ipfs://...",
  "attributes": [
    { "trait_type": "Word", "value": "Authority" },
    { "trait_type": "Rarity", "value": "Mythic" },
    { "trait_type": "Language Family", "value": "Latin" },
    { "trait_type": "Liberation Angle", "value": "Power Reclamation" },
    { "trait_type": "Semantic Shift", "value": "Creator → Controller" },
    { "trait_type": "Root Depth", "value": 3 },
    { "trait_type": "Inversion Detected", "value": true },
    { "trait_type": "Minted By", "value": "0x..." },
    { "trait_type": "Discovery Date", "display_type": "date", "value": 1704067200 }
  ],
  "properties": {
    "etymology": {
      "original_root": "auctor",
      "root_meaning": "originator, promoter, author",
      "evolution_path": ["auctor", "auctoritas", "autorite", "authority"],
      "liberation_insight": "To reclaim authority is to reclaim authorship of your own reality"
    },
    "game_data": {
      "word_id": "auth_001",
      "completion_steps": 4,
      "time_to_complete": 180,
      "hints_used": 0
    }
  }
}
```

#### B. Achievement Badges (Secondary Collection)
**Concept:** Soulbound/transferable badges for game milestones

| Badge | Criteria | Type |
|-------|----------|------|
| **First Word** | Complete first etymology | Soulbound |
| **Linguistic Archaeologist** | Complete 10 words | Soulbound |
| **Root Master** | Complete 50 words | Soulbound |
| **Etymology Sage** | Complete 100 words | Soulbound |
| **Word Wizard** | Complete all 222 words | Soulbound |
| **Daily Devotee** | 7-day streak | Transferable (1/1000) |
| **Inversion Hunter** | Find 25 inverted meanings | Transferable (1/500) |
| **Speed Reader** | Complete word in <30 seconds | Transferable (1/100) |
| **Perfect Score** | Complete without hints | Transferable (1/50) |

#### C. Daily Word Collectibles
**Concept:** Limited edition of each day's featured word

- **Supply:** 24-hour mint window OR 100 editions max
- **Pricing:** Free for first 10, 0.0005 ETH thereafter
- **Special trait:** Includes date stamp, making each day unique

#### D. Season Passes (ERC-721)
**Concept:** Time-limited access passes with benefits

| Pass Type | Duration | Benefits | Price |
|-----------|----------|----------|-------|
| **Seeker Pass** | 30 days | 2x rewards, exclusive words | 0.01 ETH |
| **Sage Pass** | 90 days | 3x rewards, early access, creator share | 0.025 ETH |
| **Oracle Pass** | Lifetime | All benefits + governance rights | 0.1 ETH |

---

### 1.2 Visual Design Suggestions

#### NFT Art Direction

**Theme:** "Excavated Manuscripts" - Ancient texts meeting digital consciousness

**Visual Layers:**
1. **Background:** Parchment/aged paper textures with subtle blockchain patterns
2. **Word Display:** Large, elegant typography with etymology roots highlighted
3. **Root Visualization:** Tree/branch imagery showing word evolution
4. **Rarity Indicators:** 
   - Common: Sepia tones
   - Rare: Deep blues/purples
   - Mythic: Gold accents with animated elements
   - Legendary: Full animation, holographic effects

**Animation Concept:**
- Words "excavate" themselves - starting obscured, revealing through the 4 game steps
- Root words glow and connect to modern meanings
- Liberation angle creates a burst of light/energy

**Generative Elements:**
- Each NFT has unique background patterns based on word hash
- Color palette shifts based on language family
- Rarity affects particle effects and glow intensity

---

## 2. CONTRACT STRATEGY

### 2.1 ERC-1155 vs ERC-721 Analysis

| Factor | ERC-721 | ERC-1155 | Recommendation |
|--------|---------|----------|----------------|
| **Gas Efficiency** | Higher per mint | Batch mint capable | ERC-1155 |
| **Multiple Editions** | One contract per edition | Single contract, multiple tokens | ERC-1155 |
| **Soulbound Support** | Requires custom | Native support via transfers | ERC-1155 |
| **Complexity** | Simpler | More complex | ERC-721 for passes |
| **Market Compatibility** | Universal | Growing support | Both acceptable |

### 2.2 Recommended Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    WYRD CONTRACT SUITE                       │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  WYRD_WORDS (ERC-1155)                               │   │
│  │  - 222+ word tokens (token IDs 1-222+)               │   │
│  │  - Multiple editions per word                        │   │
│  │  - Configurable pricing per token                    │   │
│  │  - Soulbound achievement variants                    │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  WYRD_ACHIEVEMENTS (ERC-1155)                        │   │
│  │  - Soulbound badges (non-transferable)               │   │
│  │  - Transferable rare badges                          │   │
│  │  - Automatic minting on achievement unlock           │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  WYRD_PASSES (ERC-721)                               │   │
│  │  - Season passes with utility                        │   │
│  │  - On-chain benefits verification                    │   │
│  │  - Time-locked or permanent                          │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### 2.3 Zora Creator Contract Setup

**Primary Contract: WYRD_WORDS (ERC-1155)**

```solidity
// Using Zora's Creator Contracts
import {ZoraCreator1155Impl} from "@zoralabs/creator-contracts/contracts/nft/ZoraCreator1155Impl.sol";

contract WYRD_WORDS is ZoraCreator1155Impl {
    
    // Token ID structure:
    // 1-222: Core word collection
    // 223-300: Reserved for expansion
    // 1000+: Daily word editions
    // 10000+: Achievement badges
    
    struct WordConfig {
        string word;
        uint8 rarity; // 1=Common, 2=Rare, 3=Mythic, 4=Legendary
        uint256 maxSupply;
        uint256 price;
        bool isSoulbound;
        uint256 unlockTimestamp;
    }
    
    mapping(uint256 => WordConfig) public wordConfigs;
    mapping(uint256 => uint256) public mintedCount;
    
    // Zora reward configuration
    uint256 public constant MINT_FEE = 0.000777 ether; // Zora protocol fee
    uint256 public creatorRewardBPS = 1000; // 10% to creator
    uint256 public referralRewardBPS = 500; // 5% to referrer
    
    function mintWord(
        uint256 tokenId,
        uint256 quantity,
        address recipient,
        address referrer
    ) external payable {
        WordConfig memory config = wordConfigs[tokenId];
        
        require(block.timestamp >= config.unlockTimestamp, "Word not yet unlocked");
        require(mintedCount[tokenId] + quantity <= config.maxSupply, "Exceeds max supply");
        require(msg.value >= config.price * quantity, "Insufficient payment");
        
        // Handle Zora fees and rewards
        _distributeRewards(msg.value, referrer);
        
        _mint(recipient, tokenId, quantity, "");
        mintedCount[tokenId] += quantity;
        
        emit WordMinted(tokenId, recipient, quantity, referrer);
    }
    
    function _distributeRewards(uint256 amount, address referrer) internal {
        // Zora protocol fee
        uint256 zoraFee = amount * 2500 / 10000; // 25%
        
        // Referrer reward (if valid)
        uint256 referralReward = 0;
        if (referrer != address(0) && referrer != msg.sender) {
            referralReward = amount * referralRewardBPS / 10000;
            payable(referrer).transfer(referralReward);
        }
        
        // Creator reward
        uint256 creatorReward = amount * creatorRewardBPS / 10000;
        payable(owner()).transfer(creatorReward);
        
        // Remainder to treasury
        uint256 remainder = amount - zoraFee - referralReward - creatorReward;
        payable(treasury).transfer(remainder);
    }
}
```

---

## 3. MINTING MECHANICS

### 3.1 Free vs Paid Mint Strategy

#### Tiered Access Model

```
┌─────────────────────────────────────────────────────────────┐
│                    MINT ACCESS TIERS                         │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  TIER 1: FREE MINT                                           │
│  ├─ First 3 words per wallet (onboarding)                   │
│  ├─ Daily word (first 10 minters)                           │
│  ├─ Achievement badges (soulbound)                          │
│  └─ Referral rewards (mint credits)                         │
│                                                              │
│  TIER 2: LOW COST (0.0005 - 0.001 ETH)                       │
│  ├─ Common words beyond first 3                             │
│  ├─ Daily word after first 10                               │
│  ├─ Transferable badges                                     │
│  └─ Bulk mint discounts                                     │
│                                                              │
│  TIER 3: PREMIUM (0.01 - 0.1 ETH)                            │
│  ├─ Rare, Mythic, Legendary words                           │
│  ├─ Limited edition collaborations                          │
│  ├─ Season passes                                           │
│  └─ Exclusive content access                                │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

#### Dynamic Pricing Models

**1. Time-Based Pricing**
```javascript
// Price decreases over time to encourage minting
function calculateDynamicPrice(basePrice, mintStartTime, currentTime) {
    const hoursElapsed = (currentTime - mintStartTime) / 3600;
    const discountFactor = Math.min(hoursElapsed * 0.05, 0.5); // Max 50% discount
    return basePrice * (1 - discountFactor);
}
```

**2. Supply-Based Pricing (Bonding Curve)**
```javascript
// Price increases as supply decreases
function calculateBondingCurvePrice(basePrice, minted, maxSupply) {
    const scarcityRatio = minted / maxSupply;
    const multiplier = 1 + (scarcityRatio * scarcityRatio * 2); // Quadratic curve
    return basePrice * multiplier;
}
```

**3. Streak-Based Discounts**
- 3-day streak: 10% off
- 7-day streak: 25% off
- 30-day streak: 50% off + free daily words

### 3.2 Edition Sizes and Scarcity

| Rarity | Words | Max Supply | Mint Window | Pricing Model |
|--------|-------|------------|-------------|---------------|
| Common | ~150 | 10,000 | Unlimited | Fixed low |
| Rare | ~50 | 1,000 | 30 days | Bonding curve |
| Mythic | ~20 | 222 | 14 days | Dynamic + bonding |
| Legendary | ~5 | 22 | 7 days | Auction/Dutch |
| Daily | 1/day | 100 | 24 hours | First 10 free |

**Scarcity Mechanics:**
- **Burn to Reveal:** Some words require burning a common to unlock rare
- **Set Completion:** Collect full language families for bonus rewards
- **Time Capsules:** Certain words only available during specific periods

---

## 4. REFERRAL & REWARDS SYSTEM

### 4.1 Zora Referral Integration

Zora's native referral system allows anyone to earn rewards by sharing mint links:

```javascript
// Zora SDK referral pattern
import { useAccount, useWriteContract } from 'wagmi';

function createReferralMintLink(wordId, referrerAddress) {
    // Generate shareable link with embedded referrer
    const baseUrl = "https://wyrd.game/mint";
    const params = new URLSearchParams({
        word: wordId,
        ref: referrerAddress
    });
    return `${baseUrl}?${params.toString()}`;
}

// In mint function
async function mintWithReferral(wordId, quantity, referrer) {
    const { writeContract } = useWriteContract();
    
    await writeContract({
        address: WYRD_CONTRACT_ADDRESS,
        abi: WYRD_ABI,
        functionName: 'mintWord',
        args: [wordId, quantity, recipient, referrer],
        value: calculatePrice(wordId, quantity)
    });
}
```

### 4.2 Reward Distribution

```
┌─────────────────────────────────────────────────────────────┐
│                  REWARD FLOW (Per 0.01 ETH Mint)             │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Total Mint: 0.010000 ETH                                   │
│  ├─ Zora Protocol Fee (25%): 0.002500 ETH                  │
│  ├─ Creator Reward (10%): 0.001000 ETH → WYRD Treasury     │
│  ├─ Referrer Reward (5%): 0.000500 ETH → Referrer          │
│  ├─ First Minter Reward (2%): 0.000200 ETH → First Minter  │
│  └─ WYRD Treasury (58%): 0.005800 ETH → Development        │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### 4.3 First Minter Rewards

**Concept:** Reward early adopters who discover words first

```solidity
mapping(uint256 => address) public firstMinter;
mapping(uint256 => uint256) public firstMinterReward;

function mintWord(uint256 tokenId, ...) external payable {
    // ... existing mint logic ...
    
    // First minter logic
    if (firstMinter[tokenId] == address(0)) {
        firstMinter[tokenId] = recipient;
        firstMinterReward[tokenId] = msg.value * 200 / 10000; // 2%
        
        // Mint a special "First Discoverer" badge
        _mint(recipient, FIRST_DISCOVERER_BADGE_ID, 1, "");
        
        emit FirstMint(tokenId, recipient, firstMinterReward[tokenId]);
    }
}

// Claim first minter rewards (after word sells out or time passes)
function claimFirstMinterReward(uint256 tokenId) external {
    require(msg.sender == firstMinter[tokenId], "Not first minter");
    require(mintedCount[tokenId] == wordConfigs[tokenId].maxSupply, "Not sold out");
    
    uint256 reward = firstMinterReward[tokenId];
    firstMinterReward[tokenId] = 0;
    payable(msg.sender).transfer(reward);
}
```

### 4.4 Creator Rewards Setup

**Zora Creator Rewards Configuration:**

```javascript
// Configure Zora rewards
const rewardConfig = {
    // Creator splits
    creators: [
        { address: "0x...WYRD_TREASURY", share: 70 },
        { address: "0x...GAME_DESIGNER", share: 20 },
        { address: "0x...COMMUNITY_FUND", share: 10 }
    ],
    
    // Reward triggers
    rewardTriggers: {
        onMint: true,
        onSecondarySale: true,
        onReferral: true
    },
    
    // Secondary market royalties
    royaltyBPS: 500, // 5%
    
    // Mint referral reward
    mintReferralReward: 500, // 5% of mint price
    
    // Creator reward
    creatorReward: 1000 // 10% of mint price
};
```

---

## 5. FARCASTER INTEGRATION

### 5.1 Frame-Based Minting

**Frame Structure:**

```
┌─────────────────────────────────────────────────────────────┐
│                    WYRD MINT FRAME                           │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │                                                      │   │
│  │              [WORD: AUTHORITY]                       │   │
│  │                                                      │   │
│  │         ┌─────────────────────────┐                  │   │
│  │         │   NFT PREVIEW IMAGE     │                  │   │
│  │         │   (Generative Art)      │                  │   │
│  │         └─────────────────────────┘                  │   │
│  │                                                      │   │
│  │   "Authority: from Latin 'auctor' - originator"     │   │
│  │                                                      │   │
│  │   Rarity: Mythic  |  47/222 Minted  |  0.01 ETH     │   │
│  │                                                      │   │
│  ├──────────────────────────────────────────────────────┤   │
│  │  [🔍 View Etymology]  [💎 Mint (0.01 ETH)]          │   │
│  │                                                      │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

**Frame Implementation:**

```typescript
// app/api/frame/route.ts
import { FrameRequest, getFrameMessage } from '@coinbase/onchainkit';
import { NextResponse } from 'next/server';

export async function POST(req: Request) {
    const body: FrameRequest = await req.json();
    const { isValid, message } = await getFrameMessage(body);
    
    if (!isValid) return new NextResponse('Invalid frame', { status: 400 });
    
    const buttonIndex = message.button;
    const wordId = message.state?.wordId;
    const referrer = message.state?.referrer;
    
    if (buttonIndex === 1) {
        // View etymology - show expanded frame
        return showEtymologyFrame(wordId);
    } else if (buttonIndex === 2) {
        // Initiate mint - return transaction frame
        return createMintTransactionFrame(wordId, referrer);
    }
}

function createMintTransactionFrame(wordId: string, referrer: string) {
    return NextResponse.json({
        chainId: 'eip155:8453', // Base
        method: 'eth_sendTransaction',
        params: {
            abi: WYRD_ABI,
            to: WYRD_CONTRACT,
            data: encodeMintData(wordId, referrer),
            value: getWordPrice(wordId)
        },
        state: { wordId, referrer },
        postUrl: `${BASE_URL}/api/frame/confirm`
    });
}
```

### 5.2 Share-to-Mint Mechanics

**Viral Loop Design:**

```
┌─────────────────────────────────────────────────────────────┐
│                  SHARE-TO-MINT FLOW                          │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  1. Player completes word etymology                         │
│         ↓                                                    │
│  2. "Mint Your Discovery" prompt appears                    │
│         ↓                                                    │
│  3. Generate personalized share frame                       │
│     - Includes player's discovery quote                     │
│     - Shows word + rarity                                   │
│     - Embeds referral code                                  │
│         ↓                                                    │
│  4. Share to Farcaster/Twitter                              │
│         ↓                                                    │
│  5. Others mint through shared link                         │
│         ↓                                                    │
│  6. Original sharer earns:                                  │
│     - 5% referral reward                                    │
│     - "Word Evangelist" badge progress                      │
│     - Leaderboard points                                    │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

**Social Proof Integration:**

```typescript
// Generate personalized share image
async function generateShareImage(wordData, playerData) {
    const canvas = createCanvas(1200, 630);
    const ctx = canvas.getContext('2d');
    
    // Background
    ctx.fillStyle = getRarityColor(wordData.rarity);
    ctx.fillRect(0, 0, 1200, 630);
    
    // Word
    ctx.font = 'bold 80px serif';
    ctx.fillStyle = '#fff';
    ctx.textAlign = 'center';
    ctx.fillText(wordData.word, 600, 200);
    
    // Etymology snippet
    ctx.font = 'italic 36px serif';
    ctx.fillText(`"${wordData.root}" → "${wordData.modern}"`, 600, 300);
    
    // Player insight
    ctx.font = '28px sans-serif';
    ctx.fillText(`Discovered by ${playerData.ens || truncate(playerData.address)}`, 600, 450);
    
    // WYRD branding
    ctx.font = 'bold 40px sans-serif';
    ctx.fillText('WYRD: Linguistic Liberation', 600, 550);
    
    return canvas.toBuffer('png');
}
```

### 5.3 Farcaster-Specific Features

**1. Cast Action Integration**
```typescript
// Allow users to mint directly from any cast
export const castActionConfig = {
    name: "Mint WYRD Word",
    icon: "book",
    description: "Mint the word from this cast",
    aboutUrl: "https://wyrd.game",
    action: {
        type: "post",
        postUrl: "https://wyrd.game/api/cast-action/mint"
    }
};
```

**2. Channel Integration**
- Dedicated `/wyrd` channel for game discussions
- Automatic word reveals in channel
- Community challenges with shared rewards

---

## 6. TECHNICAL IMPLEMENTATION

### 6.1 Zora SDK Integration

**Installation:**
```bash
npm install @zoralabs/protocol-sdk viem wagmi
```

**SDK Setup:**
```typescript
// lib/zora.ts
import { createPublicClient, http } from 'viem';
import { base } from 'viem/chains';
import { createCollectorClient } from '@zoralabs/protocol-sdk';

const publicClient = createPublicClient({
    chain: base,
    transport: http()
});

export const collectorClient = createCollectorClient({
    chainId: base.id,
    publicClient
});
```

**Mint Function:**
```typescript
// hooks/useMintWord.ts
import { useAccount, useWriteContract, useWaitForTransactionReceipt } from 'wagmi';
import { collectorClient } from '@/lib/zora';
import { parseEther } from 'viem';

export function useMintWord() {
    const { address } = useAccount();
    const { writeContract, data: hash, isPending } = useWriteContract();
    const { isLoading: isConfirming, isSuccess } = useWaitForTransactionReceipt({ hash });
    
    const mintWord = async (tokenId: number, quantity: number, referrer?: string) => {
        // Get mint costs from Zora SDK
        const mintCosts = await collectorClient.getMintCosts({
            collection: WYRD_CONTRACT_ADDRESS,
            tokenId,
            quantityMinted: quantity,
            mintType: '1155'
        });
        
        // Get mint parameters
        const { parameters } = await collectorClient.mint({
            minterAccount: address!,
            quantityToMint: quantity,
            collection: WYRD_CONTRACT_ADDRESS,
            tokenId,
            mintType: '1155',
            mintReferral: referrer || ZERO_ADDRESS
        });
        
        // Execute mint
        writeContract({
            ...parameters,
            value: mintCosts.totalCost
        });
    };
    
    return { mintWord, hash, isPending, isConfirming, isSuccess };
}
```

### 6.2 Mint Transaction Flow

```
┌─────────────────────────────────────────────────────────────┐
│                    MINT TRANSACTION FLOW                     │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────┐    ┌──────────┐    ┌──────────┐              │
│  │  User    │───▶│  Frontend│───▶│  Zora SDK│              │
│  │  Action  │    │  React   │    │  Client  │              │
│  └──────────┘    └──────────┘    └──────────┘              │
│       │               │               │                      │
│       │               │               │                      │
│       │               │               ▼                      │
│       │               │        ┌──────────┐                  │
│       │               │        │  Get Mint│                  │
│       │               │        │  Costs   │                  │
│       │               │        └──────────┘                  │
│       │               │               │                      │
│       │               │               ▼                      │
│       │               │        ┌──────────┐                  │
│       │               │        │  Get Mint│                  │
│       │               │        │  Params  │                  │
│       │               │        └──────────┘                  │
│       │               │               │                      │
│       ▼               ▼               ▼                      │
│  ┌──────────────────────────────────────────┐               │
│  │           Wallet Confirmation             │               │
│  │    (MetaMask, Rainbow, Coinbase, etc.)   │               │
│  └──────────────────────────────────────────┘               │
│       │                                                      │
│       ▼                                                      │
│  ┌──────────────────────────────────────────┐               │
│  │         Blockchain Transaction            │               │
│  │    ├─ Validate payment                   │               │
│  │    ├─ Distribute fees                    │               │
│  │    ├─ Mint NFT                           │               │
│  │    └─ Emit events                        │               │
│  └──────────────────────────────────────────┘               │
│       │                                                      │
│       ▼                                                      │
│  ┌──────────────────────────────────────────┐               │
│  │         Post-Mint Actions                 │               │
│  │    ├─ Update UI state                    │               │
│  │    ├─ Award achievements                 │               │
│  │    ├─ Generate share frame               │               │
│  │    └─ Update leaderboard                 │               │
│  └──────────────────────────────────────────┘               │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### 6.3 Metadata Hosting (IPFS)

**IPFS Setup:**
```typescript
// lib/ipfs.ts
import { PinataSDK } from 'pinata';

const pinata = new PinataSDK({
    pinataJwt: process.env.PINATA_JWT,
    pinataGateway: process.env.PINATA_GATEWAY
});

export async function uploadMetadata(metadata: object) {
    const blob = new Blob([JSON.stringify(metadata)], { type: 'application/json' });
    const file = new File([blob], 'metadata.json');
    
    const upload = await pinata.upload.file(file);
    return `ipfs://${upload.IpfsHash}`;
}

export async function uploadImage(imageBuffer: Buffer) {
    const file = new File([imageBuffer], 'image.png', { type: 'image/png' });
    const upload = await pinata.upload.file(file);
    return `ipfs://${upload.IpfsHash}`;
}
```

**Metadata Generation Pipeline:**
```typescript
// lib/metadata-generator.ts
export async function generateWordMetadata(wordData: WordData) {
    // 1. Generate NFT image
    const imageBuffer = await generateNFTImage(wordData);
    const imageUri = await uploadImage(imageBuffer);
    
    // 2. Generate animation (optional for higher rarities)
    let animationUri;
    if (wordData.rarity >= RARITY.MYTHIC) {
        const animationBuffer = await generateAnimation(wordData);
        animationUri = await uploadImage(animationBuffer);
    }
    
    // 3. Create metadata
    const metadata = {
        name: `WYRD: Liberation of '${wordData.word}'`,
        description: generateDescription(wordData),
        image: imageUri,
        animation_url: animationUri,
        attributes: generateAttributes(wordData),
        properties: {
            etymology: wordData.etymology,
            game_data: wordData.gameData
        }
    };
    
    // 4. Upload metadata
    return await uploadMetadata(metadata);
}
```

---

## 7. ECONOMIC MODEL RECOMMENDATIONS

### 7.1 Revenue Projections

**Conservative Estimate (Monthly):**

| Metric | Value |
|--------|-------|
| Active Players | 5,000 |
| Mint Conversion Rate | 15% |
| Average Mints per Player | 3 |
| Average Mint Price | 0.003 ETH |
| Monthly Mints | 2,250 |
| Gross Revenue | 6.75 ETH |

**Revenue Distribution:**
- Zora Protocol (25%): 1.69 ETH
- Creator Rewards (10%): 0.68 ETH
- Referral Rewards (5%): 0.34 ETH
- WYRD Treasury (60%): 4.04 ETH

### 7.2 Token Sustainability

**Treasury Allocation:**
```
WYRD Treasury (60% of mint revenue)
├── Development (40%): 1.62 ETH/month
├── Community Rewards (30%): 1.21 ETH/month
├── Marketing (20%): 0.81 ETH/month
└── Reserve (10%): 0.40 ETH/month
```

### 7.3 Player Incentive Alignment

**Play-to-Earn Elements:**
- Complete words → Mint credits
- Refer friends → ETH rewards
- Daily streaks → Discount multipliers
- Rare discoveries → Higher value NFTs

---

## 8. IMPLEMENTATION ROADMAP

### Phase 1: Foundation (Weeks 1-2)
- [ ] Deploy WYRD_WORDS ERC-1155 contract
- [ ] Set up Zora SDK integration
- [ ] Implement basic mint UI
- [ ] Configure metadata pipeline

### Phase 2: Core Features (Weeks 3-4)
- [ ] Implement tiered pricing
- [ ] Add referral system
- [ ] Create achievement badges
- [ ] Build share functionality

### Phase 3: Social Integration (Weeks 5-6)
- [ ] Deploy Farcaster Frames
- [ ] Implement cast actions
- [ ] Create share-to-mint flow
- [ ] Add social proof features

### Phase 4: Advanced Features (Weeks 7-8)
- [ ] Dynamic pricing models
- [ ] Season passes
- [ ] Set completion rewards
- [ ] Governance integration

---

## 9. CODE INTEGRATION PATTERNS

### 9.1 React Component Structure

```typescript
// components/mint/MintModal.tsx
import { useMintWord } from '@/hooks/useMintWord';
import { useWordData } from '@/hooks/useWordData';

export function MintModal({ wordId, isOpen, onClose }: MintModalProps) {
    const { wordData, isLoading } = useWordData(wordId);
    const { mintWord, isPending, isSuccess } = useMintWord();
    const [referrer, setReferrer] = useState<string>();
    
    useEffect(() => {
        // Extract referrer from URL
        const params = new URLSearchParams(window.location.search);
        setReferrer(params.get('ref') || undefined);
    }, []);
    
    const handleMint = async () => {
        await mintWord(wordId, 1, referrer);
    };
    
    if (isSuccess) {
        return <MintSuccess wordData={wordData} onShare={generateShareFrame} />;
    }
    
    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent>
                <NFTPreview wordData={wordData} />
                <MintPricing wordData={wordData} />
                <Button onClick={handleMint} disabled={isPending}>
                    {isPending ? 'Minting...' : `Mint for ${wordData.price} ETH`}
                </Button>
                {referrer && <ReferrerBadge address={referrer} />}
            </DialogContent>
        </Dialog>
    );
}
```

### 9.2 Contract Constants

```typescript
// lib/constants.ts
export const WYRD_CONTRACT_ADDRESS = {
    base: '0x...',
    baseSepolia: '0x...'
};

export const WYRD_ABI = [
    {
        inputs: [
            { name: 'tokenId', type: 'uint256' },
            { name: 'quantity', type: 'uint256' },
            { name: 'recipient', type: 'address' },
            { name: 'referrer', type: 'address' }
        ],
        name: 'mintWord',
        outputs: [],
        stateMutability: 'payable',
        type: 'function'
    },
    // ... additional ABI entries
];

export const RARITY = {
    COMMON: 1,
    RARE: 2,
    MYTHIC: 3,
    LEGENDARY: 4
} as const;

export const MINT_FEES = {
    ZORA_PROTOCOL: 2500, // 25% in BPS
    CREATOR: 1000,       // 10%
    REFERRAL: 500,       // 5%
    FIRST_MINTER: 200    // 2%
};
```

---

## 10. SECURITY CONSIDERATIONS

### 10.1 Smart Contract Security
- Use OpenZeppelin's ReentrancyGuard for mint functions
- Implement proper access control (Ownable2Step)
- Add pausable functionality for emergencies
- Use SafeMath for all calculations

### 10.2 Frontend Security
- Validate all user inputs
- Use SIWE (Sign-In with Ethereum) for authentication
- Implement rate limiting on mint endpoints
- Sanitize metadata before IPFS upload

### 10.3 Economic Security
- Set maximum mint limits per transaction
- Implement anti-bot measures (CAPTCHA for free mints)
- Monitor for unusual minting patterns
- Emergency pause functionality

---

## Summary

This Zora minting integration transforms WYRD from a standalone game into a sustainable, community-driven onchain ecosystem. Key highlights:

1. **222+ Mintable Words** with tiered rarity and pricing
2. **ERC-1155 Architecture** for gas efficiency and flexibility
3. **Zora Native Rewards** including referral and creator splits
4. **Farcaster Integration** for viral social sharing
5. **Dynamic Pricing** models to optimize engagement
6. **Achievement System** for player retention
7. **Economic Sustainability** through balanced reward distribution

The design maintains WYRD's consciousness-liberation ethos while creating genuine value for players through collectible etymology NFTs.

---

*Document Version: 1.0*
*Created for: WYRD Game Integration*
*Protocol: Zora Creator Contracts*
*Target Chain: Base*
