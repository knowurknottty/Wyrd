# WYRD Farcaster Mini-App: Comprehensive UX Flow Design

## Document Overview

**Project:** WYRD - Linguistic Liberation System  
**Platform:** Farcaster Mini-App (Frame)  
**Target:** Mobile-first, quick-session design  
**Core Value:** Transform etymology exploration into consciousness liberation through gamified word analysis

---

## 1. ONBOARDING FLOW

### 1.1 Discovery to Entry Flow

**PATH A: Cast Discovery** | **PATH B: Direct Frame Link**
---|---
Friend's Cast: "Just analyzed 'AUTHORITY' on WYRD" | Shared Link in Bio/DM
↓ | ↓
Embedded Frame Preview Card | Frame Opens Directly
[Play WYRD] | 
↓ | ↓
**WYRD SPLASH SCREEN** (1.5 seconds)
↓
**FIRST-TIME GATE CHECK** (localStorage)
↓
NEW USER → Onboarding Flow | RETURNING USER → Daily Word Dashboard

### 1.2 First-Time User Onboarding (Progressive Disclosure)

#### Screen 1: Welcome & Hook (0-3 seconds)
```
        W Y R D
       ─────────
       Linguistic
       Liberation
         System

"Words shape reality.
 Uncover their secrets."

[Begin Liberation]

── or ──

[Connect Wallet]
(optional - skip for now)
```

**Micro-interactions:**
- Logo: Subtle pulse animation (2s cycle)
- Tagline: Typewriter effect reveal
- CTA: Gentle bounce on load, scale on hover/tap

**Decision Point:**
- Tap "Begin Liberation" → Screen 2 (Quick Start)
- Tap "Connect Wallet" → Wallet Selection Modal → Screen 2 (with wallet connected)

---

#### Screen 2: The Promise (3-8 seconds)
```
○ ○ ● ○  (progress)

"Every word carries
 hidden power."

┌─────────────────┐
│  AUTHORITY      │
│  ↓              │
│  "author"       │
│  (creator)      │
│  ↓              │
│  Who creates    │
│  YOUR reality?  │
└─────────────────┘

[Show Me How]
```

**Animation:** Word card flips to reveal etymology layers

---

#### Screen 3: The 4 Steps Preview (8-15 seconds)
```
○ ○ ○ ●  (progress)

"4 Steps to Liberation"

┌────┐ ┌────┐ ┌────┐ ┌────┐
│ 👁️ │→│ ⛏️ │→│ 🌊 │→│ ✦  │
│ 1  │ │ 2  │ │ 3  │ │ 4  │
└────┘ └────┘ └────┘ └────┘
 See   Dig   Track  Free   

Surface → Roots → Shift → Liberation
Reading  Excav.  Detect  Angle

[Try First Word]
```

**Interactive Element:** Tapping each step reveals brief tooltip

---

#### Screen 4: Tutorial Word (Guided First Analysis)
```
┌─────────────────────┐
│  TUTORIAL WORD      │
│  ═════════════════  │
│                     │
│      C O N T R O L  │
└─────────────────────┘

"Tap to begin analysis"
      ↓↓↓

[👁️ STEP 1: Surface Read]

"What does 'control'
 mean to you?"

┌─────────────────────┐
│  Power, command,    │
│  restriction...     │
└─────────────────────┘

[Continue →]
```

**Guided Flow:**
1. **Step 1 - Surface Reading**: User taps word, sees common definitions
2. **Step 2 - Root Excavation**: Reveal etymology (contra + rotulus = "against the roll")
3. **Step 3 - Semantic Shift**: Show how meaning evolved
4. **Step 4 - Liberation Angle**: Prompt reflection question

---

### 1.3 Wallet Connection Flow (Optional, Progressive)

**TRIGGER POINTS:**
- After 3rd word analysis ("Connect to save progress")
- When attempting to mint ("Connect to collect")
- When sharing with attribution ("Connect to claim")
- User-initiated from settings

```
┌─────────────────┐
│  Wallet Modal   │
│  ─────────────  │
│                 │
│  [🦊 MetaMask]  │
│  [🌈 Rainbow]   │
│  [🔷 Coinbase]  │
│  [✨ Privy]     │ ← RECOMMENDED (email/social)
│                 │
│  ─ or ─         │
│                 │
│  [📧 Continue   │
│   with Email]   │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  SUCCESS STATE  │
│  ─────────────  │
│  ✓ Connected    │
│  +50 XP Bonus   │
│  Progress Saved │
└─────────────────┘
```

**Key Principle:** Wallet is NEVER a barrier to entry. Users can:
- Analyze unlimited words without wallet
- Share discoveries without wallet
- Only need wallet for minting/collecting

---

## 2. CORE INTERACTION FLOWS

### 2.1 Daily Word Experience

**DAILY DASHBOARD:**
```
┌──────────┐  ┌──────────┐  ┌──────────┐
│   🔥     │  │   📅     │  │   🏆     │
│ Streak:  │  │ Day 47   │  │ Rank:    │
│   12     │  │ of 365   │  │ Seeker   │
└──────────┘  └──────────┘  └──────────┘

╔═══════════════════════════════════════╗
║                                       ║
║     T O D A Y ' S  W O R D          ║
║                                       ║
║        P R O P A G A N D A            ║
║                                       ║
╚═══════════════════════════════════════╝

     "Tap to begin liberation"
           ↓↓↓↓↓↓↓

[🔍 Analyze]  [📤 Share]  [📖 History]
```

**ANALYSIS FLOW (4 Steps):**

**STEP 1: SURFACE READING**
```
P R O P A G A N D A

Common meanings:
• Information, especially of a biased nature
• Used to promote a political cause
• Often misleading in nature

[I recognize this meaning →]
```

**STEP 2: ROOT EXCAVATION**
```
🔍 Etymology Revealed

propagare (Latin)
↓
pro- ("forth") + pag- ("to fasten")
↓
"That which is to be spread / propagated"

[💡 Interesting! →]  [🤔 Tell me more]
```

**STEP 3: SEMANTIC SHIFT**
```
🌊 How the meaning shifted

1620s: Neutral - "committee of cardinals"
↓
1790s: "Systematic dissemination of doctrine"
↓
20th C: Negative connotation (WWI/WWII usage)

[⚡ Detect Inversion →]
```

**STEP 4: LIBERATION ANGLE**
```
✦ Your Liberation Prompt

"If propaganda is 'that which spreads'...
 what ideas are YOU propagating
 without conscious choice?"

┌─────────────────────────────┐
│  [Share your reflection...] │
└─────────────────────────────┘

[Complete Liberation ✓]
```

**COMPLETION SCREEN:**
```
🎉 Liberation Complete!

┌──────────┐  ┌──────────┐  ┌──────────┐
│   +25    │  │   +10    │  │   🔥     │
│    XP    │  │  Insight │  │ Streak:  │
│          │  │  Points  │  │   13!    │
└──────────┘  └──────────┘  └──────────┘

[🎨 Mint NFT]  [📤 Share]  [🔍 Another]
```

---

### 2.2 Word Scanner Flow

**SCANNER INTERFACE:**
```
🔍 Enter a word to liberate

┌─────────────────────────────────┐
│  ┌─────────────────────────┐    │
│  │ Type or paste word...   │    │
│  └─────────────────────────┘    │
│            [🔍 Scan]            │
└─────────────────────────────────┘

── or ──

📸 [Camera Scan]  🎤 [Voice]  📋 [Paste]

── Trending ──

┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐
│POWER   │ │TRUTH   │ │MONEY   │ │TIME    │
│🔥 234  │ │🔥 198  │ │🔥 156  │ │🔥 142  │
└────────┘ └────────┘ └────────┘ └────────┘
```

**SCANNING STATES:**

**STATE 1: SEARCHING**
```
⚡ Scanning the etymosphere...

[████░░░░░░░░░░░░] 25%

Searching 222+ word entries...
```

**STATE 2: FOUND IN DATABASE**
```
✓ Word found in the Liberation Archive!

      D E M O C R A C Y

[Begin Analysis →]
```

**STATE 3: NOT FOUND (Crowdsourced Discovery)**
```
🔮 This word hasn't been liberated yet!

"SYNERGY" is not in our archive.

You can:
• [Request Analysis] - Add to queue (50 XP)
• [Submit Etymology] - Contribute (100 XP)
• [Try Similar Word] - See related entries
```

---

### 2.3 Analysis Completion Flow

**COMPLETION CELEBRATION:**
```
✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦

🎉 LIBERATION COMPLETE 🎉

✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦

┌─────────────────────────────┐
│                             │
│      P R O P A G A N D A    │
│                             │
│  From: propagare            │
│  "to propagate, spread"     │
│                             │
│  Liberation: What are YOU   │
│  spreading unconsciously?   │
│                             │
└─────────────────────────────┘

REWARDS UNLOCKED:

┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐
│  +25   │ │  +10   │ │   🔥   │ │   🧠   │
│   XP   │ │ Insight│ │ Streak │ │  Words │
│        │ │ Points │ │   +1   │ │   47   │
└────────┘ └────────┘ └────────┘ └────────┘

[🎨 Mint]  [📤 Share]  [🏷️ Challenge]  [🔍 Another]

📊 Progress: Seeker → Sage
[████████████████░░] 67% (670/1000 XP)
```

---

### 2.4 Discovery/Minting Flow

**MINT PREVIEW SCREEN:**
```
╔═══════════════════════════════════════╗
║                                       ║
║      P R O P A G A N D A              ║
║                                       ║
║  "That which spreads                  ║
║   without conscious choice"           ║
║                                       ║
║  Liberated by: @user                  ║
║  Day 47 of 365                        ║
║                                       ║
╚═══════════════════════════════════════╝

MINT DETAILS:
• Network: Base (L2)
• Cost: FREE (gas sponsored)
• Edition: 1 of unlimited

[⚡ Mint Now - FREE]

── or ──

[💾 Save to Collection] (no mint)
```

**MINTING STATES:**

**STATE 1: PREPARING**
```
⚡ Preparing your liberation artifact...
[████████░░░░░░░░░░] 40%
• Generating unique visual
• Preparing metadata
```

**STATE 2: SIGNING**
```
📝 Please sign the transaction

[Open Wallet]  [Cancel]
```

**STATE 3: CONFIRMING**
```
⏳ Confirming on Base network...
[██████████████████░░] 85%
Transaction: 0x7a3f...9e2d
```

**STATE 4: SUCCESS**
```
🎉 Successfully minted!

Your word liberation is now forever on-chain.

[View on BaseScan]  [Share]  [Add to Profile]
```

---

## 3. SOCIAL SHARING FLOWS

### 3.1 Share Word Discovery to Farcaster

**SHARE COMPOSER SCREEN:**
```
PREVIEW:
╔═══════════════════════════════════════╗
║  W Y R D - Linguistic Liberation    ║
║                                       ║
║        P R O P A G A N D A            ║
║                                       ║
║  "From Latin propagare:               ║
║   'to spread, propagate'"             ║
║                                       ║
║  💡 Liberation: What ideas are YOU    ║
║     spreading unconsciously?          ║
║                                       ║
║  🔥 Day 13 streak | 🎨 Minted on Base ║
╚═══════════════════════════════════════╝

YOUR MESSAGE:
┌─────────────────────────────────────┐
│ Just liberated 'PROPAGANDA' on      │
│ @wyrd 🧠                            │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│ "What ideas are you spreading       │
│  without realizing it?"             │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│ [Tap to analyze your own words →]   │
└─────────────────────────────────────┘

TEMPLATES: [💭 Reflection] [🔥 Challenge] [🎓 Educational]

OPTIONS: ☑️ Include NFT ☑️ Tag WYRD ☐ Custom text

[📤 Share to Farcaster]
```

**POST-SHARE SUCCESS:**
```
✓ Shared to Farcaster!

Your cast is live.
+15 XP for sharing knowledge!

[View Cast]  [Invite Replies]  [Share Again]

ENGAGEMENT TRACKING:
• Recasts: +5 XP each
• Replies: +3 XP each
• New users from link: +50 XP
```

---

### 3.2 Invite Friends Flow

**INVITE HUB SCREEN:**
```
🎁 Invite & Earn

For each friend who joins:
┌──────────┐  ┌──────────┐  ┌──────────┐
│   +100   │  │   +1     │  │   🏆     │
│    XP    │  │  Streak  │  │  Bonus   │
│          │  │  Protect │  │  Unlock  │
└──────────┘  └──────────┘  └──────────┘

YOUR INVITE LINK:
┌─────────────────────────────────────┐
│ https://wyrd.fun/invite/@handle   │
│                         [📋 Copy]   │
└─────────────────────────────────────┘

SHARE VIA:
┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐
│   🐦   │ │   📱   │ │   ✉️   │ │   🔗   │
│Twitter │ │  SMS   │ │ Email  │ │  More  │
└────────┘ └────────┘ └────────┘ └────────┘

── Your Impact ──
Friends Joined: 7
Words Liberated Together: 142
[View Leaderboard →]
```

---

### 3.3 Challenge Others Flow

**CHALLENGE CREATOR:**
```
🏆 Create a Challenge

WORD TO CHALLENGE:
┌─────────────────────────────────────┐
│        P R O P A G A N D A          │
└─────────────────────────────────────┘

CHALLENGE TYPE:
┌──────────────┐ ┌──────────────┐ ┌──────────────┐
│  ⚡ Speed    │ │  🧠 Depth    │ │  🔥 Streak   │
│  Challenge   │ │  Challenge   │ │  Challenge   │
│              │ │              │ │              │
│  Who can     │ │  Who can     │ │  Who can     │
│  analyze     │ │  find the    │ │  maintain    │
│  fastest?    │ │  deepest     │ │  longest     │
│              │ │  insight?    │ │  streak?     │
└──────────────┘ └──────────────┘ └──────────────┘

CHALLENGE MESSAGE:
┌─────────────────────────────────────┐
│ I challenge you to liberate         │
│ 'PROPAGANDA' on @wyrd!              │
│ Can you find a deeper insight? 🧠   │
└─────────────────────────────────────┘

CHALLENGE TO:
┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐
│ @alice │ │ @bob   │ │ @char  │ │  🌐    │
│   ✓    │ │   ○    │ │   ○    │ │Public │
└────────┘ └────────┘ └────────┘ └────────┘

[🏆 Send Challenge]
```

---

## 4. RE-ENGAGEMENT FLOWS

### 4.1 Daily Notification Handling

**NOTIFICATION TRIGGERS:**
- 9:00 AM local: "Today's word is ready"
- 8:00 PM local: "Don't break your streak!" (if not completed)
- Special events: New feature, milestone, friend activity

**NOTIFICATION CARD:**
```
┌─────────────────────────────────────┐
│  🔮 WYRD                            │
│  ─────────────────────────────────  │
│                                     │
│  Today's word awaits...             │
│                                     │
│        T R A N S F O R M A T I O N  │
│                                     │
│  "Your daily liberation is ready"   │
│                                     │
│  [🔍 Liberate Now]                  │
│                                     │
│  🔥 Streak: 12 days | ⏰ 8h left    │
└─────────────────────────────────────┘
```

**TAP HANDLING:**
- IF APP INSTALLED: Open app directly to Daily Word screen
- IF APP NOT INSTALLED: Open Farcaster Frame in browser
- IF WITHIN FARCASTER APP: Open as embedded Frame

---

### 4.2 Streak Recovery Flow

**STREAK BROKEN SCREEN:**
```
💔  S T R E A K   B R O K E N

Your 12-day liberation streak ended

┌─────────────────────────────────────┐
│                                     │
│           🔥 12 → 0 🔥              │
│                                     │
│    "Even broken streaks teach us    │
│     about impermanence."            │
│                                     │
└─────────────────────────────────────┘

RECOVERY OPTIONS:

┌─────────────────────────────────────┐
│ 🛡️ STREAK SHIELD (if available)     │
│    You have 1 Streak Shield         │
│    [Use Shield - Restore streak]    │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│ 💎 BUY STREAK RECOVERY              │
│    Restore for 500 XP               │
│    [Purchase Recovery]              │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│ ✨ START FRESH                      │
│    Every ending is a new beginning  │
│    [Begin New Streak →]             │
└─────────────────────────────────────┘

Your longest streak: 23 days
```

**STREAK SHIELD EARNED:**
- Every 7-day streak: +1 Shield
- Every 30-day streak: +3 Shields
- Special events: Bonus shields

---

### 4.3 New Feature Discovery Flow

**FEATURE SPOTLIGHT MODAL:**
```
┌─────────────────────────────────────┐
│  🎉  N E W   F E A T U R E          │
│                                     │
│         ┌─────────────┐             │
│         │   📸📸📸    │             │
│         │   Camera    │             │
│         │   Scanner   │             │
│         └─────────────┘             │
│                                     │
│  "Point your camera at any word     │
│   in the real world to liberate it!"│
│                                     │
│  ✓ Scan words from books, signs     │
│  ✓ Instant etymology lookup         │
│  ✓ Save discoveries to collection   │
│                                     │
│  [🚀 Try It Now]  [💾 Maybe Later]  │
│                                     │
│  ☐ Don't show new features again    │
└─────────────────────────────────────┘
```

**PROGRESSIVE FEATURE ROLLOUT:**
```
FEATURE UNLOCK SCHEDULE:

Day 1:   Basic word analysis
Day 3:   Word scanner unlocked
Day 7:   Streak shields enabled
Day 14:  Challenge friends feature
Day 21:  Advanced etymology layers
Day 30:  Community contributions

Each unlock celebrated with:
• Special animation
• XP bonus (+25-100 XP)
• Shareable milestone card
```

---

## 5. MOBILE-FIRST CONSIDERATIONS

### 5.1 Frame Constraints & Design

**SCREEN REAL ESTATE:**
```
┌─────────────────────────────────────────┐
│  Farcaster App Header (~60px)          │
├─────────────────────────────────────────┤
│                                         │
│  SAFE CONTENT AREA                      │
│  (~500-600px depending on device)       │
│                                         │
├─────────────────────────────────────────┤
│  Frame Action Bar (~50px)              │
└─────────────────────────────────────────┘
```

**DESIGN PRINCIPLES:**
- Single-column layout
- Maximum 3 primary actions per screen
- Touch targets minimum 44x44px
- Scrollable content with sticky CTAs
- Bottom-sheet modals for secondary actions

---

### 5.2 Touch Interaction Patterns

| Gesture | Use Case | Feedback |
|---------|----------|----------|
| **TAP** | Select word, reveal etymology, advance step, confirm | Ripple + haptic (light) |
| **SWIPE** | Navigate steps, dismiss modal, pull refresh | Spring animation + haptic (medium) |
| **LONG PRESS** | Peek preview, hidden details, quick actions | Scale up + haptic (heavy) |
| **PINCH** | Zoom visualization, expand etymology tree | Smooth scale animation |

---

### 5.3 Quick-Session Design

**SESSION LENGTH TARGETS:**
- Micro: 30 seconds (check daily word, quick share)
- Short: 2-3 minutes (complete one analysis)
- Medium: 5-10 minutes (multiple words, challenges)

**TIME-TO-VALUE OPTIMIZATION:**
```
0-3 sec:   App loads, splash shown
3-8 sec:   Daily word displayed
8-15 sec:  First tap reveals etymology
15-30 sec: Core insight delivered
30-60 sec: Liberation angle presented
60-120 sec: Completion + share options
```

**RESUME SESSION FLOW:**
- Save progress every step
- On return: "Continue your analysis of 'PROPAGANDA'?"
- One-tap resume from interruption point

---

## 6. FRICTION REDUCTION STRATEGIES

### 6.1 Gasless Transaction Patterns

**GASLESS MINTING ARCHITECTURE:**
```
USER ACTION → SPONSORED TX → RELAYER/PAYMASTER
(Tap "Mint")   (No gas fee)    (Covers gas)
                    │
                    ▼
              USER RECEIVES
               NFT (FREE)
```

**IMPLEMENTATION OPTIONS:**
1. ThirdWeb Gasless (recommended)
2. OpenZeppelin Defender Relayer
3. Custom Paymaster on Base

**USER EXPERIENCE:**
- No "insufficient funds" errors
- No gas price anxiety
- One-tap minting
- Optional: Show "Gas sponsored by WYRD"

---

### 6.2 Wallet Abstraction Strategies

**PRIVY INTEGRATION (Recommended):**
```
USER AUTH OPTIONS:
┌────────┐  ┌────────┐  ┌────────┐
│   📧   │  │   🐦   │  │   👤   │
│ Email  │  │Twitter │  │Farcaster│
│ + OTP  │  │  Auth  │  │  Auth  │
└────┬───┘  └───┬────┘  └───┬────┘
     │          │           │
     └──────────┴───────────┘
                │
                ▼
    ┌─────────────────────┐
    │  EMBEDDED SMART     │
    │  WALLET CREATED     │ ← User doesn't see this
    │  (Privy-managed)    │
    └─────────────────────┘
                │
                ▼
    ┌─────────────────────┐
    │  SEAMLESS WEB3      │
    │  EXPERIENCE         │
    │  • Mint NFTs        │
    │  • Sign messages    │
    │  • No seed phrases  │
    └─────────────────────┘
```

**PROGRESSIVE WALLET ADOPTION:**
- Phase 1: No wallet required (analyze, share)
- Phase 2: Embedded wallet auto-created on first mint
- Phase 3: Option to export to external wallet

---

### 6.3 One-Tap Actions

**OPTIMIZED FLOWS:**

| Flow | Taps | Steps |
|------|------|-------|
| Daily Word → Completion | 3 | Open → Analyze → Share |
| Word Scanner → Analysis | 3 | Scanner → Input → Submit |
| Share → Farcaster Post | 2 | Tap Share → Confirm |
| Mint → NFT Owned | 2 | Tap Mint → Confirm |

**SMART DEFAULTS:**
- Pre-filled share messages (customizable)
- Auto-advance through analysis steps (with skip option)
- Default mint settings (user can customize later)
- Remember user preferences

---

## 7. LOADING STATES & ERROR HANDLING

### 7.1 Loading State Patterns

**SKELETON SCREENS:**
```
WORD CARD LOADING:
┌─────────────────────────────────────┐
│  ┌─────────────────────────────┐    │
│  │  ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ │    │
│  │  ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ │    │
│  └─────────────────────────────┘    │
│                                     │
│  ┌─────────────────────────────┐    │
│  │ ░░░░░░░░░░░░░░░░░░░░░░░░░░░ │    │
│  │ ░░░░░░░░░░░░░░░░░░░░░░░░░░░ │    │
│  │ ░░░░░░░░░░░░░░░░░░░░░░░░░░░ │    │
│  └─────────────────────────────┘    │
└─────────────────────────────────────┘
```

**Animation:** Gentle pulse on skeleton blocks  
**Duration:** Max 2 seconds before showing cached/error state

**ENTERTAINING LOADERS:**
- "Excavating word roots..."
- "Tracing etymology through time..."
- "Decoding linguistic layers..."
- "Connecting to the etymosphere..."

---

### 7.2 Error Handling Patterns

**NETWORK ERROR:**
```
🌐 Connection Lost

"The etymosphere is temporarily unreachable."

[🔄 Retry]  [📴 Use Offline Mode]

Your last 10 words are available offline.
```

**WORD NOT FOUND:**
```
🔮 Word Not in Archive

"'XYZWORD' hasn't been liberated yet."

[📋 Request Analysis]  [🔍 Try Similar Words]

Similar: X-WORD, Y-WORD, Z-WORD
```

**MINTING ERROR:**
```
⚠️ Minting Interrupted

"Your liberation artifact couldn't be minted."

[🔄 Try Again]  [💾 Save to Collection]  [⏭️ Skip]

Your analysis is still saved!
```

**WALLET ERROR:**
```
🔐 Wallet Connection Issue

"We couldn't connect to your wallet."

[🔄 Reconnect]  [📧 Use Email Instead]  [⏭️ Continue]

You can still analyze words without a wallet!
```

**ERROR PREVENTION:**
- Pre-validate word input
- Check wallet balance before mint (if not gasless)
- Retry failed requests automatically (3 attempts)
- Cache critical data for offline access

---

## 8. MICRO-INTERACTIONS & DELIGHT MOMENTS

### 8.1 Animation Specifications

| Interaction | Duration | Effect | Haptic |
|-------------|----------|--------|--------|
| Word Reveal | 600ms | Scale 0.8→1.0, fade in | Light impact |
| Etymology Unlock | 800ms | 3D flip, particle burst | Medium impact |
| Streak Increment | 1000ms | Count-up, flame intensify | Success pattern |
| XP Gain | 500ms | Float up, progress fill | Light tap |
| Completion Celebration | 2000ms | Confetti, card glow | Success + continuous |
| Mint Success | 1500ms | NFT materializes, sparkle | Heavy + success |

**Easing:** cubic-bezier(0.34, 1.56, 0.64, 1) (spring)

---

### 8.2 Haptic Feedback Patterns

| Interaction | Pattern |
|-------------|---------|
| Button tap (standard) | Light impact |
| Button tap (primary CTA) | Medium impact |
| Word selection | Light impact |
| Step completion | Medium impact |
| Analysis complete | Success pattern (3 pulses) |
| Streak milestone | Success + continuous light |
| Error/warning | Error pattern (2 sharp pulses) |
| Pull to refresh | Light impact on release |
| Long press activation | Heavy impact |
| Mint success | Heavy + success pattern |

**Note:** All haptics respect system settings. Provide toggle in settings.

---

## 9. DECISION TREES & BRANCHING

### 9.1 User State Decision Tree

```
User opens WYRD
       │
       ▼
  First time?
   /       \
 YES        NO
  │          │
  ▼          ▼
Onboarding  Has wallet?
   Flow      /    \
           YES     NO
            │       │
            ▼       ▼
      Check daily  Check daily
      completion   completion
         /  \        │
      Done  Not Done │
       │      │      │
       ▼      ▼      ▼
   Streak  Daily    Show connect
   status  word     wallet prompt
```

### 9.2 Share Flow Decision Tree

```
User completes analysis
       │
       ▼
   Tap Share
       │
       ▼
  Wallet connected?
     /        \
   YES         NO
    │           │
    ▼           ▼
Full options  Limited options
    │           │
    └─────┬─────┘
          │
          ▼
    User selects
    share method
          │
    ┌─────┼─────┐
    ▼     ▼     ▼
Farcaster Copy Other
 (in-app) Link  apps
```

---

## 10. SUCCESS METRICS & TRACKING

### 10.1 Key UX Metrics

**ONBOARDING METRICS:**
- Time to first analysis completion
- Onboarding completion rate
- Drop-off points in onboarding flow
- Wallet connection rate (optional vs required)

**ENGAGEMENT METRICS:**
- Daily Active Users (DAU)
- Average sessions per user per week
- Average words analyzed per session
- Streak retention (7-day, 30-day)
- Feature adoption rate (scanner, challenges, etc.)

**CONVERSION METRICS:**
- Share rate (analysis → share)
- Mint rate (completion → mint)
- Invite rate (users who invite friends)
- Challenge participation rate

**RETENTION METRICS:**
- Day 1, 7, 30 retention
- Streak recovery rate
- Re-engagement from notifications
- Return rate after break

**SATISFACTION METRICS:**
- NPS score
- App store rating
- Support ticket volume
- Feature request frequency

---

## APPENDIX: QUICK REFERENCE

### A. State Machine Summary

| State | Entry Condition | Exit Condition |
|-------|-----------------|----------------|
| `DISCOVERED` | User sees WYRD link/cast | Tap to open |
| `ONBOARDING` | First-time user | Complete tutorial OR skip |
| `DASHBOARD` | Daily word available | Tap word OR other action |
| `ANALYZING` | User starts analysis | Complete all 4 steps |
| `COMPLETING` | Analysis done | Share, mint, or continue |
| `SHARING` | User taps share | Post shared OR cancelled |
| `MINTING` | User taps mint | Success OR error handled |
| `RECOVERING` | Streak broken | Shield used OR new streak |

### B. Critical User Paths

1. **Happy Path**: Discover → Onboard → Daily Word → Complete Analysis → Share → Return tomorrow
2. **Power User Path**: Discover → Skip Onboard → Multiple Analyses → Mint Collection → Invite Friends
3. **Casual Path**: Discover → Analyze → Return sporadically → Streak breaks → Recovery
4. **Social Path**: Discover → Analyze → Share → Friend joins → Challenge each other

### C. Friction Points to Monitor

- Wallet connection abandonment
- Analysis step drop-offs
- Share cancellation rate
- Mint failure recovery
- Notification opt-out rate
- App uninstall triggers

---

*Document Version: 1.0*  
*Last Updated: 2025*  
*For: WYRD Farcaster Mini-App Development*
