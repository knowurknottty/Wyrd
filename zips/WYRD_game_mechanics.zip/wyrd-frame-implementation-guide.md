# WYRD Farcaster Mini-App Implementation Guide

## Quick Start Checklist

### Prerequisites
- [ ] Farcaster account with FID
- [ ] Neynar API key
- [ ] Domain registered (wyrd.game)
- [ ] Base mainnet RPC endpoint
- [ ] IPFS/API storage for NFT metadata

### Step 1: Install Dependencies

```bash
npm install @farcaster/miniapp-sdk @farcaster/auth-client @neynar/nodejs-sdk
npm install viem wagmi @coinbase/onchainkit
```

### Step 2: Environment Setup

Create `.env.local`:

```bash
# Farcaster
FARCASTER_DOMAIN=wyrd.game
FARCASTER_HEADER=eyJmaWQiOjEyMzQsInR5cGUiOiJjdXN0b2R5Iiwia2V5IjoiMHh...}
FARCASTER_PAYLOAD=eyJkb21haW4iOiJ3eXJkLmdhbWUifQ
FARCASTER_SIGNATURE=MHh...
NEYNAR_API_KEY=your_neynar_api_key

# Database
DATABASE_URL=your_database_url
REDIS_URL=your_redis_url

# Blockchain
BASE_RPC_URL=https://mainnet.base.org
WYRD_NFT_CONTRACT=0x...

# Storage
IPFS_API_KEY=your_ipfs_key
IPFS_API_SECRET=your_ipfs_secret
```

### Step 3: Generate Frame Manifest

Use the Farcaster manifest generator:

```bash
# Install CLI
npm install -g @farcaster/manifest-cli

# Generate manifest
farcaster-manifest generate --domain wyrd.game --fid YOUR_FID

# Sign manifest with your custody wallet
farcaster-manifest sign --domain wyrd.game --private-key YOUR_PRIVATE_KEY
```

### Step 4: Create Frame Routes

Create the following files in your Next.js app:

```
app/
├── frame/
│   ├── manifest.json/route.ts
│   ├── layout.tsx
│   ├── page.tsx (launch page)
│   ├── daily/page.tsx
│   ├── word/[id]/page.tsx
│   ├── scanner/page.tsx
│   └── profile/page.tsx
├── api/
│   ├── frame/
│   │   ├── validate/route.ts
│   │   └── notify/route.ts
│   ├── words/
│   │   ├── [id]/route.ts
│   │   ├── search/route.ts
│   │   └── daily/route.ts
│   └── composer/route.ts
```

### Step 5: Add Frame Components

Copy the components from `wyrd-frame-components.tsx` to:

```
components/frame/
├── FrameProvider.tsx
├── FrameSplash.tsx
├── WordAnalysisFrame.tsx
├── DailyChallengeFrame.tsx
├── WordScannerFrame.tsx
├── UserProfileFrame.tsx
├── ShareComposer.tsx
└── AddToHomePrompt.tsx
```

### Step 6: Test in Warpcast Debugger

1. Deploy your app to production (frames require HTTPS)
2. Go to https://warpcast.com/~/developers/frames
3. Enter your frame URL: `https://wyrd.game/frame`
4. Test all interactions

### Step 7: Submit to Farcaster Directory

1. Go to https://warpcast.com/~/developers/mini-apps
2. Click "Submit Mini App"
3. Enter your manifest URL: `https://wyrd.game/frame/manifest.json`
4. Fill in app details
5. Submit for review

---

## Code Snippets

### Frame Layout Wrapper

```tsx
// app/frame/layout.tsx
import { FrameProvider } from '@/components/frame/FrameProvider';
import { FrameSplash } from '@/components/frame/FrameSplash';

export default function FrameLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <FrameProvider>
      <FrameContent>{children}</FrameContent>
    </FrameProvider>
  );
}

function FrameContent({ children }: { children: React.ReactNode }) {
  const { isReady } = useFrame();
  return (
    <>
      <FrameSplash isReady={isReady} />
      {children}
    </>
  );
}
```

### Word Analysis Page

```tsx
// app/frame/word/[id]/page.tsx
import { WordAnalysisFrame } from '@/components/frame/WordAnalysisFrame';

export default async function WordPage({
  params,
}: {
  params: { id: string };
}) {
  const word = await fetchWord(params.id);
  
  return <WordAnalysisFrame wordId={params.id} wordData={word} />;
}
```

### Daily Challenge Page

```tsx
// app/frame/daily/page.tsx
import { DailyChallengeFrame } from '@/components/frame/DailyChallengeFrame';

export default async function DailyPage() {
  const { word, dayNumber } = await fetchDailyWord();
  const userStreak = await fetchUserStreak();
  
  return (
    <DailyChallengeFrame
      word={word}
      dayNumber={dayNumber}
      userStreak={userStreak}
    />
  );
}
```

---

## Testing Checklist

### Frame Functionality
- [ ] Frame loads without errors
- [ ] Splash screen displays correctly
- [ ] Frame context is received (user FID, username)
- [ ] Primary button works
- [ ] Navigation between pages works
- [ ] Frame can be added to home

### Gameplay
- [ ] Word analysis flow completes all 4 steps
- [ ] Daily challenge displays correctly
- [ ] Word scanner finds words
- [ ] Liberation complete screen shows
- [ ] Share button opens Warpcast composer

### Social Features
- [ ] Casts include correct embeds
- [ ] OG images generate properly
- [ ] Challenge invites work
- [ ] Referral tracking works

### Wallet Integration
- [ ] Wallet connects in frame
- [ ] Transactions can be sent
- [ ] NFT minting works (if implemented)

### Notifications
- [ ] Users can subscribe to notifications
- [ ] Daily notifications send correctly
- [ ] Challenge notifications work
- [ ] Streak reminders send

---

## Common Issues & Solutions

### Issue: Frame not loading in Warpcast
**Solution:** 
- Ensure HTTPS is enabled
- Check manifest.json is valid
- Verify domain matches manifest

### Issue: SDK context is null
**Solution:**
- Call `sdk.actions.ready()` after loading
- Check you're running inside a frame with `sdk.isInMiniApp()`

### Issue: Wallet transactions failing
**Solution:**
- Verify correct chain ID (Base = 8453)
- Check wallet has sufficient gas
- Ensure contract addresses are correct

### Issue: Notifications not sending
**Solution:**
- Verify user has subscribed to notifications
- Check notification token is stored
- Ensure Warpcast API key is valid

---

## Performance Tips

1. **Lazy load components** - Only load frame SDK when needed
2. **Cache word data** - Use Redis for frequently accessed words
3. **Optimize images** - Compress OG images, use WebP format
4. **Minimize API calls** - Batch requests where possible
5. **Use edge functions** - Deploy API routes to edge for lower latency

---

## Analytics Events

Track these events for insights:

```typescript
// Frame engagement
frame_opened
word_analysis_started
word_analysis_completed
share_initiated
share_completed

// Social
challenge_invite_sent
challenge_invite_accepted
challenge_completed

// Monetization
nft_mint_started
nft_mint_completed
transaction_initiated
transaction_completed

// Retention
notification_opened
streak_maintained
return_visit
```

---

## Resources

- [Farcaster Mini-App Docs](https://docs.farcaster.xyz/learn/what-is-farcaster/mini-apps)
- [Mini-App SDK Reference](https://github.com/farcasterxyz/miniapps)
- [Neynar API Docs](https://docs.neynar.com/)
- [Warpcast Developer Portal](https://warpcast.com/~/developers)
- [Base Documentation](https://docs.base.org/)

---

## Support

For issues or questions:
- Farcaster Dev Channel: https://warpcast.com/~/channel/farcaster-dev
- WYRD Support: support@wyrd.game
