# WYRD Farcaster Mini-App Integration Specification

## Executive Summary

This document provides a comprehensive technical specification for integrating WYRD (Linguistic Liberation System) as a Farcaster Mini-App (formerly Frames v2). The integration enables viral social distribution through Farcaster's social graph while maintaining the core etymology gameplay experience.

---

## 1. Frame Architecture

### 1.1 Mini-App Overview

WYRD becomes a full-screen interactive application that renders inside Farcaster clients (Warpcast, etc.). The mini-app leverages:

- **Full-screen web experience** - No image rendering limitations
- **Interactive UI components** - Native React components for gameplay
- **Wallet integration** - For potential NFT minting of discoveries
- **Notifications** - Re-engage users with daily words and challenges
- **Social context** - Access to user's Farcaster identity and social graph

### 1.2 Route Structure

```
/                              # Mini-app entry point (splash/loading)
/frame/                        # Frame-specific routes
  ├── manifest.json            # Farcaster manifest (required)
  ├── launch/                  # Initial launch experience
  │   └── page.tsx
  ├── daily/                   # Daily word challenge
  │   └── page.tsx
  ├── word/[id]/               # Individual word analysis
  │   └── page.tsx
  ├── scanner/                 # Word scanner interface
  │   └── page.tsx
  ├── profile/                 # User's liberation stats
  │   └── page.tsx
  └── share/                   # Share composition interface
      └── page.tsx

/api/frame/                    # Server-side frame handlers
  ├── validate/                # Message validation endpoint
  ├── notify/                  # Notification sending endpoint
  └── auth/                    # Farcaster auth callbacks
```

### 1.3 Frame Manifest Configuration

```json
{
  "accountAssociation": {
    "header": "eyJmaWQiOjEyMzQsInR5cGUiOiJjdXN0b2R5Iiwia2V5IjoiMHh...",
    "payload": "eyJkb21haW4iOiJ3eXJkLmdhbWUifQ",
    "signature": "MHh..."
  },
  "frame": {
    "version": "1",
    "name": "WYRD - Linguistic Liberation",
    "iconUrl": "https://wyrd.game/icon.png",
    "homeUrl": "https://wyrd.game/frame/launch",
    "imageUrl": "https://wyrd.game/og-image.png",
    "buttonTitle": "Liberate Language",
    "splashImageUrl": "https://wyrd.game/splash.png",
    "splashBackgroundColor": "#1a1a2e",
    "subtitle": "Decode reality through etymology",
    "description": "A linguistic liberation system that reveals how language shapes consciousness through etymological analysis.",
    "primaryCategory": "entertainment",
    "tags": ["word-game", "etymology", "consciousness", "education"],
    "heroImageUrl": "https://wyrd.game/hero.png",
    "tagline": "Every word is a spell. Break it.",
    "ogTitle": "WYRD - Linguistic Liberation System",
    "ogDescription": "Decode the hidden meanings behind everyday language",
    "ogImageUrl": "https://wyrd.game/og-image.png"
  }
}
```

### 1.4 State Management Architecture

```typescript
// types/frame.ts
export interface FrameContext {
  user: {
    fid: number;
    username?: string;
    displayName?: string;
    pfpUrl?: string;
  };
  location?: FrameLocationContext;
  client: {
    clientFid: number;
    added: boolean;
    safeAreaInsets?: SafeAreaInsets;
    notificationDetails?: FrameNotificationDetails;
  };
}

export interface WYRDFrameState {
  // Core game state
  currentWordId: string | null;
  analysisProgress: AnalysisStep;
  userDiscoveries: string[];
  liberationScore: number;
  
  // Social state
  sharedDiscoveries: SharedDiscovery[];
  challengeInvites: ChallengeInvite[];
  
  // Frame-specific
  isInFrame: boolean;
  frameContext: FrameContext | null;
  notificationToken: string | null;
}

export enum AnalysisStep {
  SURFACE_READING = 'surface',
  ROOT_EXCAVATION = 'roots',
  SEMANTIC_SHIFT = 'semantic',
  LIBERATION_ANGLE = 'liberation'
}
```

### 1.5 Frame SDK Integration Pattern

```typescript
// hooks/useFrameSDK.ts
import { sdk } from '@farcaster/miniapp-sdk';
import { useEffect, useState } from 'react';

export function useFrameSDK() {
  const [isReady, setIsReady] = useState(false);
  const [context, setContext] = useState<FrameContext | null>(null);
  const [isInFrame, setIsInFrame] = useState(false);

  useEffect(() => {
    const initFrame = async () => {
      try {
        // Check if running inside Farcaster
        const inFrame = await sdk.isInMiniApp();
        setIsInFrame(inFrame);

        if (inFrame) {
          // Get frame context (user info, location, etc.)
          const frameContext = await sdk.context;
          setContext(frameContext);

          // Signal that frame is ready to display
          await sdk.actions.ready();
          setIsReady(true);

          // Set up primary button for main action
          await sdk.actions.setPrimaryButton({
            text: 'Liberate',
            enabled: true,
          });

          // Listen for primary button clicks
          sdk.on('primaryButtonClick', handlePrimaryAction);
        }
      } catch (error) {
        console.error('Frame SDK initialization failed:', error);
      }
    };

    initFrame();

    return () => {
      sdk.off('primaryButtonClick', handlePrimaryAction);
    };
  }, []);

  const handlePrimaryAction = () => {
    // Handle primary button click
    // This could trigger the liberation analysis
  };

  const addFrame = async () => {
    if (isInFrame) {
      try {
        await sdk.actions.addFrame();
        // Frame added to user's launcher
      } catch (error) {
        console.error('Failed to add frame:', error);
      }
    }
  };

  const signIn = async () => {
    if (isInFrame) {
      try {
        const result = await sdk.actions.signIn({
          nonce: generateNonce(), // Generate cryptographically secure nonce
        });
        // Handle sign-in result
        return result;
      } catch (error) {
        console.error('Sign-in failed:', error);
      }
    }
  };

  return {
    isReady,
    isInFrame,
    context,
    addFrame,
    signIn,
  };
}
```

---

## 2. Social Distribution Features

### 2.1 Share Discovery Flow

When a player completes a word analysis, they can share their "liberation" on Farcaster:

```typescript
// components/ShareDiscovery.tsx
import { sdk } from '@farcaster/miniapp-sdk';

interface ShareDiscoveryProps {
  word: WordEntry;
  analysis: AnalysisResult;
  liberationInsight: string;
}

export function ShareDiscovery({ word, analysis, liberationInsight }: ShareDiscoveryProps) {
  const composeShareCast = async () => {
    const shareText = generateLiberationCast(word, analysis, liberationInsight);
    
    // Open Warpcast composer with pre-filled content
    const composerUrl = buildComposerUrl({
      text: shareText,
      embeds: [`https://wyrd.game/frame/word/${word.id}`],
    });

    // If in frame, use SDK to open composer
    if (await sdk.isInMiniApp()) {
      await sdk.actions.openUrl(composerUrl);
    } else {
      window.open(composerUrl, '_blank');
    }
  };

  return (
    <button onClick={composeShareCast} className="share-button">
      🔓 Share Liberation
    </button>
  );
}

// Generate compelling cast text
function generateLiberationCast(
  word: WordEntry,
  analysis: AnalysisResult,
  insight: string
): string {
  const templates = [
    `🔓 LIBERATED: "${word.word}"\n\n${insight}\n\nWhat words control you? →`,
    `The word "${word.word}" comes from ${analysis.rootOrigin}\n\nBut here's what they don't tell you...\n\n${insight}`,
    `Etymology reveal: "${word.word}"\n\nOriginal meaning: ${analysis.originalMeaning}\n\nNow used to: ${analysis.currentManipulation}\n\n${insight}`,
  ];
  
  return templates[Math.floor(Math.random() * templates.length)];
}
```

### 2.2 Cast Embed Formats

**Standard Word Embed:**
```html
<!-- Dynamic OG image generated for each word -->
<meta property="fc:frame" content="vNext">
<meta property="fc:frame:image" content="https://wyrd.game/api/og/word/{wordId}">
<meta property="og:image" content="https://wyrd.game/api/og/word/{wordId}">
<meta property="fc:frame:button:1" content="🔓 Liberate This Word">
<meta property="fc:frame:button:1:action" content="link">
<meta property="fc:frame:button:1:target" content="https://wyrd.game/frame/word/{wordId}">
<meta property="fc:frame:button:2" content="📚 View All Words">
<meta property="fc:frame:button:2:action" content="link">
<meta property="fc:frame:button:2:target" content="https://wyrd.game/frame">
```

**Daily Challenge Embed:**
```html
<meta property="fc:frame" content="vNext">
<meta property="fc:frame:image" content="https://wyrd.game/api/og/daily">
<meta property="og:image" content="https://wyrd.game/api/og/daily">
<meta property="fc:frame:button:1" content="🎯 Today's Challenge">
<meta property="fc:frame:button:1:action" content="link">
<meta property="fc:frame:button:1:target" content="https://wyrd.game/frame/daily">
<meta property="fc:frame:button:2" content="🏆 Leaderboard">
<meta property="fc:frame:button:2:action" content="link">
<meta property="fc:frame:button:2:target" content="https://wyrd.game/frame/leaderboard">
```

### 2.3 Viral Mechanics

```typescript
// lib/viral.ts

interface ViralMechanics {
  // Challenge streaks
  streakBonus: (streakDays: number) => number;
  
  // Social multipliers
  referralBonus: (referredUserFid: number) => Promise<number>;
  
  // Share rewards
  shareReward: (castHash: string) => Promise<Reward>;
}

export const viralMechanics: ViralMechanics = {
  streakBonus: (streakDays) => {
    // Exponential bonus for consecutive daily plays
    return Math.min(Math.pow(1.5, streakDays), 10);
  },
  
  referralBonus: async (referredFid) => {
    // Check if referred user is new and active
    const isValidReferral = await validateReferral(referredFid);
    return isValidReferral ? 50 : 0;
  },
  
  shareReward: async (castHash) => {
    // Track cast engagement and reward accordingly
    const engagement = await trackCastEngagement(castHash);
    return {
      points: engagement.likes * 2 + engagement.recasts * 5,
      badge: engagement.recasts > 10 ? 'VIRAL_LIBERATOR' : null,
    };
  },
};

// Challenge invite system
export async function createChallengeInvite(
  challengerFid: number,
  wordId: string
): Promise<ChallengeInvite> {
  const invite = {
    id: generateId(),
    challengerFid,
    wordId,
    createdAt: new Date(),
    expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
  };
  
  // Store invite and generate shareable URL
  await storeChallengeInvite(invite);
  
  return invite;
}
```

---

## 3. Composer Actions

### 3.1 Composer Action Definition

```typescript
// app/api/composer/route.ts
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  // Return form configuration for Warpcast composer
  return NextResponse.json({
    type: 'form',
    title: 'Analyze Word with WYRD',
    url: 'https://wyrd.game/frame/scanner?composer=true',
  });
}

export async function GET(req: NextRequest) {
  // Return action metadata
  return NextResponse.json({
    type: 'composer',
    name: 'WYRD Word Analysis',
    icon: 'search', // Valid icon from Farcaster spec
    description: 'Analyze any word through the lens of etymology and liberation',
    aboutUrl: 'https://wyrd.game/about',
    imageUrl: 'https://wyrd.game/composer-icon.png',
    action: {
      type: 'post',
    },
  });
}
```

### 3.2 Composer Action UI

```typescript
// app/frame/scanner/page.tsx
'use client';

import { useState, useEffect } from 'react';
import { sdk } from '@farcaster/miniapp-sdk';

export default function ScannerPage() {
  const [word, setWord] = useState('');
  const [isComposer, setIsComposer] = useState(false);

  useEffect(() => {
    // Check if opened from composer
    const params = new URLSearchParams(window.location.search);
    setIsComposer(params.get('composer') === 'true');
  }, []);

  const handleAnalyze = async () => {
    if (!word.trim()) return;

    // Perform word analysis
    const analysis = await analyzeWord(word);
    
    if (isComposer) {
      // Return cast to Warpcast composer
      window.parent.postMessage(
        {
          type: 'createCast',
          data: {
            cast: {
              text: generateAnalysisCast(word, analysis),
              embeds: [`https://wyrd.game/frame/word/${analysis.wordId}`],
            },
          },
        },
        '*'
      );
    } else {
      // Navigate to word page
      window.location.href = `/frame/word/${analysis.wordId}`;
    }
  };

  return (
    <div className="scanner-container">
      <h1>Word Scanner</h1>
      <p>Enter any word to reveal its hidden etymology</p>
      
      <input
        type="text"
        value={word}
        onChange={(e) => setWord(e.target.value)}
        placeholder="Type a word..."
        className="word-input"
      />
      
      <button onClick={handleAnalyze} className="analyze-button">
        {isComposer ? 'Share Analysis' : '🔓 Liberate'}
      </button>
    </div>
  );
}
```

### 3.3 Available Composer Actions

| Action | Description | Icon |
|--------|-------------|------|
| `wyrd_analyze` | Analyze any word for etymology | search |
| `wyrd_daily` | Share today's daily challenge | calendar |
| `wyrd_challenge` | Challenge a friend to analyze a word | zap |
| `wyrd_liberate` | Quick liberation of common words | unlock |

---

## 4. Identity & Wallet Integration

### 4.1 Farcaster Auth Integration

```typescript
// lib/auth/farcaster.ts
import { createAppClient, viemConnector } from '@farcaster/auth-client';

const appClient = createAppClient({
  relay: 'https://relay.farcaster.xyz',
  ethereum: viemConnector(),
});

export async function generateAuthNonce(): Promise<string> {
  return crypto.randomUUID();
}

export async function verifyFarcasterSignature(
  message: string,
  signature: string,
  fid: number
): Promise<boolean> {
  const { success } = await appClient.verifySignInMessage({
    message,
    signature: signature as `0x${string}`,
    domain: 'wyrd.game',
    nonce: extractNonce(message),
  });
  
  return success;
}

// Link Farcaster identity to WYRD profile
export async function linkFarcasterIdentity(
  fid: number,
  username: string,
  walletAddress?: string
): Promise<UserProfile> {
  // Check if user already exists
  const existingUser = await getUserByFid(fid);
  
  if (existingUser) {
    // Update existing profile
    return await updateUserProfile(existingUser.id, {
      farcasterUsername: username,
      walletAddress,
      lastLogin: new Date(),
    });
  }
  
  // Create new profile
  return await createUserProfile({
    fid,
    farcasterUsername: username,
    walletAddress,
    createdAt: new Date(),
    liberationScore: 0,
    discoveries: [],
  });
}
```

### 4.2 Wallet Connection Patterns

```typescript
// hooks/useFrameWallet.ts
import { sdk } from '@farcaster/miniapp-sdk';
import { useState, useEffect } from 'react';

export function useFrameWallet() {
  const [address, setAddress] = useState<string | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [chainId, setChainId] = useState<number | null>(null);

  useEffect(() => {
    const initWallet = async () => {
      if (await sdk.isInMiniApp()) {
        // Frame provides wallet through EIP-1193 provider
        const provider = sdk.wallet;
        
        if (provider) {
          // Request account access
          const accounts = await provider.request({
            method: 'eth_requestAccounts',
          });
          
          if (accounts && accounts.length > 0) {
            setAddress(accounts[0]);
            setIsConnected(true);
            
            // Get chain ID
            const chain = await provider.request({
              method: 'eth_chainId',
            });
            setChainId(parseInt(chain as string, 16));
          }
        }
      }
    };

    initWallet();
  }, []);

  const sendTransaction = async (tx: TransactionRequest): Promise<string> => {
    const provider = sdk.wallet;
    if (!provider) throw new Error('Wallet not available');

    const txHash = await provider.request({
      method: 'eth_sendTransaction',
      params: [tx],
    });

    return txHash as string;
  };

  const signMessage = async (message: string): Promise<string> => {
    const provider = sdk.wallet;
    if (!provider) throw new Error('Wallet not available');

    const signature = await provider.request({
      method: 'personal_sign',
      params: [message, address],
    });

    return signature as string;
  };

  return {
    address,
    isConnected,
    chainId,
    sendTransaction,
    signMessage,
  };
}
```

### 4.3 NFT Minting Integration

```typescript
// lib/nft/minting.ts
import { encodeFunctionData } from 'viem';

const WYRD_NFT_CONTRACT = '0x...'; // Deployed on Base

interface MintParams {
  wordId: string;
  word: string;
  liberationInsight: string;
  metadataURI: string;
}

export async function mintLiberationNFT(
  wallet: FrameWallet,
  params: MintParams
): Promise<string> {
  const mintData = encodeFunctionData({
    abi: WYRD_NFT_ABI,
    functionName: 'mintLiberation',
    args: [
      params.wordId,
      params.word,
      params.liberationInsight,
      params.metadataURI,
    ],
  });

  const txHash = await wallet.sendTransaction({
    to: WYRD_NFT_CONTRACT,
    data: mintData,
    value: '0', // Or mint price if applicable
  });

  return txHash;
}

// Generate metadata for NFT
export async function generateNFTMetadata(
  word: WordEntry,
  analysis: AnalysisResult,
  userFid: number
): Promise<string> {
  const metadata = {
    name: `WYRD Liberation: ${word.word}`,
    description: `Linguistic liberation of "${word.word}" by FID:${userFid}`,
    image: await generateNFTImage(word, analysis),
    attributes: [
      { trait_type: 'Word', value: word.word },
      { trait_type: 'Origin', value: analysis.rootOrigin },
      { trait_type: 'Liberation Level', value: analysis.liberationScore },
      { trait_type: 'Analyzed By', value: userFid },
    ],
  };

  // Upload to IPFS and return URI
  return await uploadToIPFS(metadata);
}
```

---

## 5. Notification Strategy

### 5.1 Notification Framework

```typescript
// lib/notifications/index.ts
import { sdk } from '@farcaster/miniapp-sdk';

interface NotificationPayload {
  fid: number;
  title: string;
  body: string;
  notificationId: string;
}

export async function sendNotification(
  payload: NotificationPayload
): Promise<boolean> {
  try {
    const response = await fetch('/api/frame/notify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    return response.ok;
  } catch (error) {
    console.error('Failed to send notification:', error);
    return false;
  }
}

// Notification types
export const notificationTemplates = {
  dailyWord: (word: string): NotificationPayload => ({
    fid: 0, // Will be set per user
    title: '🔓 Daily Liberation Ready',
    body: `Today's word is "${word}". Break the spell.`,
    notificationId: `daily-${Date.now()}`,
  }),

  challengeReceived: (fromUsername: string, word: string): NotificationPayload => ({
    fid: 0,
    title: '🎯 Challenge Received!',
    body: `${fromUsername} challenged you to liberate "${word}"`,
    notificationId: `challenge-${Date.now()}`,
  }),

  streakReminder: (streakDays: number): NotificationPayload => ({
    fid: 0,
    title: '🔥 Streak in Danger!',
    body: `Your ${streakDays}-day liberation streak ends in 4 hours.`,
    notificationId: `streak-${Date.now()}`,
  }),

  viralDiscovery: (word: string, engagement: number): NotificationPayload => ({
    fid: 0,
    title: '🌟 Your Liberation Went Viral!',
    body: `"${word}" got ${engagement} reactions. You're changing minds.`,
    notificationId: `viral-${Date.now()}`,
  }),
};
```

### 5.2 Notification Server Handler

```typescript
// app/api/frame/notify/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { neynarClient } from '@/lib/neynar';

export async function POST(req: NextRequest) {
  const { fid, title, body, notificationId } = await req.json();

  try {
    // Store notification in database
    await storeNotification({
      fid,
      title,
      body,
      notificationId,
      sentAt: new Date(),
    });

    // Send via Neynar or Farcaster API
    await neynarClient.sendNotification({
      fid,
      title,
      body,
      notificationId,
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Notification failed:', error);
    return NextResponse.json(
      { success: false, error: 'Notification failed' },
      { status: 500 }
    );
  }
}
```

### 5.3 Scheduled Notifications

```typescript
// lib/notifications/scheduler.ts
import { CronJob } from 'cron';

// Daily word notification (9 AM UTC)
export const dailyWordJob = new CronJob('0 9 * * *', async () => {
  const dailyWord = await getDailyWord();
  const subscribers = await getNotificationSubscribers();

  for (const subscriber of subscribers) {
    await sendNotification({
      ...notificationTemplates.dailyWord(dailyWord.word),
      fid: subscriber.fid,
    });
  }
});

// Streak reminder (8 PM UTC - 4 hours before midnight)
export const streakReminderJob = new CronJob('0 20 * * *', async () => {
  const usersWithStreaks = await getUsersWithActiveStreaks();

  for (const user of usersWithStreaks) {
    const hasPlayedToday = await checkUserPlayedToday(user.fid);
    
    if (!hasPlayedToday) {
      await sendNotification({
        ...notificationTemplates.streakReminder(user.streakDays),
        fid: user.fid,
      });
    }
  }
});
```

---

## 6. Technical Implementation

### 6.1 SDK Usage Patterns

```typescript
// Complete Frame SDK integration example
// app/frame/layout.tsx
'use client';

import { sdk } from '@farcaster/miniapp-sdk';
import { useEffect, useState } from 'react';
import { FrameProvider } from '@/components/FrameProvider';

export default function FrameLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <FrameProvider>
      <div className="frame-container">{children}</div>
    </FrameProvider>
  );
}

// components/FrameProvider.tsx
'use client';

import { sdk, type FrameContext } from '@farcaster/miniapp-sdk';
import { createContext, useContext, useEffect, useState } from 'react';

interface FrameContextType {
  isInFrame: boolean;
  isReady: boolean;
  context: FrameContext | null;
  addFrame: () => Promise<void>;
  signIn: () => Promise<any>;
  openUrl: (url: string) => Promise<void>;
  close: () => Promise<void>;
}

const FrameContext = createContext<FrameContextType | null>(null);

export function FrameProvider({ children }: { children: React.ReactNode }) {
  const [isInFrame, setIsInFrame] = useState(false);
  const [isReady, setIsReady] = useState(false);
  const [context, setContext] = useState<FrameContext | null>(null);

  useEffect(() => {
    const init = async () => {
      const inFrame = await sdk.isInMiniApp();
      setIsInFrame(inFrame);

      if (inFrame) {
        const ctx = await sdk.context;
        setContext(ctx);
        await sdk.actions.ready();
        setIsReady(true);
      }
    };

    init();
  }, []);

  const addFrame = async () => {
    await sdk.actions.addFrame();
  };

  const signIn = async () => {
    return await sdk.actions.signIn({
      nonce: crypto.randomUUID(),
    });
  };

  const openUrl = async (url: string) => {
    await sdk.actions.openUrl(url);
  };

  const close = async () => {
    await sdk.actions.close();
  };

  return (
    <FrameContext.Provider
      value={{ isInFrame, isReady, context, addFrame, signIn, openUrl, close }}
    >
      {children}
    </FrameContext.Provider>
  );
}

export const useFrame = () => {
  const ctx = useContext(FrameContext);
  if (!ctx) throw new Error('useFrame must be used within FrameProvider');
  return ctx;
};
```

### 6.2 Frame Message Validation

```typescript
// lib/frame/validation.ts
import { createPublicClient, http, verifyMessage } from 'viem';
import { mainnet } from 'viem/chains';

interface FrameMessage {
  fid: number;
  timestamp: number;
  url: string;
  buttonIndex?: number;
  inputText?: string;
  state?: string;
  transactionId?: string;
  address?: string;
}

interface TrustedData {
  messageBytes: string;
}

interface FrameRequest {
  untrustedData: FrameMessage;
  trustedData: TrustedData;
}

const publicClient = createPublicClient({
  chain: mainnet,
  transport: http(),
});

export async function validateFrameMessage(
  request: FrameRequest
): Promise<{ isValid: boolean; message?: FrameMessage }> {
  try {
    // Decode the trusted data
    const messageBytes = Buffer.from(request.trustedData.messageBytes, 'hex');
    
    // Verify the message signature against Farcaster hub
    const validationResult = await verifyMessageOnHub(messageBytes);
    
    if (!validationResult.valid) {
      return { isValid: false };
    }

    // Verify timestamp is recent (prevent replay attacks)
    const timestamp = request.untrustedData.timestamp;
    const now = Math.floor(Date.now() / 1000);
    const MAX_AGE = 5 * 60; // 5 minutes
    
    if (now - timestamp > MAX_AGE) {
      return { isValid: false };
    }

    // Verify URL matches expected domain
    const url = new URL(request.untrustedData.url);
    if (url.hostname !== 'wyrd.game') {
      return { isValid: false };
    }

    return { isValid: true, message: request.untrustedData };
  } catch (error) {
    console.error('Frame validation error:', error);
    return { isValid: false };
  }
}

async function verifyMessageOnHub(messageBytes: Buffer): Promise<{ valid: boolean }> {
  // Use Neynar or direct hub API for validation
  const response = await fetch('https://api.neynar.com/v2/farcaster/frame/validate', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'api_key': process.env.NEYNAR_API_KEY!,
    },
    body: JSON.stringify({
      message_bytes_in_hex: messageBytes.toString('hex'),
    }),
  });

  const data = await response.json();
  return { valid: data.valid };
}
```

### 6.3 Transaction Handling

```typescript
// lib/frame/transactions.ts
import { sdk } from '@farcaster/miniapp-sdk';
import { encodeFunctionData, parseEther } from 'viem';

interface TransactionParams {
  to: string;
  data?: string;
  value?: string;
  chainId: number;
}

export async function sendFrameTransaction(
  params: TransactionParams
): Promise<string> {
  const provider = sdk.wallet;
  if (!provider) {
    throw new Error('Wallet not available in frame context');
  }

  // Request transaction through frame
  const txHash = await provider.request({
    method: 'eth_sendTransaction',
    params: [{
      to: params.to,
      data: params.data,
      value: params.value,
    }],
  });

  return txHash as string;
}

// Example: Mint NFT transaction
export async function mintLiberationToken(
  wordId: string,
  word: string
): Promise<string> {
  const mintData = encodeFunctionData({
    abi: WYRD_NFT_ABI,
    functionName: 'mint',
    args: [wordId, word],
  });

  return sendFrameTransaction({
    to: WYRD_NFT_CONTRACT,
    data: mintData,
    chainId: 8453, // Base mainnet
  });
}

// Batch transactions (EIP-5792)
export async function sendBatchTransactions(
  calls: TransactionParams[]
): Promise<string[]> {
  const provider = sdk.wallet;
  if (!provider) {
    throw new Error('Wallet not available');
  }

  // Check if wallet supports batch transactions
  const capabilities = await provider.request({
    method: 'wallet_getCapabilities',
    params: [],
  });

  if (capabilities?.batch) {
    // Use batch transaction API
    const result = await provider.request({
      method: 'wallet_sendCalls',
      params: [{
        version: '1.0',
        from: await getConnectedAddress(),
        calls: calls.map(c => ({
          to: c.to,
          data: c.data,
          value: c.value,
        })),
      }],
    });

    return result as string[];
  }

  // Fallback: Send transactions sequentially
  const hashes: string[] = [];
  for (const call of calls) {
    const hash = await sendFrameTransaction(call);
    hashes.push(hash);
  }

  return hashes;
}
```

---

## 7. Integration Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           FARCASTER CLIENT                                  │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                        WYRD MINI-APP                                │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │   Launch     │  │    Daily     │  │    Word      │              │   │
│  │  │    Page      │──│   Challenge  │──│   Analysis   │              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  │         │                 │                 │                       │   │
│  │         ▼                 ▼                 ▼                       │   │
│  │  ┌─────────────────────────────────────────────────────┐           │   │
│  │  │              Frame SDK Integration                   │           │   │
│  │  │  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌────────┐  │           │   │
│  │  │  │ Context │  │ Actions │  │ Wallet  │  │ Events │  │           │   │
│  │  │  └─────────┘  └─────────┘  └─────────┘  └────────┘  │           │   │
│  │  └─────────────────────────────────────────────────────┘           │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      │ API Calls
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                              WYRD BACKEND                                   │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐    │
│  │    Frame     │  │    Word      │  │    User      │  │ Notification │    │
│  │    API       │  │   Service    │  │   Service    │  │   Service    │    │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘    │
│         │                 │                 │                 │             │
│         └─────────────────┴─────────────────┴─────────────────┘             │
│                                       │                                     │
│                                       ▼                                     │
│                         ┌─────────────────────┐                             │
│                         │   Database/Cache    │                             │
│                         └─────────────────────┘                             │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      │ External APIs
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           EXTERNAL SERVICES                                 │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐    │
│  │   Neynar     │  │    Base      │  │    IPFS      │  │   OpenAI     │    │
│  │   (Farcaster)│  │  (Blockchain)│  │  (Storage)   │  │  (Image Gen) │    │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘    │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 8. Implementation Checklist

### Phase 1: Foundation (Week 1-2)

- [ ] Set up Farcaster Mini-App SDK
- [ ] Create frame manifest.json with proper signing
- [ ] Implement frame layout and provider components
- [ ] Set up frame route structure
- [ ] Add frame message validation endpoint
- [ ] Test in Warpcast debugger

### Phase 2: Core Gameplay (Week 3-4)

- [ ] Port word analysis flow to frame context
- [ ] Implement daily word challenge in frame
- [ ] Create word scanner interface
- [ ] Add user profile/stats page
- [ ] Implement state persistence between sessions

### Phase 3: Social Features (Week 5-6)

- [ ] Build share composition interface
- [ ] Create dynamic OG image generation
- [ ] Implement cast embeds for words
- [ ] Add challenge invite system
- [ ] Set up viral tracking mechanics

### Phase 4: Composer Actions (Week 7)

- [ ] Create composer action endpoints
- [ ] Build word scanner composer UI
- [ ] Implement daily challenge composer action
- [ ] Test composer actions in Warpcast

### Phase 5: Identity & Wallet (Week 8)

- [ ] Integrate Farcaster auth (sign-in with Farcaster)
- [ ] Link Farcaster FID to WYRD profile
- [ ] Add wallet connection via frame
- [ ] Implement NFT minting flow
- [ ] Test transactions on Base

### Phase 6: Notifications (Week 9)

- [ ] Set up notification service
- [ ] Implement daily word notifications
- [ ] Add challenge notification system
- [ ] Create streak reminder notifications
- [ ] Set up notification scheduling

### Phase 7: Launch & Iterate (Week 10+)

- [ ] Deploy to production
- [ ] Submit to Farcaster app directory
- [ ] Monitor analytics and engagement
- [ ] Iterate based on user feedback
- [ ] Add new features based on usage patterns

---

## 9. Environment Variables

```bash
# Farcaster
FARCASTER_DOMAIN=wyrd.game
FARCASTER_ACCOUNT_PRIVATE_KEY=0x...
NEYNAR_API_KEY=...

# Frame
FRAME_SECRET=... # For signing frame responses

# Database
DATABASE_URL=...
REDIS_URL=...

# Blockchain
BASE_RPC_URL=https://mainnet.base.org
BASE_SEPOLIA_RPC_URL=https://sepolia.base.org
WYRD_NFT_CONTRACT=0x...

# Storage
IPFS_API_KEY=...
IPFS_API_SECRET=...

# AI/Image Generation
OPENAI_API_KEY=...
```

---

## 10. Package Dependencies

```json
{
  "dependencies": {
    "@farcaster/miniapp-sdk": "^0.3.0",
    "@farcaster/auth-client": "^0.3.0",
    "@neynar/nodejs-sdk": "^1.0.0",
    "viem": "^2.0.0",
    "wagmi": "^2.0.0",
    "@coinbase/onchainkit": "^0.4.0",
    "react": "^18.0.0",
    "next": "^14.0.0",
    "tailwindcss": "^3.0.0",
    "typescript": "^5.0.0"
  }
}
```

---

## 11. Security Considerations

1. **Message Validation**: Always validate frame messages using trusted data
2. **Replay Protection**: Check timestamps to prevent replay attacks
3. **Origin Verification**: Verify requests come from expected domains
4. **Rate Limiting**: Implement rate limits on API endpoints
5. **Input Sanitization**: Sanitize all user inputs before processing
6. **Wallet Security**: Never store private keys in client-side code
7. **Transaction Validation**: Verify all transaction parameters before signing

---

## 12. Analytics & Monitoring

```typescript
// lib/analytics/frame.ts
export function trackFrameEvent(
  event: string,
  properties: Record<string, any>
) {
  // Track frame-specific events
  analytics.track(`frame_${event}`, {
    ...properties,
    context: 'farcaster_frame',
    timestamp: Date.now(),
  });
}

// Key metrics to track
const frameMetrics = {
  // Engagement
  frame_opens: 'Number of frame opens',
  word_analysis_starts: 'Word analysis initiated',
  word_analysis_completes: 'Word analysis completed',
  shares_initiated: 'Share flows started',
  shares_completed: 'Casts published',
  
  // Social
  challenge_invites_sent: 'Challenge invites created',
  challenge_invites_accepted: 'Challenge invites accepted',
  referral_conversions: 'New users from referrals',
  
  // Monetization
  nfts_minted: 'Liberation NFTs minted',
  transactions_initiated: 'Wallet transactions started',
  transactions_completed: 'Wallet transactions confirmed',
  
  // Retention
  notification_opens: 'Users opening from notifications',
  streak_maintained: 'Users maintaining daily streaks',
  return_visits: 'Users returning within 7 days',
};
```

---

*Document Version: 1.0*
*Last Updated: 2025*
*For WYRD Linguistic Liberation System*
