// WYRD Frame Components - Implementation Code
// These components can be directly used in the WYRD React app

// ============================================
// 1. FrameProvider - Root context provider
// ============================================

'use client';

import { sdk, type FrameContext } from '@farcaster/miniapp-sdk';
import {
  createContext,
  useContext,
  useEffect,
  useState,
  ReactNode,
} from 'react';

interface FrameContextType {
  isInFrame: boolean;
  isReady: boolean;
  context: FrameContext | null;
  addFrame: () => Promise<void>;
  signIn: () => Promise<any>;
  openUrl: (url: string) => Promise<void>;
  close: () => Promise<void>;
  setPrimaryButton: (config: { text: string; enabled?: boolean }) => Promise<void>;
  onPrimaryButtonClick: (callback: () => void) => void;
}

const FrameContext = createContext<FrameContextType | null>(null);

export function FrameProvider({ children }: { children: ReactNode }) {
  const [isInFrame, setIsInFrame] = useState(false);
  const [isReady, setIsReady] = useState(false);
  const [context, setContext] = useState<FrameContext | null>(null);

  useEffect(() => {
    const initFrame = async () => {
      try {
        const inFrame = await sdk.isInMiniApp();
        setIsInFrame(inFrame);

        if (inFrame) {
          const ctx = await sdk.context;
          setContext(ctx);
          await sdk.actions.ready();
          setIsReady(true);
        }
      } catch (error) {
        console.error('Frame initialization failed:', error);
      }
    };

    initFrame();
  }, []);

  const addFrame = async () => {
    if (!isInFrame) return;
    await sdk.actions.addFrame();
  };

  const signIn = async () => {
    if (!isInFrame) return null;
    return await sdk.actions.signIn({
      nonce: crypto.randomUUID(),
    });
  };

  const openUrl = async (url: string) => {
    if (!isInFrame) {
      window.open(url, '_blank');
      return;
    }
    await sdk.actions.openUrl(url);
  };

  const close = async () => {
    if (!isInFrame) return;
    await sdk.actions.close();
  };

  const setPrimaryButton = async (config: { text: string; enabled?: boolean }) => {
    if (!isInFrame) return;
    await sdk.actions.setPrimaryButton(config);
  };

  const onPrimaryButtonClick = (callback: () => void) => {
    if (!isInFrame) return;
    sdk.on('primaryButtonClick', callback);
  };

  return (
    <FrameContext.Provider
      value={{
        isInFrame,
        isReady,
        context,
        addFrame,
        signIn,
        openUrl,
        close,
        setPrimaryButton,
        onPrimaryButtonClick,
      }}
    >
      {children}
    </FrameContext.Provider>
  );
}

export function useFrame() {
  const ctx = useContext(FrameContext);
  if (!ctx) throw new Error('useFrame must be used within FrameProvider');
  return ctx;
}

// ============================================
// 2. FrameSplash - Loading screen for frame
// ============================================

interface FrameSplashProps {
  isReady: boolean;
}

export function FrameSplash({ isReady }: FrameSplashProps) {
  if (isReady) return null;

  return (
    <div className="fixed inset-0 bg-[#1a1a2e] flex flex-col items-center justify-center z-50">
      <div className="w-24 h-24 mb-6 animate-pulse">
        {/* WYRD Logo */}
        <svg viewBox="0 0 100 100" className="w-full h-full text-purple-400">
          <text
            x="50"
            y="65"
            textAnchor="middle"
            className="text-4xl font-bold fill-current"
          >
            W
          </text>
        </svg>
      </div>
      <p className="text-purple-300 text-lg animate-pulse">
        Initializing Liberation...
      </p>
    </div>
  );
}

// ============================================
// 3. WordAnalysisFrame - Main gameplay component
// ============================================

'use client';

import { useState, useEffect } from 'react';
import { useFrame } from './FrameProvider';

interface WordEntry {
  id: string;
  word: string;
  etymology: {
    roots: string[];
    origin: string;
    originalMeaning: string;
  };
  semanticShift: string;
  liberationAngle: string;
}

interface WordAnalysisFrameProps {
  wordId: string;
  wordData: WordEntry;
}

export function WordAnalysisFrame({ wordId, wordData }: WordAnalysisFrameProps) {
  const { isInFrame, setPrimaryButton, onPrimaryButtonClick } = useFrame();
  const [currentStep, setCurrentStep] = useState(0);
  const [isComplete, setIsComplete] = useState(false);

  const steps = [
    { title: 'Surface Reading', content: wordData.word },
    { title: 'Root Excavation', content: wordData.etymology.roots.join(' → ') },
    { title: 'Semantic Shift', content: wordData.semanticShift },
    { title: 'Liberation Angle', content: wordData.liberationAngle },
  ];

  useEffect(() => {
    if (isInFrame) {
      setPrimaryButton({
        text: currentStep < steps.length - 1 ? 'Continue' : 'Liberate',
        enabled: true,
      });

      onPrimaryButtonClick(() => {
        if (currentStep < steps.length - 1) {
          setCurrentStep((prev) => prev + 1);
        } else {
          setIsComplete(true);
        }
      });
    }
  }, [currentStep, isInFrame]);

  if (isComplete) {
    return <LiberationComplete word={wordData} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1a2e] to-[#16213e] p-6">
      {/* Progress indicator */}
      <div className="flex justify-center gap-2 mb-8">
        {steps.map((_, idx) => (
          <div
            key={idx}
            className={`w-3 h-3 rounded-full transition-all ${
              idx <= currentStep ? 'bg-purple-400 w-6' : 'bg-gray-600'
            }`}
          />
        ))}
      </div>

      {/* Step content */}
      <div className="max-w-md mx-auto">
        <div className="text-center mb-8">
          <span className="text-purple-400 text-sm uppercase tracking-wider">
            Step {currentStep + 1} of {steps.length}
          </span>
          <h2 className="text-2xl font-bold text-white mt-2">
            {steps[currentStep].title}
          </h2>
        </div>

        <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-purple-500/20">
          {currentStep === 0 && (
            <div className="text-center">
              <h1 className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400 mb-4">
                {wordData.word}
              </h1>
              <p className="text-gray-400">The word as it appears to you</p>
            </div>
          )}

          {currentStep === 1 && (
            <div className="space-y-4">
              <div className="flex items-center justify-center gap-2 text-2xl">
                {wordData.etymology.roots.map((root, idx) => (
                  <span key={idx} className="text-purple-300">
                    {root}
                    {idx < wordData.etymology.roots.length - 1 && (
                      <span className="text-gray-500 mx-2">→</span>
                    )}
                  </span>
                ))}
              </div>
              <p className="text-center text-gray-400">
                Origin: <span className="text-white">{wordData.etymology.origin}</span>
              </p>
            </div>
          )}

          {currentStep === 2 && (
            <div className="text-center">
              <p className="text-lg text-gray-300 leading-relaxed">
                {wordData.semanticShift}
              </p>
            </div>
          )}

          {currentStep === 3 && (
            <div className="text-center">
              <div className="text-4xl mb-4">🔓</div>
              <p className="text-lg text-purple-300 leading-relaxed">
                {wordData.liberationAngle}
              </p>
            </div>
          )}
        </div>

        {/* Navigation buttons (fallback for non-frame) */}
        {!isInFrame && (
          <div className="mt-8 flex justify-center">
            <button
              onClick={() => {
                if (currentStep < steps.length - 1) {
                  setCurrentStep((prev) => prev + 1);
                } else {
                  setIsComplete(true);
                }
              }}
              className="px-8 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-full font-semibold transition-colors"
            >
              {currentStep < steps.length - 1 ? 'Continue' : '🔓 Liberate'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================
// 4. LiberationComplete - Share screen
// ============================================

interface LiberationCompleteProps {
  word: WordEntry;
}

function LiberationComplete({ word }: LiberationCompleteProps) {
  const { isInFrame, openUrl } = useFrame();
  const [isShared, setIsShared] = useState(false);

  const shareText = `🔓 LIBERATED: "${word.word}"\n\n${word.liberationAngle}\n\nWhat words control you? →`;

  const handleShare = async () => {
    const composerUrl = `https://warpcast.com/~/compose?text=${encodeURIComponent(
      shareText
    )}&embeds[]=${encodeURIComponent(`https://wyrd.game/frame/word/${word.id}`)}`;

    await openUrl(composerUrl);
    setIsShared(true);
  };

  const handleMint = async () => {
    // Navigate to minting flow
    window.location.href = `/frame/mint/${word.id}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1a2e] to-[#16213e] p-6 flex flex-col items-center justify-center">
      <div className="text-center mb-8">
        <div className="text-6xl mb-4">🎉</div>
        <h2 className="text-3xl font-bold text-white mb-2">Word Liberated!</h2>
        <p className="text-gray-400">
          You've uncovered the hidden meaning of "{word.word}"
        </p>
      </div>

      <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-purple-500/20 max-w-md w-full mb-8">
        <div className="flex items-center justify-between mb-4">
          <span className="text-gray-400">Liberation Score</span>
          <span className="text-2xl font-bold text-purple-400">+100</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-gray-400">Words Liberated</span>
          <span className="text-2xl font-bold text-pink-400">1</span>
        </div>
      </div>

      <div className="flex flex-col gap-4 w-full max-w-md">
        <button
          onClick={handleShare}
          className="w-full py-4 bg-purple-600 hover:bg-purple-700 text-white rounded-xl font-semibold transition-colors flex items-center justify-center gap-2"
        >
          <span>🔓</span>
          Share Liberation
        </button>

        <button
          onClick={handleMint}
          className="w-full py-4 bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700 text-white rounded-xl font-semibold transition-colors flex items-center justify-center gap-2"
        >
          <span>🏆</span>
          Mint as NFT
        </button>

        <button
          onClick={() => (window.location.href = '/frame')}
          className="w-full py-4 bg-white/10 hover:bg-white/20 text-white rounded-xl font-semibold transition-colors"
        >
          Liberate Another Word
        </button>
      </div>

      {isShared && (
        <div className="mt-6 text-green-400 flex items-center gap-2">
          <span>✓</span>
          <span>Cast composer opened!</span>
        </div>
      )}
    </div>
  );
}

// ============================================
// 5. DailyChallengeFrame - Daily word component
// ============================================

interface DailyChallengeFrameProps {
  word: WordEntry;
  dayNumber: number;
  userStreak: number;
}

export function DailyChallengeFrame({
  word,
  dayNumber,
  userStreak,
}: DailyChallengeFrameProps) {
  const { isInFrame } = useFrame();

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1a2e] to-[#16213e] p-6">
      {/* Header */}
      <div className="flex justify-between items-center mb-8">
        <div>
          <span className="text-purple-400 text-sm uppercase tracking-wider">
            Daily Challenge
          </span>
          <h1 className="text-2xl font-bold text-white">Day #{dayNumber}</h1>
        </div>
        <div className="bg-orange-500/20 px-4 py-2 rounded-full">
          <span className="text-orange-400 font-semibold">🔥 {userStreak} day streak</span>
        </div>
      </div>

      {/* Word card */}
      <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-purple-500/20 text-center mb-8">
        <p className="text-gray-400 mb-4">Today's word to liberate:</p>
        <h2 className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">
          {word.word}
        </h2>
      </div>

      {/* Challenge info */}
      <div className="bg-white/5 rounded-xl p-6 mb-8">
        <h3 className="text-white font-semibold mb-3">Today's Challenge</h3>
        <ul className="space-y-2 text-gray-400">
          <li className="flex items-center gap-2">
            <span className="text-purple-400">✓</span>
            Complete the 4-step analysis
          </li>
          <li className="flex items-center gap-2">
            <span className="text-purple-400">✓</span>
            Share your liberation
          </li>
          <li className="flex items-center gap-2">
            <span className="text-purple-400">✓</span>
            Maintain your streak
          </li>
        </ul>
      </div>

      {/* CTA */}
      <button
        onClick={() => (window.location.href = `/frame/word/${word.id}`)}
        className="w-full py-4 bg-purple-600 hover:bg-purple-700 text-white rounded-xl font-semibold transition-colors"
      >
        🔓 Start Liberation
      </button>
    </div>
  );
}

// ============================================
// 6. WordScannerFrame - Input any word
// ============================================

'use client';

import { useState } from 'react';

export function WordScannerFrame() {
  const [word, setWord] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const handleAnalyze = async () => {
    if (!word.trim()) return;

    setIsAnalyzing(true);

    // Check if word exists in database
    const response = await fetch(`/api/words/search?q=${encodeURIComponent(word)}`);
    const data = await response.json();

    if (data.found) {
      window.location.href = `/frame/word/${data.wordId}`;
    } else {
      // Generate analysis on-the-fly or show "not found"
      window.location.href = `/frame/scanner/result?word=${encodeURIComponent(word)}`;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1a2e] to-[#16213e] p-6 flex flex-col">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">Word Scanner</h1>
        <p className="text-gray-400">Enter any word to reveal its hidden etymology</p>
      </div>

      <div className="flex-1 flex flex-col justify-center max-w-md mx-auto w-full">
        <div className="relative mb-6">
          <input
            type="text"
            value={word}
            onChange={(e) => setWord(e.target.value)}
            placeholder="Type a word..."
            className="w-full px-6 py-4 bg-white/5 border border-purple-500/30 rounded-xl text-white text-xl text-center placeholder-gray-500 focus:outline-none focus:border-purple-500 transition-colors"
            onKeyDown={(e) => e.key === 'Enter' && handleAnalyze()}
          />
          {word && (
            <button
              onClick={() => setWord('')}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white"
            >
              ✕
            </button>
          )}
        </div>

        <button
          onClick={handleAnalyze}
          disabled={!word.trim() || isAnalyzing}
          className="w-full py-4 bg-purple-600 hover:bg-purple-700 disabled:bg-gray-700 disabled:cursor-not-allowed text-white rounded-xl font-semibold transition-colors flex items-center justify-center gap-2"
        >
          {isAnalyzing ? (
            <>
              <span className="animate-spin">⟳</span>
              Scanning...
            </>
          ) : (
            <>
              <span>🔍</span>
              Analyze Word
            </>
          )}
        </button>
      </div>

      {/* Quick suggestions */}
      <div className="mt-8">
        <p className="text-gray-500 text-sm mb-3">Popular scans:</p>
        <div className="flex flex-wrap gap-2">
          {['government', 'money', 'education', 'freedom', 'reality'].map((w) => (
            <button
              key={w}
              onClick={() => setWord(w)}
              className="px-3 py-1 bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white rounded-full text-sm transition-colors"
            >
              {w}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ============================================
// 7. UserProfileFrame - Stats and achievements
// ============================================

interface UserStats {
  fid: number;
  username: string;
  displayName: string;
  pfpUrl?: string;
  liberationScore: number;
  wordsLiberated: number;
  currentStreak: number;
  longestStreak: number;
  recentDiscoveries: string[];
  badges: string[];
}

interface UserProfileFrameProps {
  stats: UserStats;
}

export function UserProfileFrame({ stats }: UserProfileFrameProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1a2e] to-[#16213e] p-6">
      {/* Profile header */}
      <div className="flex items-center gap-4 mb-8">
        {stats.pfpUrl ? (
          <img
            src={stats.pfpUrl}
            alt={stats.displayName}
            className="w-16 h-16 rounded-full border-2 border-purple-500"
          />
        ) : (
          <div className="w-16 h-16 rounded-full bg-purple-600 flex items-center justify-center text-2xl font-bold text-white">
            {stats.displayName[0]}
          </div>
        )}
        <div>
          <h1 className="text-xl font-bold text-white">{stats.displayName}</h1>
          <p className="text-gray-400">@{stats.username}</p>
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 gap-4 mb-8">
        <div className="bg-white/5 rounded-xl p-4 text-center">
          <p className="text-3xl font-bold text-purple-400">{stats.liberationScore}</p>
          <p className="text-gray-400 text-sm">Liberation Score</p>
        </div>
        <div className="bg-white/5 rounded-xl p-4 text-center">
          <p className="text-3xl font-bold text-pink-400">{stats.wordsLiberated}</p>
          <p className="text-gray-400 text-sm">Words Liberated</p>
        </div>
        <div className="bg-white/5 rounded-xl p-4 text-center">
          <p className="text-3xl font-bold text-orange-400">{stats.currentStreak}</p>
          <p className="text-gray-400 text-sm">Current Streak</p>
        </div>
        <div className="bg-white/5 rounded-xl p-4 text-center">
          <p className="text-3xl font-bold text-green-400">{stats.longestStreak}</p>
          <p className="text-gray-400 text-sm">Best Streak</p>
        </div>
      </div>

      {/* Badges */}
      {stats.badges.length > 0 && (
        <div className="mb-8">
          <h2 className="text-white font-semibold mb-3">Badges</h2>
          <div className="flex flex-wrap gap-2">
            {stats.badges.map((badge) => (
              <span
                key={badge}
                className="px-3 py-1 bg-purple-500/20 text-purple-300 rounded-full text-sm"
              >
                {badge}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Recent discoveries */}
      {stats.recentDiscoveries.length > 0 && (
        <div className="mb-8">
          <h2 className="text-white font-semibold mb-3">Recent Liberations</h2>
          <div className="space-y-2">
            {stats.recentDiscoveries.map((word) => (
              <div
                key={word}
                className="flex items-center justify-between bg-white/5 rounded-lg p-3"
              >
                <span className="text-white">{word}</span>
                <span className="text-purple-400">✓</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Actions */}
      <div className="flex gap-4">
        <button
          onClick={() => (window.location.href = '/frame/daily')}
          className="flex-1 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-xl font-semibold transition-colors"
        >
          Daily Challenge
        </button>
        <button
          onClick={() => (window.location.href = '/frame/scanner')}
          className="flex-1 py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl font-semibold transition-colors"
        >
          Scan Word
        </button>
      </div>
    </div>
  );
}

// ============================================
// 8. ShareComposer - Cast composition helper
// ============================================

interface ShareComposerProps {
  word: WordEntry;
  onShare?: () => void;
}

export function ShareComposer({ word, onShare }: ShareComposerProps) {
  const { isInFrame, openUrl } = useFrame();
  const [selectedTemplate, setSelectedTemplate] = useState(0);

  const templates = [
    {
      label: 'Standard',
      text: `🔓 LIBERATED: "${word.word}"\n\n${word.liberationAngle}\n\nWhat words control you? →`,
    },
    {
      label: 'Revelation',
      text: `The word "${word.word}" comes from ${word.etymology.origin}\n\nBut here's what they don't tell you...\n\n${word.liberationAngle}`,
    },
    {
      label: 'Question',
      text: `Did you know "${word.word}" originally meant "${word.etymology.originalMeaning}"?\n\nNow it's used to control. Time to liberate.\n\n${word.liberationAngle}`,
    },
  ];

  const handleShare = async () => {
    const template = templates[selectedTemplate];
    const composerUrl = `https://warpcast.com/~/compose?text=${encodeURIComponent(
      template.text
    )}&embeds[]=${encodeURIComponent(`https://wyrd.game/frame/word/${word.id}`)}`;

    await openUrl(composerUrl);
    onShare?.();
  };

  return (
    <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-purple-500/20">
      <h3 className="text-white font-semibold mb-4">Share Your Liberation</h3>

      {/* Template selector */}
      <div className="flex gap-2 mb-4">
        {templates.map((t, idx) => (
          <button
            key={idx}
            onClick={() => setSelectedTemplate(idx)}
            className={`px-3 py-1 rounded-full text-sm transition-colors ${
              selectedTemplate === idx
                ? 'bg-purple-600 text-white'
                : 'bg-white/10 text-gray-400 hover:text-white'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Preview */}
      <div className="bg-black/30 rounded-xl p-4 mb-4">
        <p className="text-gray-300 whitespace-pre-line text-sm">
          {templates[selectedTemplate].text}
        </p>
      </div>

      {/* Share button */}
      <button
        onClick={handleShare}
        className="w-full py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-xl font-semibold transition-colors flex items-center justify-center gap-2"
      >
        <span>📤</span>
        Share on Warpcast
      </button>
    </div>
  );
}

// ============================================
// 9. FrameLayout - Wrapper with splash
// ============================================

'use client';

import { ReactNode } from 'react';
import { useFrame, FrameProvider } from './FrameProvider';
import { FrameSplash } from './FrameSplash';

function FrameLayoutInner({ children }: { children: ReactNode }) {
  const { isReady } = useFrame();

  return (
    <>
      <FrameSplash isReady={isReady} />
      {children}
    </>
  );
}

export function FrameLayout({ children }: { children: ReactNode }) {
  return (
    <FrameProvider>
      <FrameLayoutInner>{children}</FrameLayoutInner>
    </FrameProvider>
  );
}

// ============================================
// 10. AddToHome - Prompt to add frame
// ============================================

export function AddToHomePrompt() {
  const { isInFrame, addFrame, context } = useFrame();
  const [isAdded, setIsAdded] = useState(context?.client.added ?? false);

  if (!isInFrame || isAdded) return null;

  const handleAdd = async () => {
    await addFrame();
    setIsAdded(true);
  };

  return (
    <div className="fixed bottom-4 left-4 right-4 bg-purple-600 rounded-xl p-4 shadow-lg z-40">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-white font-semibold">Add WYRD to your home</p>
          <p className="text-purple-200 text-sm">Quick access to daily liberations</p>
        </div>
        <button
          onClick={handleAdd}
          className="px-4 py-2 bg-white text-purple-600 rounded-lg font-semibold"
        >
          Add
        </button>
      </div>
    </div>
  );
}

// ============================================
// Export all components
// ============================================

export {
  FrameProvider,
  useFrame,
  FrameSplash,
  WordAnalysisFrame,
  DailyChallengeFrame,
  WordScannerFrame,
  UserProfileFrame,
  ShareComposer,
  FrameLayout,
  AddToHomePrompt,
};
