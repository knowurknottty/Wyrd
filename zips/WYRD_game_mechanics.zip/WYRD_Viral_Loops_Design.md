# WYRD Viral Loops Design Document
## Linguistic Liberation System - Growth Strategy

**Document Version:** 1.0  
**Target Viral Coefficient (K):** 0.8 (initial) → 1.2 (mature)  
**Estimated User Acquisition Cost:** $0.50-2.00 (organic) | $5-15 (paid)  
**Primary Growth Channel:** Farcaster + Word-of-Mouth

---

## Executive Summary

WYRD's viral strategy leverages the inherently shareable nature of etymology revelations—"mind-blown" moments that people naturally want to share. By combining linguistic discovery with crypto-native mechanics (points, airdrops, quests), we create multiple viral loops that compound over time.

### Core Viral Hypothesis
> *"When someone learns that 'salary' comes from 'salt' (Roman soldiers were paid in salt), they don't keep it to themselves—they tell 3 friends."*

---

## 1. SHAREABLE MOMENTS

### 1.1 The "Mind-Blown" Revelation Framework

**What Creates Shareable Moments:**

| Revelation Type | Example | Share Probability |
|----------------|---------|-------------------|
| **Etymology Shock** | "Disaster = dis (bad) + aster (star) → bad star omen" | 85% |
| **Hidden Power Structure** | "Government = gubernare (to steer) → who chooses the destination?" | 92% |
| **Everyday Word Origin** | "Salary = salt (Roman soldier payment)" | 78% |
| **Inversion Detection** | "Freedom = free + dom (domain/condition) → condition of being free" | 88% |
| **Cross-Language Connection** | "Ghost = gust (German: guest) → spirit as visitor" | 75% |

### 1.2 Share Card System

**Visual Share Formats:**

#### Format A: The Revelation Card
```
┌─────────────────────────────────────┐
│  🔮 WYRD REVELATION                 │
│                                     │
│  DISASTER                           │
│  ═══════════                        │
│                                     │
│  Surface: Catastrophic event        │
│                                     │
│  Root: dis (bad) + aster (star)     │
│                                     │
│  💫 The ancients blamed bad luck    │
│     on misaligned stars             │
│                                     │
│  [Unlock more at wyrd.game]         │
└─────────────────────────────────────┘
```

#### Format B: The Liberation Frame
```
┌─────────────────────────────────────┐
│                                     │
│  "GOVERNMENT"                       │
│                                     │
│  From Latin "gubernare"             │
│  = to steer a ship                  │
│                                     │
│  🚢 Who chooses the destination?    │
│                                     │
│  Linguistic liberation via @wyrd    │
│                                     │
└─────────────────────────────────────┘
```

#### Format C: The Comparison Split
```
┌──────────────────┬──────────────────┐
│   WHAT YOU SEE   │  WHAT IT MEANS   │
├──────────────────┼──────────────────┤
│   SALARY         │  SALT MONEY      │
│   ═══════        │  ═══════════     │
│   Your paycheck  │  Roman soldiers  │
│                  │  were paid in    │
│                  │  salt            │
├──────────────────┼──────────────────┤
│   [Share]        │  [Discover More] │
└──────────────────┴──────────────────┘
```

### 1.3 Share Triggers & Timing

**Optimal Share Moments:**

| Trigger Point | Action | Reward |
|--------------|--------|--------|
| Complete word analysis | Show share modal | +50 WYRD points |
| Discover "rare" word (<5% of users found) | Auto-generate share card | +100 WYRD points |
| Complete Daily Word streak (7 days) | Unlock special share frame | +200 WYRD points |
| Find connection between 2 words | Create comparison share | +75 WYRD points |
| Submit word suggestion (approved) | Share contributor badge | +500 WYRD points |

### 1.4 Social Media Templates

**Farcaster Cast Template:**
```
🔮 WYRD REVELATION

"[WORD]"

Surface: [surface meaning]
Root: [etymology]
The twist: [liberation angle]

Your mind = blown 🤯

→ wyrd.game/daily

@wyrd #LinguisticLiberation
```

**Twitter/X Template:**
```
Just learned that "[WORD]" comes from [etymology]

My whole worldview shifted.

Discover more linguistic revelations at wyrd.game 🔮

#Etymology #WordOrigins #WYRD
```

**Warpcast Embed Format:**
- Frame displays word + root
- "Reveal" button shows liberation angle
- "Share" button generates cast with embed

---

## 2. REFERRAL MECHANICS

### 2.1 Dual-Sided Referral System

**The WYRD Invitation Flow:**

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   Inviter   │────→│   Invite    │────→│   New User  │
│  (Existing) │     │   Link/Code │     │  (Referred) │
└─────────────┘     └─────────────┘     └─────────────┘
       │                                     │
       │         ┌─────────────┐            │
       └────────→│   On-Chain  │←───────────┘
                 │  Attribution│
                 └─────────────┘
```

**Referral Rewards:**

| Action | Inviter Reward | New User Reward |
|--------|---------------|-----------------|
| Sign up via referral | +200 WYRD points | +100 WYRD points |
| Complete first word analysis | +100 WYRD points | +50 WYRD points |
| 7-day streak | +500 WYRD points | +250 WYRD points |
| Submit approved word | +1000 WYRD points | +500 WYRD points |
| Referral hits 10 invites | +5000 WYRD points | - |

### 2.2 Referral Tracking System

**Technical Implementation:**
- **Method 1:** Unique referral codes (e.g., `WYRD-ALICE-123`)
- **Method 2:** Farcaster frame embeds with attribution
- **Method 3:** On-chain attestation (EAS - Ethereum Attestation Service)
- **Method 4:** Wallet connection mapping

**Attribution Chain:**
```
User A invites User B → EAS attestation created
User B invites User C → EAS attestation created
User C action → Rewards flow to B and A (10% each level up)
```

### 2.3 Tiered Referral Program

**WYRD Advocate Tiers:**

| Tier | Invites Required | Benefits |
|------|-----------------|----------|
| **Seeker** | 0-2 | Basic referral link |
| **Apprentice** | 3-5 | 2x referral points, custom invite code |
| **Scholar** | 6-10 | 3x points, early access to new words |
| **Luminary** | 11-25 | 4x points, exclusive word pack, POAP |
| **Oracle** | 26-50 | 5x points, governance rights, name in credits |
| **Archon** | 51+ | 10x points, revenue share, advisory role |

### 2.4 Viral Coefficient Optimization

**Target Metrics:**

| Metric | Target | Current Estimate |
|--------|--------|------------------|
| K-factor (viral coefficient) | 0.8 → 1.2 | 0.4 |
| Invite conversion rate | 25% | 15% |
| Shares per active user/week | 2.5 | 0.8 |
| Referral-driven signups | 40% | 20% |

**Optimization Tactics:**
1. **Social Proof in Invite:** Show "[X] friends joined this week"
2. **Scarcity:** "Only [Y] invites left at this reward level"
3. **Progress Visualization:** Show friend's progress toward first reward
4. **Reminders:** Gentle nudge when friend completes milestone

---

## 3. SOCIAL PROOF ELEMENTS

### 3.1 Public Leaderboards

**Leaderboard Categories:**

| Leaderboard | Metric | Update Frequency |
|------------|--------|-----------------|
| **Daily Streak** | Consecutive days played | Real-time |
| **Words Liberated** | Total words analyzed | Real-time |
| **Knowledge Score** | Accuracy + depth | Weekly |
| **Community Builder** | Successful referrals | Daily |
| **Word Contributor** | Submitted + approved words | Weekly |
| **Inversion Hunter** | Rare inversions found | Monthly |

**Leaderboard Display:**
- Top 100 publicly visible
- User's rank always visible (even if not in top 100)
- Percentile ranking ("Top 5% of liberators")
- Friend-only leaderboard option

### 3.2 Achievement System

**WYRD Badge Collection:**

| Badge | Requirement | Rarity |
|-------|-------------|--------|
| 🌱 **First Step** | Complete first word analysis | Common |
| 🔥 **Week Warrior** | 7-day streak | Common |
| 🌟 **Month Master** | 30-day streak | Uncommon |
| 💎 **Century Club** | 100 words analyzed | Uncommon |
| 🔮 **Truth Seeker** | Find 10 inversions | Rare |
| 🏛️ **Etymologist** | Submit 5 approved words | Rare |
| 🌊 **Viral Vector** | 10 successful referrals | Epic |
| 👑 **Liberator** | All 222 words analyzed | Legendary |
| ⚡ **Speed Demon** | Complete analysis in <30s | Secret |
| 🎭 **Double Meaning** | Find word with 3+ roots | Secret |

### 3.3 Community Challenges

**Weekly Challenge Structure:**

```
┌─────────────────────────────────────────────────────┐
│  THIS WEEK'S CHALLENGE                              │
│  ═════════════════════                              │
│                                                     │
│  🔍 THE HUNT: Find words with Latin roots           │
│                                                     │
│  Progress: 23/50 words found                        │
│  [████████████████░░░░░░░░░░░░░░░░░░░░] 46%         │
│                                                     │
│  Community Progress: 1,247/5,000                    │
│  [████████████░░░░░░░░░░░░░░░░░░░░░░░░] 25%         │
│                                                     │
│  Reward: 500 WYRD points + exclusive POAP           │
│  Time remaining: 3 days 14 hours                    │
│                                                     │
└─────────────────────────────────────────────────────┘
```

**Challenge Types:**
1. **Collective Hunt:** Community finds X words with Y characteristic
2. **Speed Run:** Fastest time to complete 10 daily words
3. **Creative Challenge:** Best user-submitted liberation angle (voted)
4. **Streak Challenge:** Most users maintaining 7+ day streak
5. **Referral Sprint:** Most referrals in a week

### 3.4 Collective Milestones

**Community Unlock System:**

| Milestone | Requirement | Unlock |
|-----------|-------------|--------|
| **Genesis** | 1,000 total words analyzed | New word pack: "Power Words" |
| **Awakening** | 10,000 words analyzed | Community word submission opens |
| **Expansion** | 100,000 words analyzed | New feature: Word Battles |
| **Liberation** | 1M words analyzed | Token launch + airdrop |
| **Transcendence** | 10M words analyzed | WYRD DAO formation |

**Milestone Visualization:**
- Global progress bar on homepage
- Individual contribution shown ("You contributed 0.3% to this milestone")
- Celebration animation when milestone reached
- Special rewards for contributors during milestone period

---

## 4. NETWORK EFFECTS

### 4.1 Value Multiplication Framework

**How WYRD Becomes More Valuable with More Users:**

```
Users ↑ → More word submissions ↑ → Larger database ↑ → More discoveries ↑ → More sharing ↑ → Users ↑
     ↑___________________________________________________________________________________________↓
```

**Network Effect Vectors:**

| Vector | Solo Value | Network Value | Multiplier |
|--------|-----------|---------------|------------|
| Word database | 222 words | 222 + community words | 2-5x |
| Discoveries | Personal only | Shared, discussed | 3-10x |
| Challenges | Single-player | Competitive, collaborative | 2-3x |
| Learning | Linear | Social reinforcement | 2-4x |
| Content | Static | Dynamic, crowdsourced | 5-20x |

### 4.2 Community-Generated Content Loops

**User Contribution Flywheel:**

```
┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│ User plays  │───→│ Has insight │───→│ Submits     │
│ WYRD        │    │ about word  │    │ word/angle  │
└─────────────┘    └─────────────┘    └─────────────┘
                                              │
       ┌──────────────────────────────────────┘
       │
       ▼
┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│ Community   │←───│ Approved &  │←───│ Moderation  │
│ engages     │    │ published   │    │ & voting    │
└─────────────┘    └─────────────┘    └─────────────┘
       │
       └──────────────────────────────────────┐
                                              ▼
                                       ┌─────────────┐
                                       │ User earns  │
                                       │ rewards &   │
                                       │ reputation  │
                                       └─────────────┘
```

**Content Contribution Types:**

| Contribution Type | Submission | Review | Reward |
|------------------|------------|--------|--------|
| New word entry | Full etymology | Community + team | 1000 WYRD |
| Liberation angle | Alternative angle | Voting | 200 WYRD |
| Word connection | Link 2+ words | Auto-approve | 100 WYRD |
| Etymology correction | Fix error | Team verify | 500 WYRD |
| Translation | Word in other language | Community | 300 WYRD |

### 4.3 Social Discovery Features

**Friend Activity Feed:**
```
┌─────────────────────────────────────────────────────┐
│  FRIEND ACTIVITY                                      │
│  ═══════════════                                      │
│                                                       │
│  @alice just liberated "GOVERNMENT" 🔥               │
│  "Who chooses the destination?"                      │
│  [View] [React]                                       │
│                                                       │
│  @bob found a rare inversion in "PERSON" 👀          │
│  [View] [Challenge]                                   │
│                                                       │
│  @carol started a 7-day streak! 🌟                   │
│  [Cheer]                                              │
│                                                       │
└─────────────────────────────────────────────────────┘
```

**Discovery Mechanisms:**
1. **Friend Streaks:** See friends' daily streaks, cheer them on
2. **Word Battles:** Challenge friends to analyze same word, compare angles
3. **Shared Collections:** Create and share word lists
4. **Co-discovery:** Find words with friends simultaneously
5. **Mention System:** Tag friends in word discoveries

### 4.4 Cross-Pollination Features

**Integration Points:**

| Platform | Integration | Viral Effect |
|----------|-------------|--------------|
| **Farcaster** | Frame embeds, casts | Native sharing |
| **Lens** | Post word discoveries | Cross-chain growth |
| **Twitter/X** | Share cards | Mainstream reach |
| **Discord** | Bot + channel integration | Community depth |
| **Telegram** | Mini-app + bot | Global reach |

---

## 5. CRYPTO-NATIVE GROWTH TACTICS

### 5.1 Points System (WYRD Points)

**Points Economy:**

| Activity | Points | Daily Cap |
|----------|--------|-----------|
| Complete word analysis | 50 | 500 |
| Share discovery | 25 | 250 |
| Daily word completion | 100 | 100 |
| Streak bonus (7d) | 500 | 500 |
| Streak bonus (30d) | 2000 | 2000 |
| Referral signup | 200 | unlimited |
| Referral activity | 100 | unlimited |
| Submit approved word | 1000 | 1000 |
| Win challenge | 500-5000 | varies |
| Community vote winner | 1000 | 1000 |

**Points Utility:**
1. **Leaderboard ranking**
2. **Exclusive word packs unlock**
3. **Early access to features**
4. **Governance weight (future)**
5. **Token allocation multiplier (future)**

### 5.2 Airdrop Strategy

**WYRD Token Airdrop Framework:**

**Phase 1: Pre-Announcement (Current)**
- Points accumulate without token mention
- Create organic usage patterns
- Build genuine community

**Phase 2: Soft Announcement (Month 3)**
- "Points may have future utility"
- Increase engagement
- Filter farmers from genuine users

**Phase 3: Snapshot Announcement (Month 6)**
- Multiplier system revealed
- Final push for engagement
- Anti-sybil measures activated

**Airdrop Allocation:**

| Category | Allocation % | Criteria |
|----------|--------------|----------|
| **Early Adopters** | 30% | Pre-announcement activity |
| **Power Users** | 25% | Top 10% by points |
| **Contributors** | 20% | Submitted approved content |
| **Referrers** | 15% | Successful referrals |
| **Community** | 10% | Random weighted by activity |

**Anti-Sybil Measures:**
1. Minimum 14-day activity period
2. Farcaster account age > 30 days
3. Gitcoin Passport score > 20
4. Unique wallet + social graph analysis
5. Behavioral pattern detection

### 5.3 Quest System

**Quest Categories:**

| Quest Type | Example | Reward |
|------------|---------|--------|
| **Daily** | Analyze 3 words today | 150 WYRD |
| **Weekly** | Find 5 Latin-root words | 500 WYRD |
| **Monthly** | Maintain 30-day streak | 5000 WYRD |
| **One-Time** | Connect wallet | 100 WYRD |
| **Social** | Share 5 discoveries | 250 WYRD |
| **Creative** | Submit word entry | 1000 WYRD |
| **Competitive** | Top 10 this week | 2000 WYRD |

**Quest UI:**
```
┌─────────────────────────────────────────────────────┐
│  ACTIVE QUESTS                                      │
│  ═════════════                                      │
│                                                     │
│  📅 Daily Quest (Resets in 8h)                     │
│  [████████████████████░░░░] 4/5 words              │
│  Reward: 150 WYRD                                   │
│                                                     │
│  🗓️ Weekly Quest (3 days left)                     │
│  [████████░░░░░░░░░░░░░░░░] 2/5 Latin words        │
│  Reward: 500 WYRD                                   │
│                                                     │
│  🎯 Special Quest                                   │
│  Refer 3 friends → 2 joined!                       │
│  [████████████░░░░░░░░░░░░] 2/3                    │
│  Reward: 1000 WYRD + "Connector" badge             │
│                                                     │
└─────────────────────────────────────────────────────┘
```

### 5.4 POAP Integration

**WYRD POAP Collection:**

| POAP | Requirement | Rarity |
|------|-------------|--------|
| **Genesis Player** | Played in first month | Limited (est. 500) |
| **Streak Master** | 30-day streak | Uncommon |
| **Word Liberator** | 100 words analyzed | Common |
| **Community Founder** | Referred 10+ users | Rare |
| **Etymology Sage** | 5 words approved | Rare |
| **Event Attendee** | Join WYRD spaces/AMA | Per event |
| **Challenge Winner** | Win weekly challenge | Weekly limited |
| **Milestone Witness** | Active during major milestone | Per milestone |

**POAP Utility:**
- Display on Farcaster profile
- Future token allocation boost
- Exclusive channel access
- Governance voting power
- Merch discounts

---

## 6. FARCASTER-SPECIFIC VIRAL MECHANICS

### 6.1 Frame-Based Viral Loops

**WYRD Frame Types:**

#### Frame 1: Daily Word Reveal
```
┌─────────────────────────────────────┐
│  🔮 WYRD DAILY                      │
│                                     │
│  Today's word: [REDACTED]           │
│                                     │
│  [Reveal Origin] [Share Discovery]  │
│                                     │
│  1,247 liberators today             │
└─────────────────────────────────────┘
```

#### Frame 2: Word Battle Challenge
```
┌─────────────────────────────────────┐
│  ⚔️ WORD BATTLE                     │
│                                     │
│  @alice challenges you!             │
│                                     │
│  Word: "DEMOCRACY"                  │
│                                     │
│  [Accept Challenge] [Decline]       │
│                                     │
│  Winner gets 100 WYRD points        │
└─────────────────────────────────────────────────────┘
```

#### Frame 3: Community Milestone
```
┌─────────────────────────────────────┐
│  🎉 MILESTONE UNLOCKED!             │
│                                     │
│  10,000 words liberated!            │
│                                     │
│  You contributed 23 🙌               │
│                                     │
│  [Claim POAP] [Share Victory]       │
└─────────────────────────────────────┘
```

### 6.2 Channel Strategy

**Primary Channel: /wyrd**

**Channel Content Mix:**

| Content Type | Frequency | Purpose |
|--------------|-----------|---------|
| Daily Word | Daily | Engagement |
| Revelation Thread | 3x/week | Education |
| Community Spotlight | Weekly | Recognition |
| Challenge Announcement | Weekly | Participation |
| Milestone Celebration | Per milestone | Community |
| AMA/Spaces | Monthly | Deep engagement |

**Channel Growth Tactics:**
1. **Cross-post to related channels:** /etymology, /philosophy, /wordgames
2. **Partner with Farcaster influencers:** Power badge holders
3. **Channel-exclusive drops:** Early access, special POAPs
4. **Community moderation:** Active member rewards

### 6.3 Power Badge Holder Incentives

**Power Badge Benefits:**

| Benefit | Description |
|---------|-------------|
| **2x Points** | All WYRD points earned are doubled |
| **Early Access** | New features 48h before public |
| **Exclusive Words** | Special word pack only for power badges |
| **Direct Line** | Priority support + feedback channel |
| **Recognition** | Special badge display in app |
| **Airdrop Boost** | 1.5x token allocation multiplier |

**Power Badge Activation:**
- Auto-detected via Farcaster API
- Benefits activate immediately
- Special onboarding flow
- Exclusive welcome message

### 6.4 Cast-Based Challenges

**Cast Challenge Formats:**

#### Format 1: Word of the Day Cast
```
🔮 WYRD Daily Word #127

"[WORD]"

Can you guess the origin before revealing?

→ Frame: [Reveal]

#WYRD #DailyWord @wyrd
```

#### Format 2: Community Challenge Cast
```
⚔️ This Week's Challenge

Find words with Greek roots

Current leaders:
🥇 @alice (12 words)
🥈 @bob (9 words)
🥉 @carol (7 words)

Join: wyrd.game/challenge

Prize: 1000 WYRD + exclusive POAP
```

#### Format 3: Revelation Thread Cast
```
🧵 Word Revelation Thread (1/5)

5 words that will change how you see the world:

1. DISASTER = bad star (dis + aster)
   Ancient Romans blamed misfortune on stars

→ Read the full thread

#Etymology #WYRD
```

### 6.5 Farcaster-First Features

**Native Integrations:**

| Feature | Description | Viral Effect |
|---------|-------------|--------------|
| **Cast Embed** | Every share is a cast-ready embed | Native sharing |
| **Frame Actions** | One-tap reveal, share, challenge | Low friction |
| **Channel Bot** | Auto-post daily words, challenges | Consistent presence |
| **Mention Rewards** | Tag @wyrd for bonus points | Brand mentions |
| **Recast Incentives** | Recast daily word for points | Organic reach |
| **Reply Challenges** | Reply with word guess for rewards | Engagement |

---

## 7. IMPLEMENTATION ROADMAP

### Phase 1: Foundation (Weeks 1-4)

| Week | Feature | Priority | Effort |
|------|---------|----------|--------|
| 1 | Share cards + basic sharing | P0 | Medium |
| 1 | Points system (basic) | P0 | Low |
| 2 | Referral links + tracking | P0 | Medium |
| 2 | Daily streak system | P0 | Low |
| 3 | Leaderboards (basic) | P1 | Low |
| 3 | Achievement badges | P1 | Medium |
| 4 | Farcaster frame (daily word) | P0 | Medium |
| 4 | /wyrd channel setup | P0 | Low |

### Phase 2: Growth (Weeks 5-8)

| Week | Feature | Priority | Effort |
|------|---------|----------|--------|
| 5 | Quest system | P1 | Medium |
| 5 | Community challenges | P1 | Medium |
| 6 | Word submission system | P1 | High |
| 6 | Friend activity feed | P2 | Medium |
| 7 | Word battles | P2 | Medium |
| 7 | POAP integration | P2 | Medium |
| 8 | Tiered referral program | P1 | Medium |
| 8 | Collective milestones | P2 | Low |

### Phase 3: Scale (Weeks 9-12)

| Week | Feature | Priority | Effort |
|------|---------|----------|--------|
| 9 | Advanced frames (battles, milestones) | P2 | Medium |
| 9 | Power badge benefits | P2 | Low |
| 10 | Airdrop announcement prep | P1 | Medium |
| 10 | Anti-sybil measures | P1 | Medium |
| 11 | Tokenomics design | P1 | High |
| 11 | Governance framework | P2 | High |
| 12 | Full airdrop campaign | P0 | High |
| 12 | WYRD DAO formation | P2 | High |

### Resource Requirements

| Role | Phase 1 | Phase 2 | Phase 3 |
|------|---------|---------|---------|
| Frontend Dev | 1 FTE | 1 FTE | 1.5 FTE |
| Backend Dev | 0.5 FTE | 1 FTE | 1 FTE |
| Smart Contract | 0 FTE | 0.25 FTE | 1 FTE |
| Designer | 0.5 FTE | 0.5 FTE | 0.5 FTE |
| Community | 0.5 FTE | 1 FTE | 1.5 FTE |

---

## 8. SUCCESS METRICS

### Primary KPIs

| Metric | Month 1 | Month 3 | Month 6 | Month 12 |
|--------|---------|---------|---------|----------|
| **DAU** | 500 | 2,000 | 5,000 | 15,000 |
| **MAU** | 2,000 | 8,000 | 20,000 | 50,000 |
| **K-factor** | 0.3 | 0.6 | 0.9 | 1.2 |
| **Retention (D7)** | 25% | 35% | 40% | 45% |
| **Retention (D30)** | 10% | 15% | 20% | 25% |
| **Shares/week** | 200 | 1,000 | 3,000 | 10,000 |
| **Referral %** | 15% | 25% | 35% | 45% |

### Secondary KPIs

| Metric | Target |
|--------|--------|
| Words analyzed / user / week | 10 |
| Average session duration | 5 minutes |
| Share conversion rate | 15% |
| Referral conversion rate | 25% |
| Community submissions / month | 100 |
| Farcaster channel members | 5,000 |
| POAPs claimed | 2,000 |

### Viral Loop Health Metrics

| Loop | Health Indicator | Target |
|------|-----------------|--------|
| Share Loop | Shares / DAU | 0.4 |
| Referral Loop | Referrals / DAU | 0.15 |
| Content Loop | Submissions / MAU | 0.05 |
| Challenge Loop | Challenge participants / MAU | 0.2 |

---

## 9. RISK MITIGATION

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| **Sybil attacks on points** | High | High | Gitcoin Passport, behavioral analysis |
| **Low share conversion** | Medium | High | A/B test formats, optimize timing |
| **Referral spam** | Medium | Medium | Rate limits, quality scoring |
| **Content quality decline** | Medium | Medium | Community voting + moderation |
| **Token launch delay** | Medium | Medium | Points have standalone value |
| **Farcaster algorithm change** | Low | High | Multi-platform strategy |

---

## 10. CONCLUSION

WYRD's viral strategy combines the natural shareability of etymology revelations with crypto-native mechanics that reward participation and contribution. By focusing on:

1. **Genuine value creation** (mind-blowing word origins)
2. **Low-friction sharing** (beautiful share cards, Farcaster frames)
3. **Aligned incentives** (points, airdrops, recognition)
4. **Community ownership** (submissions, governance)

We create a sustainable growth engine where users are motivated to share not just for rewards, but because the content is genuinely worth sharing.

**Target Outcome:** 50,000 MAU within 12 months with a K-factor > 1, driven primarily by organic viral loops and community contribution.

---

*Document created for WYRD - Linguistic Liberation System*  
*Viral Growth Strategy v1.0*
