# WYRD: Addictive Game Mechanics Design Document
## Linguistic Liberation System - Game Design v1.0

---

## Executive Summary

This document outlines comprehensive game mechanics designed to create an engaging, meaningful, and ethically-designed gameplay experience for WYRD. The mechanics focus on intrinsic motivation, intellectual curiosity, and community connection while avoiding exploitative dark patterns.

**Design Philosophy:**
- Reward curiosity and deep thinking over speed
- Create meaningful progression through knowledge mastery
- Foster community through shared linguistic discoveries
- Maintain the game's consciousness-liberation mission

---

## 1. CORE LOOP ENHANCEMENT

### 1.1 The Liberation Loop (Primary Loop)

```
TRIGGER → ACTION → REWARD → INVESTMENT → (repeat)
```

#### **Trigger Layer**

| Trigger Type | Mechanic | Timing | Psychology |
|--------------|----------|--------|------------|
| **Daily Word** | New curated word available | 12:00 AM local time | Creates anticipation; FOMO prevention (24hr window) |
| **Streak Alert** | "Your 7-day streak expires in 2 hours" | Variable based on streak | Loss aversion drives return |
| **Discovery Pulse** | Push notification: "Uncover the hidden truth behind 'Democracy'" | 9:00 AM (optimal engagement) | Curiosity gap theory |
| **Community Spark** | "3 friends analyzed 'Propaganda' today" | Real-time | Social proof |
| **Milestone Nudge** | "You're 50 points from Level 7" | When close to threshold | Goal gradient effect |

#### **Action Layer - The 4-Step Analysis Flow**

**Enhanced with Micro-Rewards:**

```
Step 1: Surface Reading (30 seconds)
├── Player reads word and initial definition
├── Micro-reward: +5 XP (immediate feedback)
└── Unlock: Context clues appear

Step 2: Root Excavation (45-90 seconds)
├── Player explores etymology tree
├── Interactive element: Click to reveal deeper roots
├── Micro-reward: +10 XP per root discovered
└── Unlock: Historical usage examples

Step 3: Semantic Shift (60-120 seconds)
├── Player traces meaning evolution
├── Drag-and-drop timeline (optional interaction)
├── Micro-reward: +15 XP for completing timeline
└── Unlock: Related words network

Step 4: Liberation Angle (60+ seconds)
├── Player writes/refines their insight
├── Optional: Select from guided prompts
├── Micro-reward: +25 XP base + quality bonus
└── Unlock: Share to community + personal archive
```

#### **Reward Layer**

**Immediate Rewards (Within Session):**
- XP accumulation with visual progress bar
- Root fragments collected (visual collectibles)
- Insight quality rating (1-5 stars)
- Optional: Small sound effects for milestones

**Session Completion Rewards:**
| Words Analyzed | Reward |
|----------------|--------|
| 1 word | +50 XP, 1 Root Fragment |
| 3 words | +150 XP, 3 Root Fragments, "Curious Mind" badge |
| 5 words | +300 XP, 5 Root Fragments, "Deep Diver" badge, 2x XP boost (1 hour) |
| 7+ words | +500 XP, 10 Root Fragments, "Liberation Seeker" badge, unlock premium word |

#### **Investment Layer**

**What Players Leave Behind:**
1. **Personal Liberation Journal** - All insights saved and searchable
2. **Word Mastery Progress** - Visual progress on each word
3. **Collection Progress** - Root fragments toward unlocking features
4. **Streak Counter** - Visible commitment device
5. **Community Contributions** - Shared insights and upvotes received

**Investment Psychology:**
- Sunk cost effect: Players return to protect their progress
- Identity reinforcement: "I am someone who questions language"
- Collection completion: Desire to finish word categories

### 1.2 Secondary Loops

#### **The Daily Ritual Loop**
```
Morning Notification → Complete Daily Word → Share Insight → Check Leaderboard
```
- Designed for 5-10 minute morning routine
- Creates habit formation through temporal anchoring

#### **The Deep Dive Loop**
```
Discover New Category → Explore 5+ Words → Unlock Category Mastery → Share Discovery
```
- Designed for 20-30 minute weekend sessions
- Appeals to completionist psychology

#### **The Social Connection Loop**
```
Friend Shares Word → Analyze Same Word → Compare Insights → Discussion
```
- Creates viral spread through intellectual curiosity
- Builds community around shared discoveries

---

## 2. PROGRESSION SYSTEM

### 2.1 Player Levels (The Path of Liberation)

**Level Structure:**

| Level | Title | XP Required | Unlock |
|-------|-------|-------------|--------|
| 1 | Word Wanderer | 0 | Basic analysis, 10 starter words |
| 2 | Root Seeker | 200 | Daily word access, basic categories |
| 3 | Etymology Apprentice | 500 | Word scanner, 3 new categories |
| 4 | Meaning Miner | 1,000 | Streak tracking, insight sharing |
| 5 | Language Liberator | 2,000 | Advanced categories, profile customization |
| 6 | Semantic Scholar | 4,000 | Word creation suggestions, community features |
| 7 | Truth Tracer | 7,000 | Historical word packs, analysis history |
| 8 | Consciousness Cartographer | 12,000 | Expert categories, mentor status |
| 9 | Lexical Luminary | 20,000 | Beta features, exclusive content |
| 10 | Master of Liberation | 35,000 | All features, creator tools, immortalized in credits |

**Level-Up Ceremony:**
- Animated level-up screen
- New title displayed prominently
- Unlock preview for next level
- Optional: Share achievement to social media

### 2.2 Achievement System (Badges of Liberation)

**Category Badges:**

| Badge | Requirement | Rarity |
|-------|-------------|--------|
| First Steps | Complete first word analysis | Common |
| Daily Devotee | 7-day streak | Common |
| Week Warrior | 30-day streak | Uncommon |
| Monthly Master | 100-day streak | Rare |
| Century Seeker | 365-day streak | Legendary |
| Root Collector | Analyze 50 words | Common |
| Etymology Expert | Analyze 200 words | Uncommon |
| Lexical Legend | Analyze 500 words | Rare |
| Word Wizard | Analyze 1,000 words | Legendary |
| Deep Thinker | Write 50 insights over 100 characters | Uncommon |
| Provocation Pro | Receive 100 upvotes on insights | Rare |
| Community Catalyst | Have 10 friends join via referral | Rare |
| Category Conqueror | Master all words in one category | Uncommon |
| Renaissance Reader | Analyze words from 10+ categories | Uncommon |
| Night Owl | Analyze words 10 days in a row after 10 PM | Uncommon |
| Early Bird | Analyze words 10 days in a row before 8 AM | Uncommon |
| Speed Demon | Complete analysis in under 2 minutes (5 times) | Uncommon |
| Thoughtful Theorist | Spend 10+ minutes on single word analysis | Uncommon |
| Inversion Detector | Identify 25 "inverted" words | Uncommon |
| Truth Teller | Share 50 insights to community | Rare |

**Secret Badges (Hidden until unlocked):**
- "Easter Egg Hunter" - Find hidden word connections
- "Conspiracy Theorist" - Analyze 10 politically charged words
- "Ancient Tongue" - Trace word to Proto-Indo-European root
- "Word Wizard" - Suggest word that gets added to database

### 2.3 Long-Term Goals (Mastery Paths)

**Path of the Philologist:**
- Goal: Analyze 2,000+ words
- Reward: "Philologist" title, access to academic word packs
- Timeframe: 6-12 months

**Path of the Liberator:**
- Goal: Write 500 high-quality insights (4+ star average)
- Reward: "Liberator" title, ability to create guided prompts
- Timeframe: 4-8 months

**Path of the Connector:**
- Goal: Build network of 50+ active friends
- Reward: "Connector" title, community moderation tools
- Timeframe: 3-6 months

**Path of the Completionist:**
- Goal: Master all words in all categories
- Reward: "Completionist" title, exclusive "Founding Liberator" status
- Timeframe: 12-24 months

---

## 3. SCORING & REWARDS SYSTEM

### 3.1 XP (Experience Points) Breakdown

**Base XP:**

| Action | XP | Notes |
|--------|-----|-------|
| Complete Surface Reading | 5 | Instant |
| Discover Root (each) | 10 | Stackable |
| Complete Semantic Shift | 15 | One-time per word |
| Submit Liberation Insight | 25 | Base amount |
| Daily Word Bonus | +50% | Multiplier on all actions |
| First Analysis of Day | +25 | Daily bonus |
| New Category Discovery | +100 | One-time per category |
| Streak Milestone (7d) | +200 | Every 7 days |
| Streak Milestone (30d) | +500 | Every 30 days |
| Streak Milestone (100d) | +2000 | Every 100 days |

**Quality Multipliers:**

| Insight Quality | Multiplier | Criteria |
|-----------------|------------|----------|
| 1 Star | 0.5x | < 20 characters |
| 2 Stars | 0.75x | 20-50 characters |
| 3 Stars | 1.0x | 50-100 characters |
| 4 Stars | 1.25x | 100-200 characters + depth |
| 5 Stars | 1.5x | 200+ characters + exceptional insight |

**Quality Determination:**
- Algorithm considers: length, vocabulary complexity, question marks (curiosity), unique perspective
- Community upvotes boost quality rating retroactively

### 3.2 Streak System

**Streak Mechanics:**

| Streak Range | Daily Bonus | Streak Protection |
|--------------|-------------|-------------------|
| 1-6 days | +10 XP | None |
| 7-13 days | +25 XP | 1 free miss per month |
| 14-29 days | +50 XP | 2 free misses per month |
| 30-99 days | +100 XP | 3 free misses per month |
| 100+ days | +200 XP | 5 free misses per month |

**Streak Protection:**
- "Streak Freeze" - Can be earned or purchased with Root Fragments
- Automatic protection for first 3 days (new player grace period)
- Weekend mode: Saturday/Sunday count as one day (optional setting)

**Streak Recovery:**
- After break: Can "buy back" streak within 48 hours using Root Fragments
- Cost: 50 Fragments per day missed (max 200 for 7 days)

### 3.3 Root Fragments (Premium Currency)

**Earning Fragments:**

| Action | Fragments |
|--------|-----------|
| Complete word analysis | 1-3 (random) |
| Daily word completion | +2 bonus |
| 7-day streak | 10 |
| 30-day streak | 25 |
| Achievement unlock | 5-50 |
| Community upvote received | 1 |
| Friend referral | 25 |
| Bug report/feature suggestion | 10-50 |

**Spending Fragments:**

| Item | Cost |
|------|------|
| Unlock premium word | 50 |
| Streak freeze | 25 |
| Streak recovery (per day) | 50 |
| Category early unlock | 100 |
| Profile customization item | 15-50 |
| 2x XP boost (1 hour) | 30 |
| Reveal hidden word connection | 20 |
| Suggest new word for database | 100 |

### 3.4 Word Mastery Tiers

**Mastery Progression per Word:**

| Tier | Analyses Required | Visual Indicator | Reward |
|------|-------------------|------------------|--------|
| Unseen | 0 | Gray outline | - |
| Discovered | 1 | Bronze outline | +10 XP |
| Familiar | 3 | Silver outline | +25 XP, root fragment bonus |
| Known | 5 | Gold outline | +50 XP, unlock related words |
| Mastered | 10 | Platinum with glow | +200 XP, mastery badge progress |

**Mastery Benefits:**
- Mastered words contribute to category completion
- Mastered words appear in "Your Expertise" profile section
- Mastered words can be "taught" to others (mentor feature)

---

## 4. SOCIAL MECHANICS

### 4.1 Friend System

**Connection Types:**

| Type | How to Add | Features |
|------|------------|----------|
| Follow | One-click | See their public insights, activity feed |
| Friend | Mutual acceptance | Compare progress, private discussions |
| Study Partner | Invite + acceptance | Shared word challenges, streak accountability |

**Friend Features:**
- Activity feed: "Alex analyzed 'Propaganda' and wrote: '...'"
- Progress comparison: Side-by-side stats
- Word challenges: "Let's both analyze 'Democracy' today"
- Streak accountability: Notifications when friend might break streak

### 4.2 Leaderboards

**Leaderboard Categories:**

| Leaderboard | Metric | Reset Frequency |
|-------------|--------|-----------------|
| Weekly Wisdom | XP earned this week | Weekly (Monday) |
| Monthly Mastery | Words analyzed this month | Monthly |
| All-Time Liberators | Total XP | Never |
| Streak Champions | Current streak length | Never |
| Insight Leaders | Total upvotes received | Never |
| Speed Runners | Fastest analysis times | Weekly |
| Deep Divers | Longest analysis times | Weekly |

**Leaderboard Psychology:**
- Show player's position + 2 above and below (relatable competition)
- Top 10% get special badge
- Top 100 get "Leaderboard Legend" title
- No penalties for falling behind (positive framing only)

### 4.3 Community Features

**Insight Sharing:**
- Players can share insights to community feed
- Anonymous option available
- Upvote/downvote system (downvotes hidden, only affect ranking)
- Comment threads on popular insights
- "Insight of the Day" featured on homepage

**Word Discussions:**
- Each word has discussion thread
- Moderated by community (Path of Connector members)
- Featured insights highlighted
- "Expert Analysis" from top contributors

**Collaborative Challenges:**

| Challenge | Description | Reward |
|-----------|-------------|--------|
| Word of the Week | Community analyzes same word | Bonus XP for all participants |
| Category Sprint | Race to master new category | Exclusive badge |
| Truth Hunt | Find words with specific pattern | Root fragment bounty |
| Liberation Relay | Chain of insights on related words | Community milestone rewards |

### 4.4 Viral Mechanics

**Share Features:**

| Share Type | Content | Incentive |
|------------|---------|-----------|
| Insight Card | Beautiful image of insight + word etymology | 5 fragments per share |
| Streak Milestone | "I've analyzed words for 30 days straight!" | 10 fragments |
| Achievement | Badge unlock announcement | 5 fragments |
| Word Discovery | "I just uncovered the truth about [word]" | 3 fragments |

**Referral Program:**
- Unique referral link for each player
- Referrer gets: 25 fragments + 100 XP per friend
- Referred friend gets: 50 fragments starter bonus
- Milestone bonuses: 5 friends = 250 fragments, 10 friends = 500 fragments + exclusive badge

---

## 5. WORD MASTERY SYSTEM

### 5.1 Skill Tree: The Liberation Path

**Branch 1: Root Recognition**
- Level 1: Identify Latin roots (unlock at Level 2)
- Level 2: Identify Greek roots (unlock at Level 4)
- Level 3: Identify Germanic roots (unlock at Level 5)
- Level 4: Identify Proto-Indo-European roots (unlock at Level 7)
- Level 5: Cross-language root recognition (unlock at Level 9)

**Branch 2: Semantic Detective**
- Level 1: Trace simple meaning shifts (unlock at Level 3)
- Level 2: Identify political manipulation in language (unlock at Level 5)
- Level 3: Recognize euphemism treadmill (unlock at Level 6)
- Level 4: Detect inverted meanings (unlock at Level 7)
- Level 5: Predict future semantic shifts (unlock at Level 9)

**Branch 3: Liberation Artist**
- Level 1: Write basic insights (unlock at Level 1)
- Level 2: Craft provocative questions (unlock at Level 4)
- Level 3: Connect words to systemic analysis (unlock at Level 6)
- Level 4: Create insight series/themes (unlock at Level 8)
- Level 5: Mentor others in liberation thinking (unlock at Level 9)

### 5.2 Category Mastery

**Word Categories:**

| Category | Word Count | Difficulty | Unlock Level |
|----------|------------|------------|--------------|
| Power & Control | 25 | Easy | 1 |
| Money & Economics | 20 | Easy | 1 |
| Work & Labor | 20 | Easy | 2 |
| Education & Learning | 15 | Easy | 2 |
| Media & Communication | 20 | Medium | 3 |
| Law & Justice | 20 | Medium | 3 |
| War & Violence | 15 | Medium | 4 |
| Religion & Spirituality | 20 | Medium | 4 |
| Medicine & Health | 20 | Medium | 5 |
| Technology & Progress | 20 | Medium | 5 |
| Time & History | 15 | Hard | 6 |
| Identity & Self | 20 | Hard | 6 |
| Nature & Environment | 20 | Hard | 7 |
| Emotion & Psychology | 20 | Hard | 7 |
| Ancient & Forgotten | 15 | Expert | 8 |
| Future & Speculative | 15 | Expert | 9 |

**Category Mastery Rewards:**
- 25% complete: +100 XP, category badge progress
- 50% complete: +250 XP, category insights unlocked
- 75% complete: +500 XP, expert status in category
- 100% complete: +1000 XP, "[Category] Master" title, exclusive content

### 5.3 Analysis Depth Levels

**Depth Tiers:**

| Tier | Time Investment | Reward Multiplier | Description |
|------|-----------------|-------------------|-------------|
| Surface | 1-2 min | 1.0x | Quick analysis, basic insight |
| Standard | 3-5 min | 1.2x | Full 4-step process |
| Deep | 6-10 min | 1.5x | Extended research, multiple connections |
| Scholarly | 10+ min | 2.0x | Comprehensive analysis with external research |

**Depth Detection:**
- Time spent on each step
- Number of roots explored
- Insight length and quality
- External link clicks (if implemented)

---

## 6. DISCOVERY MECHANICS

### 6.1 Word Unlock System

**Unlock Methods:**

| Method | Description | Frequency |
|--------|-------------|-----------|
| Level Up | New words unlocked at each level | Per level |
| Category Mastery | Unlock related categories | Per category |
| Daily Word | New word available every day | Daily |
| Root Fragment Purchase | Buy premium words | Anytime |
| Community Events | Special words during events | Monthly |
| Achievements | Reward words for milestones | Per achievement |
| Random Discovery | "Found word" while analyzing | Random (5% chance) |

**Word Rarity Tiers:**

| Rarity | Color | How to Obtain | Examples |
|--------|-------|---------------|----------|
| Common | White | Default unlock | Government, Money, Work |
| Uncommon | Green | Level 3+, categories | Propaganda, Currency, Labor |
| Rare | Blue | Level 5+, achievements | Hegemony, Fiat, Alienation |
| Epic | Purple | Level 7+, events | Cybernetics, Usury, Anomie |
| Legendary | Gold | Level 9+, mastery | Archon, Mammon, Luddite |

### 6.2 Feature Unlock Roadmap

**Progressive Feature Unlock:**

| Feature | Unlock Level | Description |
|---------|--------------|-------------|
| Basic Analysis | 1 | 4-step process |
| Daily Word | 2 | Curated daily word |
| Word Scanner | 3 | Scan any word for etymology |
| Streak Tracking | 4 | Track daily participation |
| Insight Sharing | 4 | Share to community |
| Categories | 5 | Organized word collections |
| Profile Customization | 5 | Personalize profile |
| Friend System | 6 | Connect with others |
| Leaderboards | 6 | See rankings |
| Advanced Categories | 7 | Expert-level content |
| Word Suggestions | 7 | Suggest new words |
| Mentor Mode | 8 | Guide new players |
| Creator Tools | 9 | Create content |
| Beta Access | 9 | Test new features |
| Immortalization | 10 | Name in credits, legacy status |

### 6.3 Surprise & Delight Mechanics

**Easter Eggs:**

| Trigger | Easter Egg | Reward |
|---------|------------|--------|
| Analyze "Serendipity" | Special animation | 50 fragments |
| 3 palindrome words in row | "Mirror Master" badge | 100 XP |
| Analyze word on its "etymology birthday" | Historical context bonus | 25 fragments |
| Find hidden connection between 2 words | "Connection Finder" badge | 50 XP |
| Analyze at 3:33 AM | "Night Philosopher" badge | Secret content |

**Random Events:**

| Event | Frequency | Description |
|-------|-----------|-------------|
| Double XP Weekend | Monthly | 2x XP for 48 hours |
| Mystery Word | Weekly | Hidden word, bonus for finding |
| Community Challenge | Bi-weekly | Collective goal for all players |
| Flashback Word | Random | Revisit word with new context |
| Expert Guest | Monthly | Special word curated by guest |

---

## 7. IMPLEMENTATION PRIORITIES

### 7.1 Phase 1: Core Loop (Weeks 1-4)

**Priority: CRITICAL**

| Feature | Effort | Impact |
|---------|--------|--------|
| XP system with progress bar | Low | High |
| Basic achievement badges | Low | High |
| Streak tracking | Medium | High |
| Daily word bonus | Low | High |
| Level progression (1-5) | Low | High |

### 7.2 Phase 2: Engagement (Weeks 5-8)

**Priority: HIGH**

| Feature | Effort | Impact |
|---------|--------|--------|
| Root fragments currency | Medium | Medium |
| Word mastery tiers | Medium | High |
| Extended levels (6-10) | Low | Medium |
| Quality rating system | Medium | High |
| Basic leaderboards | Medium | Medium |

### 7.3 Phase 3: Social (Weeks 9-12)

**Priority: MEDIUM**

| Feature | Effort | Impact |
|---------|--------|--------|
| Friend system | High | High |
| Insight sharing | High | High |
| Community feed | High | Medium |
| Referral program | Medium | High |
| Word challenges | Medium | Medium |

### 7.4 Phase 4: Depth (Weeks 13-16)

**Priority: MEDIUM**

| Feature | Effort | Impact |
|---------|--------|--------|
| Skill tree system | High | Medium |
| Advanced categories | Medium | Medium |
| Mentor mode | High | Low |
| Creator tools | High | Low |
| Surprise mechanics | Medium | Medium |

### 7.5 Technical Implementation Notes

**Data Models Needed:**

```typescript
// Player Progress
interface PlayerProgress {
  userId: string;
  level: number;
  xp: number;
  streak: number;
  lastActive: Date;
  streakProtection: number;
  rootFragments: number;
  unlockedCategories: string[];
  masteredWords: string[];
  achievements: string[];
  skillTree: SkillTreeProgress;
}

// Word Mastery
interface WordMastery {
  userId: string;
  wordId: string;
  analysisCount: number;
  lastAnalyzed: Date;
  insights: Insight[];
  masteryTier: 'unseen' | 'discovered' | 'familiar' | 'known' | 'mastered';
}

// Achievement
interface Achievement {
  id: string;
  name: string;
  description: string;
  rarity: 'common' | 'uncommon' | 'rare' | 'legendary';
  condition: AchievementCondition;
  reward: Reward;
}
```

**Storage Requirements:**
- Player progress: ~2KB per player
- Word mastery: ~500 bytes per word per player
- Insights: ~1KB per insight
- For 10,000 players with 100 words each: ~500MB

**Performance Considerations:**
- Cache leaderboards, recalculate every 15 minutes
- Lazy-load achievement checks
- Batch XP updates
- Use local storage for offline progress, sync on reconnect

---

## 8. ETHICAL DESIGN PRINCIPLES

### 8.1 What We AVOID (Dark Patterns)

| Dark Pattern | Why We Avoid It | Our Alternative |
|--------------|-----------------|-----------------|
| Pay-to-win | Creates inequality, exploits addiction | All purchases cosmetic/convenience only |
| Infinite scroll | Time sink, loss of control | Clear session endpoints with rewards |
| Artificial scarcity | Manufactured anxiety | Generous time windows, streak protection |
| Social pressure manipulation | Damages relationships | Positive-only social features |
| Variable reward addiction | Gambling psychology | Predictable, fair reward systems |
| Sleep disruption | Health harm | No late-night notifications by default |
| Shame for inactivity | Negative motivation | Positive reinforcement only |

### 8.2 What We EMBRACE (Light Patterns)

| Light Pattern | Implementation |
|---------------|----------------|
| Autonomy | Players choose depth, categories, social engagement level |
| Mastery | Clear skill progression, meaningful improvement |
| Purpose | Insights contribute to collective knowledge |
| Curiosity | Discovery mechanics reward exploration |
| Connection | Optional social features build community |
| Reflection | Analysis process encourages deep thinking |
| Completion | Clear endpoints with satisfying rewards |

### 8.3 Player Wellbeing Features

| Feature | Description |
|---------|-------------|
| Session Timer | Optional reminder after 20/40/60 minutes |
| Daily Limit | Soft cap at 10 words (can override) |
| Break Suggestions | Encourage breaks after long sessions |
| Streak Sanity | Weekend mode, generous protection |
| Notification Control | Granular control over all notifications |
| Pause Mode | Temporary disable all streaks/progress |
| Export Data | Players own their insights and progress |

---

## 9. SUCCESS METRICS

### 9.1 Engagement Metrics

| Metric | Target | Measurement |
|--------|--------|-------------|
| Day 1 Retention | 60%+ | Players returning next day |
| Day 7 Retention | 35%+ | Players returning after week |
| Day 30 Retention | 20%+ | Players returning after month |
| Average Session Length | 5-10 min | Time per session |
| Sessions per User per Week | 4+ | Frequency of engagement |
| Words Analyzed per User | 50+ (month 1) | Content consumption |

### 9.2 Quality Metrics

| Metric | Target | Measurement |
|--------|--------|-------------|
| Average Insight Quality | 3.5+ stars | Community ratings |
| Insight Sharing Rate | 30%+ | % who share insights |
| Category Completion | 2+ categories | Depth of engagement |
| Level Progression | Level 3+ (week 1) | Progression speed |
| Streak Achievement | 7+ days (30% of users) | Habit formation |

### 9.3 Social Metrics

| Metric | Target | Measurement |
|--------|--------|-------------|
| Friend Connections | 3+ per active user | Social network growth |
| Referral Rate | 0.5 per user | Viral coefficient |
| Community Upvotes | 10+ per active user | Content quality |
| Discussion Participation | 20%+ | Active community |

---

## 10. CONCLUSION

This game mechanics design for WYRD creates an engaging, meaningful experience that:

1. **Respects Players** - No exploitative patterns, full autonomy
2. **Rewards Curiosity** - Deep thinking valued over speed
3. **Builds Community** - Social features enhance, don't pressure
4. **Creates Mastery** - Clear progression from novice to expert
5. **Supports Mission** - Every mechanic reinforces linguistic liberation

**Key Success Factors:**
- Start simple, add complexity progressively
- Listen to player feedback
- Maintain ethical standards even when tempted by engagement metrics
- Keep the focus on the transformative power of etymology

**Next Steps:**
1. Implement Phase 1 features (core loop)
2. A/B test XP values and reward frequencies
3. Gather player feedback on progression speed
4. Iterate based on retention data
5. Plan Phase 2-4 based on Phase 1 learnings

---

*Document Version: 1.0*
*Created for: WYRD Linguistic Liberation System*
*Design Philosophy: Engaging, Ethical, Enlightening*
